# AI Architect Pro | v0.0.27

## First run
Open a new Baseplate and use **AI Chat**. Type `/blueprint neighbourhood` and click Send, review the report, then Apply plan. This path requires no language model or internet. Other explicit blueprints: `/blueprint district`, `/blueprint house`, `/blueprint park`, `/blueprint parking`, `/blueprint plaza`.

## Local model
The installed qwen2.5:3b remains the default. For an optional instruction-tuned upgrade, install `qwen3:4b-instruct` using `ollama pull qwen3:4b-instruct` and choose Qwen3 4B or Change model. Model selection is saved outside the engine release. The model is not included in this ZIP. If memory pressure is high, use the original model or blueprints.

## How planning works
- Scene and asset context includes existing spawn, ground/terrain, road corridors, nearby objects, and sampled free sites.
- Proposed actions are processed in order: terrain, roads, districts, buildings/public spaces, props, vegetation, environment and spawn.
- Spawn is a non-solid editor marker. Duplicate spawn requests and duplicate terrain on an existing baseplate are ignored. If new construction would obstruct the spawn, it is relocated to clear supported ground and the move is disclosed before Apply.
- Exact placement is tried first. For ordinary placement conflicts, a bounded deterministic search may translate the complete operation, preserving geometry and dimensions. Explicit coordinate requests disable translation. Invalid actions are skipped; valid actions remain reviewable. No live scene changes happen before Apply. A stale scene requires a fresh plan.
- Report lists accepted/skipped operations and moves. The entire approved plan is undoable. Cancelling discards pending results; already-running local inference can take time to exit.
- A deterministic matching blueprint may be offered if a recognisable construction request fails or produces no valid changes. It is explicitly labelled as not a live AI response; it may not satisfy unrecognised details.
- Maximum 48 operations and 1,800 new entities per plan. Use districts for larger cities.

## Construction tools
- Houses, shops, apartments: wall sections, actual entry openings, interior partitions on qualifying houses, ground floor, window panes/collision, roof and trim. Upper levels have slabs but no stairs. These are procedural, not scanned architecture.
- Neighbourhoods and mixed-use districts: road, kerbs, footpaths, front paths, oriented buildings.
- Parks: grass, paths, benches and spaced trees. Plazas: paving, benches, planters. Parking: marked bays and wheel stops.
- Existing project GLB assets: preserve native scale by default, ground-snap and check footprint. No arbitrary code execution, deletion or third-party downloads by AI.

## Test prompts
- Build a six-house suburban neighbourhood with a park.
- Build a small mixed-use town centre with shops and apartment buildings.
- Add a 22 metre wide parking area on a clear lot.
- Create a park with paths, benches and five trees.
- Use imported assets from the project library to add street props.

## Limits
Spatial checks use conservative bounds and finite terrain samples, not exact mesh collision. Road intersections are not guaranteed traffic-network junctions. Public-space roads are not automatically connected to a parking lot. No furnished upper storeys or automatic scanned-building retrieval. Models, GPU performance, and full macOS installation require hardware testing. This update prioritises functioning logic over artificial download size.
