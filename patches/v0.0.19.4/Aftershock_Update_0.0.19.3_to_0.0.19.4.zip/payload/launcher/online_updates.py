"""Public GitHub Releases transport for the existing validated patch format."""
import hashlib, json, re, time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from .update_manager import MAX_BYTES, version_key, atomic_json, read_json

DEFAULT_REPO='Aftershock-Studios/Updates'
REPO=re.compile(r'[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9_.-]{1,100}\Z')
ASSET=re.compile(r'Aftershock_Update_([0-9.]+)_to_([0-9.]+)\.zip\Z')
HOSTS={'github.com','api.github.com','release-assets.githubusercontent.com','objects.githubusercontent.com'}

def repository(value):
    value=value.strip().removeprefix('https://github.com/').rstrip('/')
    if not REPO.fullmatch(value) or value.split('/')[1] in ('.','..'):raise ValueError('Enter a GitHub repository as owner/name')
    return value

def config_path(manager):return manager.folder/'online.json'
def get_repo(manager):
    p=config_path(manager)
    return repository(read_json(p)['repository']) if p.exists() else DEFAULT_REPO

def set_repo(manager,value):
    value=repository(value);atomic_json(config_path(manager),{'repository':value});return value

def safe_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or p.hostname not in HOSTS or p.username or p.password or p.port not in (None,443):raise ValueError('Unexpected GitHub download address')
    return p

class Redirects(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        safe_url(newurl);return super().redirect_request(req,fp,code,msg,headers,newurl)

def open_url(url,accept):
    safe_url(url)
    req=Request(url,headers={'User-Agent':'Aftershock-Studio-Updater','Accept':accept})
    try:return build_opener(Redirects()).open(req,timeout=25)
    except HTTPError as e:raise RuntimeError(f'GitHub returned HTTP {e.code}. Check that the update repository is public and has published releases.') from e
    except URLError as e:raise RuntimeError(f'Could not connect to GitHub: {e.reason}') from e

def select_update(releases,repo,current):
    candidates=[]; repo=repository(repo); current_key=version_key(current)
    for release in releases:
        if release.get('draft') or release.get('prerelease'):continue
        for asset in release.get('assets',[]):
            name=asset.get('name','');m=ASSET.fullmatch(name)
            if not m or m[1]!=current or asset.get('state')!='uploaded':continue
            try:target_key=version_key(m[2])
            except ValueError:continue
            if target_key<=current_key:continue
            if release.get('tag_name') not in (m[2],'v'+m[2]):continue
            url=asset.get('browser_download_url','');size=asset.get('size');digest=asset.get('digest') or ''
            try:p=safe_url(url)
            except ValueError:continue
            if p.hostname!='github.com' or p.path.casefold()!=f'/{repo}/releases/download/{release["tag_name"]}/{name}'.casefold() or p.query or p.fragment:continue
            if type(size) is not int or not 0<size<=MAX_BYTES or not re.fullmatch('sha256:[0-9a-f]{64}',digest):continue
            candidates.append((target_key,{'repository':repo,'base':current,'target':m[2],'url':url,'size':size,'sha256':digest[7:]}))
    return max(candidates,key=lambda x:x[0])[1] if candidates else None

def check(repo,current):
    repo=repository(repo);releases=[]
    # Check up to 500 stable/prerelease entries for a direct compatible patch.
    for page in range(1,6):
        with open_url(f'https://api.github.com/repos/{repo}/releases?per_page=100&page={page}','application/vnd.github+json') as response:
            raw=response.read(16*1024*1024+1)
        if len(raw)>16*1024*1024:raise ValueError('GitHub release response too large')
        items=json.loads(raw)
        if not isinstance(items,list):raise ValueError('Unexpected GitHub release response')
        releases.extend(items)
        if len(items)<100:break
    return select_update(releases,repo,current)

def download(asset,path,report=lambda m,p:None):
    repo=repository(asset['repository']);base=asset['base'];target=asset['target'];version_key(base);version_key(target)
    url=asset['url'];p=safe_url(url);name=f'Aftershock_Update_{base}_to_{target}.zip'
    if p.hostname!='github.com' or p.path.casefold() not in [f'/{repo}/releases/download/{tag}/{name}'.casefold() for tag in (target,'v'+target)] or p.query or p.fragment:raise ValueError('Download is outside configured release')
    size=asset['size'];digest=asset['sha256']
    if type(size) is not int or not 0<size<=MAX_BYTES or not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Invalid release asset metadata')
    path=Path(path);h=hashlib.sha256();done=0;last=0.;deadline=time.monotonic()+1800
    try:
        report('Downloading update from GitHub…',2)
        with open_url(url,'application/octet-stream') as response,path.open('xb') as out:
            while True:
                if time.monotonic()>deadline:raise TimeoutError('Update download timed out')
                chunk=response.read(256*1024)
                if not chunk:break
                done+=len(chunk)
                if done>size:raise ValueError('Download exceeds published size')
                out.write(chunk);h.update(chunk)
                if time.monotonic()-last>.15:
                    report(f'Downloading {done/1048576:.1f} / {size/1048576:.1f} MB…',2+43*done/size);last=time.monotonic()
        if done!=size or h.hexdigest()!=digest:raise ValueError('GitHub download checksum or size mismatch')
        report('Download verified…',45)
    except BaseException:
        path.unlink(missing_ok=True);raise
