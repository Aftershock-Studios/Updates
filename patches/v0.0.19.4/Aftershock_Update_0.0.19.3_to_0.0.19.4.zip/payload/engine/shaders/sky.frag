#version 330 core
in vec2 uv;out vec4 frag;
uniform mat4 u_inverse_vp;uniform vec3 u_camera,u_sun,u_sun_color;uniform float u_day,u_cloud,u_time,u_flash;
float as_hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float as_cloudNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(as_hash(i),as_hash(i+vec2(1,0)),f.x),mix(as_hash(i+vec2(0,1)),as_hash(i+1.),f.x),f.y);}
float as_cloudField(vec2 p){float sum=0.,a=.55;mat2 rot=mat2(.8,-.6,.6,.8);for(int i=0;i<5;i++){sum+=as_cloudNoise(p)*a;p=rot*p*2.05+vec2(12.7,8.1);a*=.48;}return sum;}
void main(){
 vec4 p=u_inverse_vp*vec4(uv*2.-1.,1.,1.);vec4 near_p=u_inverse_vp*vec4(uv*2.-1.,-1.,1.);
 vec3 ray=normalize(p.xyz/p.w-(abs(p.w-near_p.w)<.00001?near_p.xyz/near_p.w:u_camera));
 float y=max(ray.y,0.),sd=max(dot(ray,u_sun),0.);
 float twilight=(1.-smoothstep(.02,.38,abs(u_sun.y)))*smoothstep(-.16,.015,u_sun.y);
 vec3 horizon=mix(vec3(.018,.025,.055),vec3(.46,.63,.82),u_day);
 horizon=mix(horizon,vec3(.92,.43,.18),twilight*.65*pow(sd,2.));
 vec3 top=mix(vec3(.003,.007,.025),vec3(.055,.20,.52),u_day);
 vec3 c=mix(horizon,top,pow(y,.48));
 c+=u_sun_color*(pow(sd,12.)*.6+pow(sd,95.)*.35)*u_day*(1.-abs(u_sun.y));
 c+=u_sun_color*smoothstep(.99975,.99993,sd)*8.*u_day;
 vec2 star=vec2(atan(ray.z,ray.x),asin(clamp(ray.y,-1.,1.)))*180.;float h=as_hash(floor(star));
 c+=vec3(step(.997,h)*(1.-smoothstep(.08,.22,length(fract(star)-.5)))*(1.-u_day)*smoothstep(0.,.2,y)*2.);
 vec2 cp=ray.xz/max(.12,ray.y+.13)*2.5+vec2(u_time*.018,u_time*.008);
 float field=as_cloudField(cp), threshold=mix(.78,.35,u_cloud);
 float mask=smoothstep(threshold,threshold+.13,field)*smoothstep(.0,.15,ray.y)*u_cloud;
 float edge=clamp((field-as_cloudField(cp+u_sun.xz*.17))*3.0+.45,0.,1.);
 vec3 cloudDark=mix(vec3(.045,.055,.08),vec3(.24,.30,.37),u_day);
 vec3 cloudLight=mix(vec3(.10,.12,.17),vec3(.83,.87,.92),u_day);
 vec3 cloudColor=mix(cloudDark,cloudLight,edge)*mix(vec3(1.),mix(vec3(1.),u_sun_color,.5),twilight);
 cloudColor+=u_sun_color*pow(sd,18.)*.25*u_day;
 c=mix(c,cloudColor,mask);c+=vec3(.45,.55,.8)*u_flash;frag=vec4(c,1.);
}
