// Native menu and update-check panel, loaded into the existing Studio host.
#import <Cocoa/Cocoa.h>
#include <stdint.h>

static NSPanel *panel;
static NSProgressIndicator *bar;
static NSTextField *heading, *detail;
static NSButton *now, *later;
static NSScrollView *notesScroll;
static NSImageView *mark;
static NSTextView *notes;
static NSInteger menuAction, panelAction;
static NSMenuItem *menuRoot;
static NSPanel *assetPanel;
static NSProgressIndicator *assetBar;
static NSTextField *assetHeading,*assetDetail;
static NSButton *assetNow,*assetLater;
static NSInteger assetAction;
static BOOL assetFinished;
static __weak NSWindow *assetReturn;
static void hideAssets(void) { [assetPanel orderOut:nil]; if(assetReturn.visible) [assetReturn makeKeyAndOrderFront:nil]; }
static __weak NSWindow *returnWindow;
static void hidePanel(void) { [bar stopAnimation:nil]; [panel orderOut:nil]; if(returnWindow.visible) [returnWindow makeKeyAndOrderFront:nil]; }

@interface AftershockUpdateTarget : NSObject <NSWindowDelegate>
- (void)command:(id)sender;
- (void)assetRestart:(id)sender;
- (void)assetDismiss:(id)sender;
- (void)check:(id)sender;
- (void)options:(id)sender;
- (void)install:(id)sender;
- (void)dismiss:(id)sender;
@end
@implementation AftershockUpdateTarget
- (void)command:(id)sender { menuAction=[sender tag]; }
- (void)assetRestart:(id)sender { if(assetFinished && assetNow.enabled){assetAction=1;hideAssets();} }
- (void)assetDismiss:(id)sender { if(assetFinished){assetAction=3;hideAssets();} else {assetAction=2;assetLater.enabled=NO;assetDetail.stringValue=@"Cancelling after the current file…";} }
- (void)check:(id)sender { menuAction=1; }
- (void)options:(id)sender { menuAction=2; }
- (void)install:(id)sender { if(now.enabled && !now.hidden) { panelAction=1; hidePanel(); } }
- (void)dismiss:(id)sender { panelAction=2; hidePanel(); }
- (BOOL)windowShouldClose:(NSWindow *)sender { if(sender==assetPanel)[self assetDismiss:sender];else [self dismiss:sender]; return NO; }
@end
static AftershockUpdateTarget *target;
static NSString *str(const char *s) { return s ? ([NSString stringWithUTF8String:s] ?: @"") : @""; }
static NSTextField *text(NSString *s, NSRect frame, CGFloat size, BOOL bold) {
    NSTextField *v=[NSTextField wrappingLabelWithString:s]; v.frame=frame;
    v.alignment=NSTextAlignmentCenter; v.font=bold?[NSFont boldSystemFontOfSize:size]:[NSFont systemFontOfSize:size];
    return v;
}
static void resizePanel(BOOL found) {
    CGFloat h=found?440:230;
    [panel setContentSize:NSMakeSize(500,h)];
    [panel center];
    heading.frame=NSMakeRect(18,found?325:123,464,found?50:26);
    mark.frame=found?NSMakeRect(224,382,52,52):NSMakeRect(220,157,60,60);
    notesScroll.frame=NSMakeRect(24,59,452,261);
}
static void buildPanel(void) {
    if(panel) return;
    panel=[[NSPanel alloc] initWithContentRect:NSMakeRect(0,0,500,230) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:NO];
    panel.title=@"Aftershock Software Update"; panel.releasedWhenClosed=NO; panel.delegate=target;
    panel.floatingPanel=YES; panel.hidesOnDeactivate=NO;
    NSView *view=panel.contentView;
    mark=[[NSImageView alloc] initWithFrame:NSMakeRect(220,157,60,60)];
    mark.image=NSApp.applicationIconImage; mark.imageScaling=NSImageScaleProportionallyUpOrDown; [view addSubview:mark];
    heading=text(@"Checking for updates…",NSMakeRect(18,123,464,26),19,YES); [view addSubview:heading];
    detail=text(@"",NSMakeRect(24,61,452,57),12,NO); detail.textColor=NSColor.secondaryLabelColor; [view addSubview:detail];
    bar=[[NSProgressIndicator alloc] initWithFrame:NSMakeRect(45,70,410,14)]; bar.style=NSProgressIndicatorStyleBar;
    bar.indeterminate=YES; bar.usesThreadedAnimation=YES; [view addSubview:bar];
    notesScroll=[[NSScrollView alloc] initWithFrame:NSMakeRect(24,59,452,278)];
    notesScroll.hasVerticalScroller=YES; notesScroll.borderType=NSBezelBorder; notesScroll.autohidesScrollers=YES;
    notes=[[NSTextView alloc] initWithFrame:notesScroll.contentView.bounds]; notes.editable=NO; notes.selectable=YES;
    notes.richText=NO; notes.font=[NSFont systemFontOfSize:13]; notes.textContainerInset=NSMakeSize(9,8);
    notes.minSize=NSMakeSize(0,261); notes.maxSize=NSMakeSize(CGFLOAT_MAX,CGFLOAT_MAX); notes.autoresizingMask=NSViewWidthSizable; notes.verticallyResizable=YES; notes.horizontallyResizable=NO;
    notes.textContainer.widthTracksTextView=YES; notes.textContainer.containerSize=NSMakeSize(452,CGFLOAT_MAX);
    notesScroll.documentView=notes; notesScroll.hidden=YES; [view addSubview:notesScroll];
    now=[NSButton buttonWithTitle:@"Update Now" target:target action:@selector(install:)]; now.frame=NSMakeRect(346,13,136,32); now.bezelStyle=NSBezelStyleRounded; [view addSubview:now];
    later=[NSButton buttonWithTitle:@"Update Later" target:target action:@selector(dismiss:)]; later.frame=NSMakeRect(196,13,144,32); later.bezelStyle=NSBezelStyleRounded; [view addSubview:later];
}
static void addMenu(NSMenu *main,NSString *title,NSArray *names,NSArray *tags) {
    NSMenuItem *root=[[NSMenuItem alloc] initWithTitle:title action:NULL keyEquivalent:@""];
    NSMenu *sub=[[NSMenu alloc] initWithTitle:title];sub.autoenablesItems=NO;
    for(NSUInteger i=0;i<names.count;i++) {
        NSInteger tag=[tags[i] integerValue];
        if(!tag){[sub addItem:NSMenuItem.separatorItem];continue;}
        NSMenuItem *item=[[NSMenuItem alloc] initWithTitle:names[i] action:@selector(command:) keyEquivalent:@""];
        item.tag=tag;item.target=target;[sub addItem:item];
    }
    root.submenu=sub;[main addItem:root];
}
static void buildAssets(void) {
    if(assetPanel)return;
    assetPanel=[[NSPanel alloc] initWithContentRect:NSMakeRect(0,0,520,290) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:NO];
    assetPanel.title=@"Aftershock Asset Downloads";assetPanel.delegate=target;assetPanel.releasedWhenClosed=NO;assetPanel.floatingPanel=YES;assetPanel.hidesOnDeactivate=NO;
    NSView *view=assetPanel.contentView;
    assetHeading=text(@"Downloading assets…",NSMakeRect(20,240,480,30),19,YES);[view addSubview:assetHeading];
    assetDetail=text(@"Preparing downloads…",NSMakeRect(25,72,470,157),13,NO);assetDetail.textColor=NSColor.secondaryLabelColor;[view addSubview:assetDetail];
    assetBar=[[NSProgressIndicator alloc] initWithFrame:NSMakeRect(30,55,460,14)];assetBar.style=NSProgressIndicatorStyleBar;assetBar.indeterminate=NO;assetBar.minValue=0;assetBar.maxValue=100;[view addSubview:assetBar];
    assetNow=[NSButton buttonWithTitle:@"Restart Now" target:target action:@selector(assetRestart:)];assetNow.frame=NSMakeRect(365,12,135,32);assetNow.bezelStyle=NSBezelStyleRounded;[view addSubview:assetNow];
    assetLater=[NSButton buttonWithTitle:@"Cancel" target:target action:@selector(assetDismiss:)];assetLater.frame=NSMakeRect(213,12,145,32);assetLater.bezelStyle=NSBezelStyleRounded;[view addSubview:assetLater];
}
void aftershock_asset_begin(int count) {
    @autoreleasepool { if(!target)target=[AftershockUpdateTarget new];buildAssets();assetAction=0;assetFinished=NO;assetHeading.stringValue=[NSString stringWithFormat:@"Downloading %d asset(s)…",count];assetDetail.stringValue=@"Preparing downloads…";assetBar.hidden=NO;assetBar.doubleValue=0;assetNow.hidden=YES;assetNow.enabled=NO;assetLater.enabled=YES;assetLater.title=@"Cancel";assetLater.keyEquivalent=@"\e";assetReturn=NSApp.keyWindow;[assetPanel center];[assetPanel makeKeyAndOrderFront:nil]; }
}
void aftershock_asset_progress(double fraction,const char *message) { @autoreleasepool { if(assetPanel.visible && !assetFinished){assetBar.doubleValue=100*fraction;assetDetail.stringValue=str(message);} } }
void aftershock_asset_result(int count,const char *message) {
    @autoreleasepool { if(!assetPanel.visible)return;assetFinished=YES;assetHeading.stringValue=[NSString stringWithFormat:@"%d asset(s) installed",count];assetDetail.stringValue=[NSString stringWithFormat:@"%@\n\n%@",str(message),count?@"Restart Studio to refresh all assets.":@"No new assets were installed."];assetBar.hidden=YES;assetNow.hidden=count==0;assetNow.enabled=count>0;assetNow.keyEquivalent=count?@"\r":@"";assetLater.title=count?@"Restart Later":@"OK";assetLater.enabled=YES;assetLater.keyEquivalent=count?@"\e":@"\r"; }
}
int aftershock_asset_action(void) { NSInteger a=assetAction;assetAction=0;return (int)a; }
void aftershock_asset_close(void) { if(assetPanel.visible)hideAssets();assetAction=0; }
// Must be called on the main thread, after GLFW has created its menu.
int aftershock_install_menu(void) {
    @autoreleasepool {
        if(!target) target=[AftershockUpdateTarget new];
        NSMenu *main=NSApp.mainMenu; if(!main) return 0;
        if(menuRoot && [main.itemArray containsObject:menuRoot]) return 1;
        menuRoot=[[NSMenuItem alloc] initWithTitle:@"Updates" action:NULL keyEquivalent:@""];
        NSMenu *submenu=[[NSMenu alloc] initWithTitle:@"Updates"]; submenu.autoenablesItems=NO;
        NSMenuItem *check=[[NSMenuItem alloc] initWithTitle:@"Check for Updates…" action:@selector(check:) keyEquivalent:@""]; check.target=target; [submenu addItem:check];
        [submenu addItem:NSMenuItem.separatorItem];
        NSMenuItem *settings=[[NSMenuItem alloc] initWithTitle:@"Update Options…" action:@selector(options:) keyEquivalent:@""]; settings.target=target; [submenu addItem:settings];
        addMenu(main,@"Project",@[@"New Scene",@"Open…",@"Open Template…",@"",@"Save",@"Save As…",@"Save All Scripts",@"",@"Export Game…"],@[@10,@11,@12,@0,@13,@14,@15,@0,@16]);
        addMenu(main,@"Transform",@[@"Undo",@"Redo"],@[@20,@21]);
        addMenu(main,@"Scene",@[@"3D Scene",@"Luau Scripts",@"Terrain",@"World Tools",@"Weather…",@"Toggle Audio",@"Human Generator…"],@[@30,@31,@32,@33,@34,@35,@36]);
        addMenu(main,@"Assets",@[@"Project Library",@"Marketplace",@"Import Models…",@"Downloaded Materials",@"Import PBR Maps…"],@[@40,@41,@42,@43,@44]);
        addMenu(main,@"View",@[@"Graphics Settings…",@"Output",@"",@"Perspective",@"Top",@"Front",@"Side"],@[@50,@51,@0,@52,@53,@54,@55]);
        menuRoot.submenu=submenu; [main addItem:menuRoot]; return 1;
    }
}
int aftershock_menu_action(void) { NSInteger a=menuAction; menuAction=0; return (int)a; }
int aftershock_panel_action(void) { NSInteger a=panelAction; panelAction=0; return (int)a; }
void aftershock_check_begin(const char *version, const char *repo) {
    @autoreleasepool {
        if(!target) target=[AftershockUpdateTarget new]; buildPanel(); panelAction=0;
        resizePanel(NO); notesScroll.hidden=YES; detail.hidden=NO; heading.stringValue=@"Checking for updates…";
        detail.stringValue=[NSString stringWithFormat:@"Aftershock %@  •  %@",str(version),str(repo)]; detail.frame=NSMakeRect(24,90,452,29);
        now.hidden=YES; now.enabled=NO; now.keyEquivalent=@""; later.title=@"Cancel"; later.keyEquivalent=@"\e"; later.frame=NSMakeRect(346,13,136,32);
        bar.hidden=NO; bar.indeterminate=YES; [bar startAnimation:nil];
        returnWindow=NSApp.keyWindow; [panel center]; [panel makeKeyAndOrderFront:nil]; [NSApp activateIgnoringOtherApps:YES];
    }
}
void aftershock_check_result(int found, const char *title, const char *message) {
    @autoreleasepool {
        if(!panel || !panel.visible) return;
        [bar stopAnimation:nil]; bar.hidden=YES;
        resizePanel(found); heading.stringValue=str(title); detail.hidden=found;
        notesScroll.hidden=!found;
        if(found){notes.string=str(message);[notes scrollRangeToVisible:NSMakeRange(0,0)];}
        else {detail.stringValue=str(message); detail.frame=NSMakeRect(24,55,452,64);}
        now.hidden=!found; now.enabled=found; now.keyEquivalent=found?@"\r":@"";
        later.title=found?@"Update Later":@"OK"; later.frame=found?NSMakeRect(196,13,144,32):NSMakeRect(346,13,136,32); later.keyEquivalent=found?@"\e":@"\r";
        [panel makeKeyAndOrderFront:nil];
    }
}
void aftershock_check_raise(void) { if(panel && panel.visible) [panel makeKeyAndOrderFront:nil]; }
void aftershock_check_close(void) { if(panel && panel.visible) hidePanel(); panelAction=0; }
