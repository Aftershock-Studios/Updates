"""Bounded open-world prototype: road authoring, traffic, pedestrians and driving.
World coordinates are X/Z metres. Traffic and driving are kinematic, not Bullet vehicles.
Runtime objects are transient render batches, never added to the editable scene.
"""
from dataclasses import dataclass
import math, random, heapq
import numpy as np
from .ecs import Scene,Transform,Mesh
from .physics import Body
from .visibility import pack
from .character import Character
from .human import visual_batches, detail_level
from .city_collision import car_footprint,person_footprint,obstructed

PRESETS={'Compact':(1250.,31.,9.5,2.55),'Sport':(1450.,53.,14.,2.75),'Utility':(2100.,26.,7.,3.1)}

def finite(v):
    v=float(v)
    if not math.isfinite(v) or abs(v)>10000:raise ValueError('Coordinate outside supported range')
    return v

def validate(data):
    if data is None:return None
    roads=data.get('roads',[])
    if not isinstance(roads,list) or len(roads)>128:raise ValueError('Maximum 128 roads')
    clean=[]
    for road in roads:
        points=road['points']; width=float(road.get('width',10))
        if not 4<=width<=24 or not 2<=len(points)<=64:raise ValueError('Invalid road width or points')
        points=[tuple(map(finite,p)) for p in points]
        if any(len(p)!=2 for p in points) or any(math.dist(a,b)<1 for a,b in zip(points,points[1:])):raise ValueError('Road needs distinct X/Z points')
        if sum(math.dist(a,b) for a,b in zip(points,points[1:]))>3000:raise ValueError('Road too long')
        entry={'points':points,'width':width}
        if isinstance(road.get('entity'),str):entry['entity']=road['entity']
        clean.append(entry)
    if sum(len(r['points'])-1 for r in clean)>512 or sum(math.dist(a,b) for r in clean for a,b in zip(r['points'],r['points'][1:]))>30000:raise ValueError('Road network budget exceeded')
    counts=[int(data.get(k,d)) for k,d in [('traffic',12),('pedestrians',16)]]
    if not 0<=counts[0]<=40 or not 0<=counts[1]<=48:raise ValueError('Traffic 0–40; pedestrians 0–48')
    preset=data.get('vehicle','Compact')
    if preset not in PRESETS:raise ValueError('Unknown vehicle preset')
    return dict(roads=clean,traffic=counts[0],pedestrians=counts[1],vehicle=preset,seed=int(data.get('seed',42)))

def height(scene,x,z):return float(scene.terrain.height(x,z)) if scene.terrain is not None else 0.

def box(scene,name,pos,scale,color,rotation=0,material=(.8,0,0,0),parent=None,solid=False,kind="cube"):
    eid=scene.create(name,Transform(tuple(pos),(0,rotation,0),tuple(scale)),Mesh(color,kind=kind,material=material),parent)
    if solid:scene.set_body(eid,Body())
    return eid

def add_road(scene,points,width=10):
    city=validate(scene.city or {}); road=validate({'roads':[{'points':points,'width':width}]})['roads'][0]; city['roads'].append(road);city=validate(city)
    if scene.terrain is not None:
        for a,b in zip(road['points'],road['points'][1:]):
            samples=[height(scene,a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t) for t in np.linspace(0,1,9)]
            if max(samples)-min(samples)>.25:raise ValueError('Flatten the terrain along the road before construction')
    parent=scene.create('Road '+str(len(city['roads'])));city['roads'][-1]['entity']=parent
    for a,b in zip(road['points'],road['points'][1:]):
        dx,dz=b[0]-a[0],b[1]-a[1]; length=math.hypot(dx,dz); yaw=math.degrees(math.atan2(dx,dz));x,z=(a[0]+b[0])/2,(a[1]+b[1])/2;y=height(scene,x,z)
        box(scene,'Asphalt',(x,y+.06,z),(width,.12,length+.05),(.48,.48,.48),yaw,(.9,0,0,11),parent,True)
        for s in (-1,1):
            side=np.array([dz,-dx])/length*s*(width/2+1.15)
            box(scene,'Footpath',(x+side[0],y+.13,z+side[1]),(2.3,.26,length),(.65,.65,.65),yaw,(.9,0,0,10),parent,True)
        for n in range(int(length//8)):
            t=(n*8+4)/length
            box(scene,'Lane marking',(a[0]+dx*t,y+.128,a[1]+dz*t),(.15,.02,3.5),(.96,.88,.60),yaw,parent=parent)
    scene.city=city;scene.revision+=1
    return parent

def demo(seed=42):
    scene=Scene('Living District');rng=random.Random(seed);scene.city=validate({'seed':seed})
    box(scene,'Ground',(0,-.3,0),(240,.6,240),(.23,.33,.19),solid=True)
    for x in (-64,0,64):
        for a,b in [(-64,0),(0,64)]:add_road(scene,[(x,a),(x,b)])
    for z in (-64,0,64):
        for a,b in [(-64,0),(0,64)]:add_road(scene,[(a,z),(b,z)])
    for x in (-32,32):
        for z in (-32,32):
            for dx in (-11,11):
                for dz in (-11,11):
                    h=rng.uniform(7,25);box(scene,'Building',(x+dx,h/2,z+dz),(15,h,15),rng.choice([(.52,.58,.62),(.66,.60,.51),(.44,.51,.56)]),material=(.75,0,0,1),solid=True)
    for x in (-64,0,64):
        for z in (-64,0,64):
            box(scene,'Signal pole',(x+7,2,z+7),(.16,4,.16),(.17,.18,.19),solid=True)
    for x in (-51,-13,13,51):
        for z in (-51,-13,13,51):
            box(scene,'Tree trunk',(x,1.6,z),(.42,3.2,.42),(.38,.23,.14),solid=True,kind='builtin:tree_trunk')
            for dx,dz,s in [(0,0,3.4),(-.9,.2,2.5),(.7,-.5,2.7)]:box(scene,'Tree canopy',(x+dx,3.2+s*.3,z+dz),(s,s*.85,s),(.20,.43,.15),kind='builtin:tree_crown')
    # Small accessible shop near the start point. Separate colliders leave a real opening.
    x,z=12,-8
    box(scene,'Shop floor',(x,.07,z),(7,.14,8),(.52,.54,.56),solid=True)
    for dx in (-3.4,3.4):box(scene,'Shop side wall',(x+dx,1.65,z),(.20,3.2,8),(.60,.63,.65),solid=True)
    box(scene,'Shop back wall',(x,1.65,z-3.9),(7,3.2,.20),(.60,.63,.65),solid=True)
    for dx in (-2.1,2.1):box(scene,'Shop front wall',(x+dx,1.65,z+3.9),(2.8,3.2,.20),(.54,.57,.60),solid=True)
    box(scene,'Shop lintel',(x,2.85,z+3.9),(1.4,.8,.20),(.54,.57,.60),solid=True)
    box(scene,'Shop roof',(x,3.35,z),(7.3,.25,8.3),(.26,.28,.30),solid=True)
    box(scene,'Counter',(x-2.2,.65,z-1.6),(1.2,1.3,3),(.58,.40,.24),solid=True,material=(.8,0,0,13))
    d=box(scene,'Shop door',(x,1.13,z+3.9),(1.35,2.0,.15),(.23,.34,.43));from .interactions import register;register(scene,d)
    return scene

class RoadGraph:
    def __init__(self,roads):
        self.links={}
        for r in roads:
            for a,b in zip(r['points'],r['points'][1:]):
                a,b=tuple(a),tuple(b);self.links.setdefault(a,set()).add(b);self.links.setdefault(b,set()).add(a)
    def path(self,start,end):
        if start not in self.links or end not in self.links:return []
        q=[(0.,start)];dist={start:0.};prev={}
        while q:
            d,n=heapq.heappop(q)
            if d!=dist[n]:continue
            if n==end:
                result=[n]
                while n in prev:n=prev[n];result.append(n)
                return result[::-1]
            for other in sorted(self.links[n]):
                v=d+math.dist(n,other)
                if v<dist.get(other,math.inf):dist[other]=v;prev[other]=n;heapq.heappush(q,(v,other))
        return []

@dataclass
class Car:
    x:float;z:float;heading:float=0.;speed:float=0.;steer:float=0.;gear:int=1;rpm:float=850.;wheel:float=0.;pitch:float=0.;roll:float=0.
    preset:str='Compact';color:tuple=(.12,.34,.68)
    def drive(self,throttle,steer,brake,dt,wet=0.,blocked=None):
        mass,top,accel,wheelbase=PRESETS[self.preset];throttle=max(-1.,min(1.,throttle));steer=max(-1.,min(1.,steer));dt=min(.1,max(0.,dt))
        self.steer+=(steer-self.steer)*min(1,dt*7);grip=1-.42*max(0,min(1,wet)); old=self.speed
        if brake:self.speed=math.copysign(max(0,abs(self.speed)-13*grip*dt),self.speed)
        else:
            force=accel*throttle*(1-min(.95,abs(self.speed)/top)) if throttle*self.speed>=0 else 13*throttle
            self.speed+=force*dt;self.speed*=max(0,1-dt*(.12+.006*abs(self.speed)));self.speed=max(-8,min(top,self.speed))
        if abs(self.speed)<.035:self.speed=0.
        old_heading=self.heading;self.heading+=self.speed/wheelbase*math.tan(self.steer*.52/(1+abs(self.speed)*.055))*grip*dt
        nx=self.x+math.sin(self.heading)*self.speed*dt;nz=self.z+math.cos(self.heading)*self.speed*dt
        if blocked and blocked((self.x,self.z),(nx,nz)):self.speed=0.;self.heading=old_heading
        else:self.x,self.z=nx,nz
        self.gear=-1 if self.speed<-.1 else min(6,1+int(abs(self.speed)/6));self.rpm=850+abs(self.speed)*700/max(1,abs(self.gear));self.wheel+=self.speed*dt/.35
        self.pitch+=(max(-.09,min(.09,(old-self.speed)*.05))-self.pitch)*min(1,dt*8);self.roll+=(-self.steer*min(.12,abs(self.speed)*.01)-self.roll)*min(1,dt*8)

class Agent:
    def __init__(self,route,speed,offset):self.route=route;self.index=0;self.u=0.;self.speed=speed;self.offset=offset;self.wait=0.;self.position=route[0];self.heading=0.
    def step(self,dt,clock,traffic=False,hold=False):
        if len(self.route)<2:return
        count=len(self.route)
        def segment(i):
            a,b=self.route[i%count],self.route[(i+1)%count];dx,dz=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dz)
            return a,b,dx,dz,max(length,.001)
        a,b,dx,dz,length=segment(self.index);self.heading=math.atan2(dx,dz);remain=length-self.u
        red=(int(clock//8)%2==0)==(abs(dx)>abs(dz))
        speed=0. if hold or (traffic and red and remain<5) else self.speed
        self.u+=speed*max(0.,dt)
        for _ in range(count):
            if self.u<length:break
            self.u-=length;self.index=(self.index+1)%count;a,b,dx,dz,length=segment(self.index)
        self.heading=math.atan2(dx,dz)
        # Shared corner offsets eliminate the previous one-frame teleport at endpoints.
        _,_,px,pz,pl=segment(self.index-1);_,_,nx,nz,nl=segment(self.index+1)
        side=np.array([dz,-dx])/length;start=(side+np.array([pz,-px])/pl)*.5;end=(side+np.array([nz,-nx])/nl)*.5
        span=min(7.,length*.4);t=min(1.,self.u/span);u=min(1.,(length-self.u)/span)
        offset=(start*(1-t)+side*t) if t<1 else (end*(1-u)+side*u)
        self.position=(a[0]+dx*self.u/length+offset[0]*self.offset,a[1]+dz*self.u/length+offset[1]*self.offset)

class CityRuntime:
    def __init__(self,scene):
        self.scene=scene;self.settings=validate(scene.city);self.graph=RoadGraph(self.settings['roads']);self.time=0.;self.acc=0.;self.cars=[];self.people=[];self.driver=None;self.parked=[];self.rig_cache={};self.visual_cache={};self.rng=random.Random(self.settings['seed']);nodes=sorted(self.graph.links)
        if nodes:
            for n in range(self.settings['traffic']+self.settings['pedestrians']):
                a=nodes[n%len(nodes)]; b=nodes[(n*3+1)%len(nodes)];path=self.graph.path(a,b)
                if len(path)<2:path=[a,sorted(self.graph.links[a])[0]]
                route=path+path[-2:0:-1];traffic=n<self.settings['traffic'];agent=Agent(route,self.rng.uniform(5,10) if traffic else self.rng.uniform(.8,1.7),2.5 if traffic else 6.1)
                agent.u=0.;agent.step(0,0);agent.u=min(math.dist(route[0],route[1])*.8,(n//len(nodes))*9.);agent.step(0,0)
                if traffic:self.cars.append((agent,Car(*agent.position,heading=agent.heading,preset=self.settings['vehicle'],color=(self.rng.uniform(.18,.7),self.rng.uniform(.18,.7),self.rng.uniform(.18,.7)))))
                else:
                    char=Character(appearance=n+self.settings['seed']);x,z=agent.position;char.position=np.array([x,height(scene,x,z)+.9,z]);char.grounded=True;self.people.append((agent,char))
            x,z=nodes[len(nodes)//2];self.parked=[Car(x+3,z+9,preset=self.settings['vehicle'])]
    def footprints(self,exclude=None,player=None):
        result=[car_footprint(c) for c in [c for _,c in self.cars]+self.parked if c is not exclude]
        result.extend(person_footprint(a.position) for a,c in self.people if c is not exclude)
        if player is not None:result.append(person_footprint((player[0],player[2])))
        return result
    def proxies(self):
        # Stable runtime keys; never saved into the editing scene.
        for c in [c for _,c in self.cars]+self.parked:
            yield id(c),'car',(c.x,height(self.scene,c.x,c.z)+.83,c.z),c.heading
        for a,c in self.people:
            x,z=a.position;yield id(c),'person',(x,height(self.scene,x,z)+.9,z),a.heading
    def step(self,dt,camera,throttle=0,steer=0,brake=False,wet=0,blocked=None,player=None,solid=None):
        self.time+=dt
        if self.driver:
            initial=car_footprint(self.driver)
            def collision(a,b):
                if blocked and blocked(a,b):return True
                if math.dist(a,b)>1e-6 and abs(height(self.scene,*a)-height(self.scene,*b))>math.dist(a,b)*.75:return True
                return obstructed(initial,car_footprint(self.driver,b),self.footprints(self.driver,player)) or bool(solid and solid('car',b,self.driver.heading))
            self.driver.drive(throttle,steer,brake,dt,wet,collision)
        self.acc+=dt
        if self.acc<.1:return
        tick=self.acc;self.acc=0.
        for agent,car in self.cars:
            forward=np.array([math.sin(agent.heading),math.cos(agent.heading)]);here=np.array(agent.position)
            hold=any(other is not agent and 0<float((np.asarray(other.position)-here)@forward)<5 and abs(float((np.asarray(other.position)-here)@np.array([forward[1],-forward[0]])))<1.8 for other,_ in self.cars)
            old=(car.x,car.z);state=(agent.index,agent.u,agent.position,agent.heading);agent.step(tick,self.time,True,hold)
            if obstructed(car_footprint(car),car_footprint(car,agent.position,agent.heading),self.footprints(car,player)) or (solid and agent.position!=old and solid('car',agent.position,agent.heading)):
                agent.index,agent.u,agent.position,agent.heading=state
            car.x,car.z=agent.position;car.heading=agent.heading;car.speed=math.dist(old,agent.position)/tick;car.wheel+=car.speed*tick/.35
        for agent,char in self.people:
            state=(agent.index,agent.u,agent.position,agent.heading);agent.step(tick,self.time);x,z=agent.position
            if obstructed(person_footprint(state[2]),person_footprint(agent.position),self.footprints(char,player)) or (solid and agent.position!=state[2] and solid('person',agent.position,agent.heading)):
                agent.index,agent.u,agent.position,agent.heading=state;x,z=agent.position
            if (x-camera[0])**2+(z-camera[2])**2<100**2:
                speed=math.dist(state[2],agent.position)/max(tick,1e-6)
                v=np.array([math.sin(agent.heading)*speed,0,math.cos(agent.heading)*speed]);char.velocity=v;char.animate((x,height(self.scene,x,z)+.9,z),v,True,tick);self.rig_cache[id(char)]=char.batches();self.visual_cache.pop(id(char),None)
    def exit_position(self,solid=None):
        if not self.driver:return None
        c=self.driver;s,co=math.sin(c.heading),math.cos(c.heading)
        for x,z in [(c.x+co*2.1,c.z-s*2.1),(c.x-co*2.1,c.z+s*2.1),(c.x-s*3,c.z-co*3)]:
            p=person_footprint((x,z))
            from .city_collision import penetration
            if not any(penetration(p,o)>0 for o in self.footprints()) and not (solid and solid('person',(x,z),0)):
                return x,height(self.scene,x,z)+.95,z
        return None
    def enter(self,position):
        if not self.parked:return False
        car=min(self.parked,key=lambda c:math.hypot(c.x-position[0],c.z-position[2]))
        if math.hypot(car.x-position[0],car.z-position[2])>5:return False
        self.driver=car;return True
    def exit(self):car=self.driver;self.driver=None;return car
    def batches(self,camera,human_detail=True,quality="Medium"):
        mats=[];cols=[];surfaces=[];rigs={};shapes={}
        def part(car,local,scale,color,mat=(.7,.1,0,0),yaw=0,kind=None,spin=0):
            x,y,z=local;s,c=math.sin(car.heading),math.cos(car.heading);base=height(self.scene,car.x,car.z);pos=(car.x+c*x+s*z,base+y,car.z-s*x+c*z);matrix=Transform(pos,(math.degrees(car.pitch)+spin,math.degrees(car.heading)+yaw,math.degrees(car.roll)),scale).matrix()
            if kind:
                a,b,c=shapes.setdefault(kind,([],[],[]));a.append(matrix);b.append(color);c.append(mat)
            else:mats.append(matrix);cols.append(color);surfaces.append(mat)
        for car in [c for _,c in self.cars]+self.parked:
            if (car.x-camera[0])**2+(car.z-camera[2])**2>180**2:continue
            part(car,(0,.66,0),(1.83,.72,4.3),car.color,(.24,.65,0,17),kind="car_body");part(car,(0,1.13,-.25),(1.62,.70,2.2),(.075,.13,.18),(.09,.35,0,18),kind="car_cabin");part(car,(0,1.46,-.25),(1.06,.09,1.43),car.color,(.24,.65,0,17),kind="car_body")
            part(car,(0,.47,2.12),(1.38,.22,.12),(.045,.055,.062),(.42,.3,0,0));part(car,(0,.49,-2.12),(1.40,.16,.11),(.08,.08,.09))
            part(car,(0,.58,-2.18),(.34,.14,.035),(.78,.79,.75))
            for side in (-1,1):
                part(car,(side*.86,1.14,.48),(.24,.14,.24),car.color,(.24,.65,0,17),kind='car_mirror')
                part(car,(side*.921,.84,-.34),(.025,.055,.25),(.095,.105,.12),(.3,.65,0,0))
                part(car,(side*.92,.52,0),(.03,.055,1.6),(.085,.09,.095))
                for z in (-1.35,1.35):
                    yaw=math.degrees(car.steer*.4) if z>0 else 0;spin=math.degrees(car.wheel)%360
                    part(car,(side*.91,.35,z),(.29,.69,.69),(.045,.045,.05),yaw=yaw,kind='car_wheel',spin=spin)
                    part(car,(side*1.055,.35,z),(.035,.36,.36),(.42,.45,.48),(.35,.8,0,0),yaw=yaw,kind='car_wheel',spin=spin)
                part(car,(side*.62,.69,2.16),(.45,.18,.08),(.92,.92,.79),(.4,0,2,0));part(car,(side*.62,.69,-2.16),(.43,.18,.08),(.8,.08,.06),(.4,0,1,0))
        for node in self.graph.links:
            if len(self.graph.links[node])<3:continue
            x,z=node
            if (x-camera[0])**2+(z-camera[2])**2>150**2:continue
            signal=Car(x+7,z+7);green=int(self.time//8)%2==0
            for idx,col in enumerate([(.1,.85,.15) if green else (.02,.10,.02),(.95,.08,.06) if not green else (.12,.02,.02)]):part(signal,(0,3.7+idx*.28,0),(.24,.24,.24),col,(.5,0,2,0))
        for agent,char in self.people:
            x,z=agent.position
            if (x-camera[0])**2+(z-camera[2])**2>70**2:continue
            level=detail_level(math.hypot(x-camera[0],z-camera[2]),quality,human_detail);cached=self.visual_cache.get(id(char))
            if cached is None or cached[0]!=level:
                cached=(level,visual_batches(char,level,self.rig_cache.get(id(char))));self.visual_cache[id(char)]=cached
            for k,v in cached[1].items():rigs.setdefault(k,[]).append(v)
        for k,(a,b,c) in shapes.items():rigs.setdefault(k,[]).append(pack(a,b,c)[0])
        return pack(mats,cols,surfaces)[0],{k:np.concatenate(v) for k,v in rigs.items()}
