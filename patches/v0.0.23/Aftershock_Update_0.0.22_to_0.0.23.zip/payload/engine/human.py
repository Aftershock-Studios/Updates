"""Seeded adult character generator and shared, distance-scaled anatomical meshes.

Visual-only: the existing movement, animation and physics capsule remain authoritative.
All geometry is original procedural data in metres via the existing rig transforms.
"""
from dataclasses import dataclass
from functools import lru_cache
import math, random
import numpy as np
from .character import PROFILES
from .visibility import pack

@dataclass(frozen=True)
class Profile:
    seed:int
    height:float
    build:float
    shoulders:float
    hips:float
    head_width:float
    head_depth:float
    face:int
    hair_style:int
    skin:tuple
    hair:tuple
    iris:tuple
    shirt:tuple
    trousers:tuple
    shoes:tuple
    blink_offset:float

@lru_cache(maxsize=256)
def profile(seed=0):
    if type(seed) is not int or not 0<=seed<=2**31-1:raise ValueError('Human seed must be an integer from 0 to 2147483647')
    r=random.Random(seed)
    # Independent phenotypes; appearance does not infer identity or ethnicity.
    skin=r.choice([(.87,.70,.59),(.78,.59,.46),(.68,.48,.34),(.53,.35,.25),(.37,.235,.16),(.29,.19,.14)])
    skin=tuple(min(.95,max(.09,v*r.uniform(.94,1.06))) for v in skin)
    return Profile(seed,r.uniform(.96,1.045),r.uniform(.87,1.13),r.uniform(.92,1.10),r.uniform(.91,1.10),r.uniform(.92,1.09),r.uniform(.93,1.07),r.randrange(3),r.randrange(4),skin,r.choice([(.11,.08,.065),(.22,.14,.09),(.38,.24,.13),(.52,.37,.20),(.31,.30,.29)]),r.choice([(.16,.095,.052),(.13,.18,.12),(.24,.35,.42),(.27,.21,.12),(.095,.067,.043)]),r.choice([(.23,.36,.45),(.36,.18,.15),(.52,.49,.40),(.19,.22,.24),(.26,.41,.25),(.68,.65,.60),(.37,.28,.43)]),r.choice([(.19,.24,.32),(.29,.27,.23),(.18,.19,.21),(.37,.32,.26)]),r.choice([(.13,.15,.18),(.21,.17,.13),(.68,.66,.62)]),r.uniform(0,5))

def detail_level(distance,quality='Medium',enabled=True):
    near,mid={'Low':(5,16),'Medium':(10,28),'High':(17,40),'Ultra':(26,55)}.get(quality,(10,28))
    if not enabled:return 2
    return 0 if distance<near else 1 if distance<mid else 2

# Normalized face at +Z. Carefully place anatomical landmarks on a single head surface.
_FACE=np.array([(-.5,.26,.44,-.04),(-.46,.53,.67,.005),(-.37,.72,.81,.015),(-.25,.87,.92,.02),(-.10,.96,1.,-.015),(.07,.99,.99,-.024),(.22,1.,.97,-.034),(.35,.90,.87,-.046),(.45,.65,.66,-.045),(.5,.18,.22,-.045)])

def face_offset(x,y,variant):
    def g(cx,cy,wx,wy):return np.exp(-((x-cx)/wx)**2-((y-cy)/wy)**2)
    nose=(.155,.19,.125)[variant]
    z=nose*g(0,-.075,.105,.105)+.078*g(0,.045,.087,.17)
    z+=.029*(g(-.095,-.105,.055,.047)+g(.095,-.105,.055,.047))
    z-=.083*(g(-.213,.075,.118,.078)+g(.213,.075,.118,.078))
    z+=.034*(g(-.245,.16,.14,.055)+g(.245,.16,.14,.055))
    z+=.046*(g(-.29,-.067,.15,.10)+g(.29,-.067,.15,.10))
    z+=.045*g(0,-.228,.22,.072)+.025*g(0,-.274,.19,.06)+.032*g(0,-.398,.19,.07)
    z-=.018*g(0,-.17,.045,.062)
    return z

def front_z(x,y,variant):
    w,d,offset=(np.interp(y,_FACE[:,0],_FACE[:,j]) for j in (1,2,3))
    sine=np.sqrt(max(0.,1-(x/max(.001,.5*w))**2))
    return offset+.5*d*sine+float(face_offset(x,y,variant))*sine**2

def _rings(rows,sides,kind,variant=0):
    """Indexed closed mesh with area-weighted smooth normals and consistent winding."""
    y,w,d,off=np.asarray(rows).T
    theta=np.arange(sides)*math.tau/sides
    co,si=np.cos(theta),np.sin(theta)
    x=.5*w[:,None]*co;z=.5*d[:,None]*si+off[:,None];Y=np.broadcast_to(y[:,None],x.shape)
    if kind=='head':
        # Local relief follows the front, tapering smoothly before reaching the temples.
        z+=face_offset(x,Y,variant)*np.maximum(si,0.)**2.0
    elif kind=='hair':
        wave=.012*np.sin(theta*17+Y*18)+.008*np.sin(theta*29-Y*22)
        x*=1+wave;z+=wave*np.sign(si)*.45
    elif kind in ('torso','pelvis','thigh','calf','sleeve','forearm'):
        # Shallow cloth gathers and anatomical surface transitions, not repeated spheres.
        fold=.015*np.sin(Y*28+theta*3)+.009*np.sin(Y*51-theta*5)
        x*=1+fold;z+=fold*si*.35
    v=np.column_stack((x.ravel(),Y.ravel(),z.ravel()))
    v=np.vstack((v,[0,y[0],off[0]],[0,y[-1],off[-1]]));n=len(v)
    j=np.arange(sides);a=(np.arange(len(y)-1)[:,None]*sides+j).ravel();b=(np.arange(len(y)-1)[:,None]*sides+(j+1)%sides).ravel();c=a+sides;d=b+sides
    f=np.vstack((np.column_stack((a,c,b)),np.column_stack((b,c,d)),np.column_stack((np.full(sides,n-2),j,(j+1)%sides)),np.column_stack((np.full(sides,n-1),(len(y)-1)*sides+(j+1)%sides,(len(y)-1)*sides+j))))
    normal=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]);vn=np.zeros_like(v)
    for i in range(3):np.add.at(vn,f[:,i],normal)
    vn/=np.maximum(np.linalg.norm(vn,axis=1,keepdims=True),1e-10)
    i=f.ravel();return np.ascontiguousarray(np.column_stack((v[i],vn[i])),dtype='f4')

# Hair shells with different hairlines and volumes; hair tufts stay on the animated scalp.
_HAIR=( [(-.5,.98,.98,-.025),(-.30,1.,1.,-.02),(.12,.95,.93,-.04),(.35,.76,.77,-.035),(.5,.12,.15,-.035)],
        [(-.5,.96,.99,-.035),(-.19,1.,1.,-.025),(.10,1.,.95,-.06),(.38,.73,.79,-.08),(.5,.14,.20,-.07)],
        [(-.5,.88,.9,-.025),(-.27,1.,1.,0),(.11,1.,1.,-.01),(.37,.89,.84,-.04),(.5,.18,.21,-.04)],
        [(-.5,.96,.99,-.045),(-.23,1.,1.,-.025),(.11,.92,.90,-.05),(.37,.71,.69,-.055),(.5,.14,.15,-.05)])
_PARTS=('torso','pelvis','collar','limb','thigh','calf','sleeve','forearm','hand','shoe','sole','joint','finger','eye','ear','lip','brow','tuft')

@lru_cache(maxsize=96)
def geometry(kind,level=0,variant=0):
    if level not in (0,1,2):raise ValueError('Invalid character LOD')
    sides=(24,12,6)[level];rings=(13,7,4)[level]
    if kind=='head':rows=_FACE;sides=(56,24,10)[level];rings=(48,20,7)[level]
    elif kind=='hair':rows=np.asarray(_HAIR[variant]);sides=(28,14,8)[level];rings=(15,8,4)[level]
    elif kind=='ear':rows=np.array([(-.5,.25,.22,0),(-.35,.68,.58,0),(-.06,.96,.9,-.04),(.2,1.,1.,-.06),(.4,.63,.68,-.05),(.5,.2,.25,-.02)])
    elif kind in ('joint','eye','lip','brow','tuft','finger'):
        rows=np.array([(-.5,.025,.025,0),(-.39,.65,.65,0),(-.18,.95,.95,0),(.08,1,1,0),(.3,.82,.82,0),(.5,.025,.025,0)])
        sides=(12,8,6)[level];rings=(7,5,4)[level]
    else:rows=np.asarray(PROFILES[kind][0]);rings=max(len(rows),rings if level==0 else min(rings,12))
    rows=np.asarray(rows);y=np.unique(np.r_[np.linspace(rows[0,0],rows[-1,0],rings),rows[:,0]])
    dense=np.column_stack((y,*[np.interp(y,rows[:,0],rows[:,j]) for j in (1,2,3)]))
    return _rings(dense,sides,kind,variant)

def mesh_keys():
    for level in range(3):
        for kind in _PARTS:yield f'h{level}_{kind}',kind,level,0
        for i in range(3):yield f'h{level}_head{i}','head',level,i
        for i in range(4):yield f'h{level}_hair{i}','hair',level,i

def visual_batches(character,level=0,base=None):
    """Generate an appearance for either the player or any NPC from the same rig."""
    p=profile(int(character.appearance or 0) % 2**31)
    base=character.batches() if base is None else base
    output={};prefix=f'h{level}_';floor=character.position-np.array([0.,.9,0.]);s=math.sin(character.heading);c=math.cos(character.heading);rot=np.array([[c,0,s],[0,1,0],[-s,0,c]])
    body_scale=rot@np.diag([1.,p.height,1.])@rot.T
    def matrix(row):return row[:16].reshape(4,4).T.astype(float).copy()
    def emit(kind,m,col,mat):
        m=m.copy();m[:3,3]=floor+body_scale@(m[:3,3]-floor);m[:3,:3]=body_scale@m[:3,:3]
        output.setdefault(prefix+kind,[]).append((m,col,mat))
    skin=(.54,0,0,16);face=(.49,0,0,21);cloth=(.88,0,0,15);hair=(.62,0,0,19);eye=(.30,0,0,22);plain=(.69,0,0,0)
    def local(parent,xyz,scale,kind,col,mat,angle=0):
        co,si=math.cos(angle),math.sin(angle);a=np.eye(4);a[:3,:3]=np.array([[co,-si,0],[si,co,0],[0,0,1]])@np.diag(scale);a[:3,3]=xyz;emit(kind,parent@a,col,mat)
    adjusted={}
    for kind,rows in base.items():
        if kind in ('head','hair','detail','nose'):continue
        for i,row in enumerate(rows):
            m=matrix(row);col=p.skin if kind in ('limb','forearm','hand') else p.shirt if kind in ('torso','sleeve') else tuple(v*.66 for v in p.shirt) if kind=='collar' else p.trousers if kind in ('pelvis','thigh','calf') else p.shoes if kind=='shoe' else tuple(.32+.4*v for v in p.shoes)
            mat=skin if kind in ('limb','forearm','hand') else cloth if kind in ('torso','sleeve','collar','pelvis','thigh','calf') else plain
            scale=p.build*(p.shoulders if kind=='torso' else p.hips if kind=='pelvis' else 1.) if kind in ('torso','pelvis','thigh','calf','sleeve','forearm') else 1.
            m[:3,0]*=scale;m[:3,2]*=p.build if kind in ('torso','pelvis','thigh','calf','sleeve','forearm') else 1.
            adjusted[kind,i]=m.copy()
            if kind=='hand' and level<2:
                # Palm and fingers follow the existing wrist and hand axis.
                local(m,(0,.17,0),(.88,.66,.94),'hand',p.skin,skin)
                for j,(x,length) in enumerate(zip((-.32,-.11,.11,.31),(.39,.49,.46,.34))):
                    local(m,(x,-.20-length*.18,.035),(.17,length,.51),'finger',p.skin,skin,(j-1.5)*.055)
                local(m,((-.43 if i==0 else .43),.03,.15),(.22,.46,.63),'finger',p.skin,skin,(-.55 if i==0 else .55))
            else:emit(kind,m,col,mat)
    # Cover moving knee/elbow seams with anatomical transition geometry; not a new collider.
    if level<2:
        for i in (0,1):
            for a,b,col,mat in [('thigh','calf',p.trousers,cloth),('sleeve','forearm',p.skin,skin)]:
                upper=adjusted[a,i];lower=adjusted[b,i];pos=(upper[:3,3]-upper[:3,1]*.43+lower[:3,3]+lower[:3,1]*.42)*.5
                m=lower.copy();m[:3,3]=pos;m[:3,0]*=.91;m[:3,1]*=.28;m[:3,2]*=.92;emit('joint',m,col,mat)
    head=matrix(base['head'][0]);head[:3,0]*=p.head_width;head[:3,2]*=p.head_depth
    emit('head'+str(p.face),head,p.skin,face)
    cap=matrix(base['hair'][0]);cap[:3,0]*=p.head_width;cap[:3,2]*=p.head_depth
    # Four hairstyle silhouettes. Shorter caps avoid obscuring the brows and eyes.
    cap[:3,1]*=(.59,.81,1.02,.70)[p.hair_style];cap[:3,3]+=rot@np.array([0,.020,-.008]);emit('hair'+str(p.hair_style),cap,p.hair,hair)
    if level==0 and p.hair_style in (1,2):
        for row in base['hair'][1:]:
            m=matrix(row);m[:3,1]*=(.75 if p.hair_style==1 else 1.05);emit('tuft',m,p.hair,hair)
    if level<2:
        blink=abs((character.breath/2.2+p.blink_offset)%5.3-2.65);opening=.14+.86*min(1.,blink/.11)
        for side in (-1,1):
            x=side*.213;y=.075;z=front_z(x,y,p.face)
            local(head,(side*.495,-.025,-.035),(.21,.25,.25),'ear',p.skin,skin,side*.14)
            local(head,(x,y,z+.012),(.205,.059*opening,.057),'eye',(.84,.80,.76),eye)
            if level==0:
                local(head,(x,y,z+.042),(.068,.052*opening,.018),'eye',p.iris,eye)
                local(head,(x,y,z+.051),(.030,.030*opening,.008),'eye',(.045,.035,.032),eye)
                local(head,(x-.014,y+.013*opening,z+.055),(.014,.011*opening,.004),'eye',(.98,.98,.97),(.18,0,0,22))
            else:local(head,(x,y,z+.039),(.060,.049*opening,.015),'eye',p.iris,eye)
            local(head,(x,.159,front_z(x,.159,p.face)+.009),(.212,.022,.034),'brow',p.hair,hair,side*-.10)
        z=front_z(0,-.247,p.face);lipcol=(min(.92,p.skin[0]*.89+.06),p.skin[1]*.70,p.skin[2]*.76)
        local(head,(0,-.237,z+.013),(.30,.029,.032),'lip',lipcol,skin)
        local(head,(0,-.265,z+.012),(.27,.035,.034),'lip',tuple(min(.95,v*1.08) for v in lipcol),skin)
        local(head,(0,-.249,z+.032),(.29,.009,.007),'lip',tuple(v*.48 for v in lipcol),plain)
        if level==0:
            for side in (-1,1):local(head,(side*.075,-.12,front_z(side*.075,-.12,p.face)+.007),(.047,.020,.010),'eye',tuple(v*.48 for v in p.skin),plain)
    return {k:pack([i[0] for i in rows],[i[1] for i in rows],[i[2] for i in rows])[0] for k,rows in output.items()}
