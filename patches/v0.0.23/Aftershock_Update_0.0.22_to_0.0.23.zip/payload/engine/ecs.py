"""Small entity/component registry. Y-up, metres, Euler angles in degrees."""
from dataclasses import dataclass
import json
import math
from pathlib import Path
import uuid
import numpy as np


def vec3(value):
    result = tuple(float(x) for x in value)
    if len(result) != 3 or not all(math.isfinite(x) for x in result):
        raise ValueError('Expected three finite numbers')
    return result


@dataclass(frozen=True)
class Transform:
    position: tuple = (0., 0., 0.)
    rotation: tuple = (0., 0., 0.)
    scale: tuple = (1., 1., 1.)

    def __post_init__(self):
        for field in ('position', 'rotation', 'scale'):
            object.__setattr__(self, field, vec3(getattr(self, field)))
        if any(x <= 0 for x in self.scale):
            raise ValueError('Scale must be positive')

    def matrix(self):
        x, y, z = map(math.radians, self.rotation)
        cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
        rx = np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]], dtype='f4')
        ry = np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]], dtype='f4')
        rz = np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]], dtype='f4')
        out = np.eye(4, dtype='f4')
        out[:3,:3] = (ry @ rx @ rz) * self.scale
        out[:3,3] = self.position
        return out


@dataclass(frozen=True)
class Mesh:
    color: tuple = (.6,.6,.6)
    kind: str = 'cube'
    material: tuple = (.8, 0., 0., 0.)  # roughness, metallic, emission, pattern

    def __post_init__(self):
        object.__setattr__(self, 'color', vec3(self.color))
        m = tuple(float(v) for v in self.material)
        if len(m) != 4 or not all(math.isfinite(v) for v in m) or not (.04 <= m[0] <= 1 and 0 <= m[1] <= 1 and 0 <= m[2] <= 20 and m[3] in range(15)):
            raise ValueError('Invalid material')
        object.__setattr__(self, 'material', m)
        if self.kind.startswith('builtin:'):
            from .vegetation import GEOMETRY
            if self.kind.split(':',1)[1] not in GEOMETRY:raise ValueError('Unknown built-in mesh')
        elif self.kind != 'cube':
            from .assets import asset_path
            asset_path(self.kind)
        if any(not 0 <= v <= 1 for v in self.color): raise ValueError('RGB must be in [0,1]')


class Scene:
    def __init__(self, name='Scene'):
        self.name = name
        self.names, self.parents, self.transforms, self.meshes, self.spins = {}, {}, {}, {}, {}
        self.children = {None: set()}
        self.bodies = {}
        self.terrain = None
        self.city = None
        self.player_appearance = 0
        self.clips = {}
        self.doors = set()
        from .environment import Environment
        self.environment = Environment(); self.audio_events=[];self.spatial_events=[];self.emitters=[]
        self.revision = 0
        self.tick = 0

    def create(self, name, transform=None, mesh=None, parent=None, spin=None, eid=None):
        eid = uuid.uuid4().hex if eid is None else eid
        if not isinstance(eid, str) or not eid or eid in self.names or (parent is not None and parent not in self.names):
            raise ValueError('Invalid/duplicate entity ID or missing parent')
        transform = transform or Transform()
        if not isinstance(transform, Transform) or (mesh is not None and not isinstance(mesh, Mesh)):
            raise TypeError('Invalid component type')
        spin = None if spin is None else vec3(spin)
        self.names[eid], self.parents[eid], self.transforms[eid] = str(name), parent, transform
        self.children[eid] = set()
        self.children[parent].add(eid)
        if mesh is not None: self.meshes[eid] = mesh
        if spin is not None: self.spins[eid] = spin
        self.revision += 1
        return eid

    def set_transform(self, eid, transform):
        if eid not in self.names or not isinstance(transform, Transform): raise ValueError('Invalid entity/transform')
        self.transforms[eid] = transform
        self.revision += 1

    def set_body(self, eid, body):
        from .physics import Body
        if eid not in self.names: raise ValueError("Unknown entity")
        if body is not None and not isinstance(body, Body): raise TypeError("Expected Body")
        if body is not None and body.kind != "static" and self.parents[eid] is not None: raise ValueError("Dynamic/kinematic bodies must be root entities")
        if body is None or body.kind!='kinematic':self.doors.discard(eid)
        if body is None: self.bodies.pop(eid, None)
        else: self.bodies[eid] = body
        self.revision += 1

    def reparent(self, eid, parent):
        if eid not in self.names or (parent is not None and parent not in self.names): raise ValueError('Unknown entity')
        if parent is not None and eid in self.bodies and self.bodies[eid].kind != "static": raise ValueError("Dynamic/kinematic bodies must be root entities")
        cur = parent
        while cur is not None:
            if cur == eid: raise ValueError('Hierarchy cycle')
            cur = self.parents[cur]
        self.children[self.parents[eid]].remove(eid)
        self.children[parent].add(eid)
        self.parents[eid] = parent
        self.revision += 1

    def destroy(self, eid):
        if eid not in self.names: raise KeyError(eid)
        pending = [eid]
        self.children[self.parents[eid]].remove(eid)
        while pending:
            key = pending.pop()
            pending.extend(self.children.pop(key))
            if self.city is not None:self.city['roads']=[r for r in self.city['roads'] if r.get('entity')!=key]
            self.doors.discard(key)
            for store in (self.names,self.parents,self.transforms,self.meshes,self.spins,self.bodies): store.pop(key,None)
        self.revision += 1

    def step(self, dt):
        for eid, speed in self.spins.items():
            t = self.transforms[eid]
            self.transforms[eid] = Transform(t.position, tuple((r+s*dt)%360 for r,s in zip(t.rotation,speed)), t.scale)
        self.tick += 1

    def ordered(self):
        pending = list(self.children[None])
        while pending:
            eid = pending.pop()
            yield eid
            pending.extend(self.children[eid])

    def to_data(self):
        from dataclasses import asdict
        data = {'version':1, 'name':self.name, 'entities':[]}
        if self.terrain is not None: data['terrain']=self.terrain.data()
        data['environment']=self.environment.data()
        if self.player_appearance:data['player_appearance']=self.player_appearance
        if self.emitters:data['emitters']=self.emitters.copy()
        if self.doors:data['doors']=sorted(self.doors)
        if self.clips:
            from .animation import clip_data
            data['clips']=clip_data(self.clips)
        if self.city is not None:
            from .city import validate
            data['city']=validate(self.city)
        for eid in self.ordered():
            t = self.transforms[eid]
            m = self.meshes.get(eid)
            data['entities'].append(dict(id=eid,name=self.names[eid],parent=self.parents[eid],position=t.position,rotation=t.rotation,scale=t.scale,mesh=None if m is None else dict(kind=m.kind,color=m.color,material=m.material),spin=self.spins.get(eid),body=asdict(self.bodies[eid]) if eid in self.bodies else None))
        return data

    def save(self,path):
        path=Path(path); data=self.to_data()
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix+'.tmp')
        temp.write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')
        temp.replace(path)

    @classmethod
    def load(cls,path):
        return cls.from_data(json.loads(Path(path).read_text(encoding='utf-8')))

    @classmethod
    def from_data(cls,data):
        if data.get('version') != 1: raise ValueError('Unsupported scene version')
        scene = cls(data['name'])
        seed=data.get('player_appearance',0)
        if type(seed) is not int or not 0<=seed<=2**31-1:raise ValueError('Invalid player appearance seed')
        scene.player_appearance=seed
        from .environment import Environment
        scene.environment=Environment(**data.get('environment',{}))
        from .audio import validate_emitter
        if len(data.get('emitters',[]))>32:raise ValueError('Maximum 32 emitters')
        scene.emitters=[validate_emitter(e) for e in data.get('emitters',[])]
        from .animation import load_clips
        scene.clips=load_clips(data.get('clips',{}))
        if data.get('city') is not None:
            from .city import validate
            scene.city=validate(data['city'])
        if data.get('terrain') is not None:
            from .terrain import Terrain
            scene.terrain=Terrain.from_data(data['terrain'])
        # Files written by save() always list parents before children.
        for item in data['entities']:
            m = item['mesh']
            scene.create(item['name'],Transform(item['position'],item['rotation'],item['scale']),None if m is None else Mesh(**m),item['parent'],item['spin'],item['id'])
            if item.get("body") is not None:
                from .physics import Body
                scene.set_body(item["id"],Body(**item["body"]))
        for e in data.get('doors',[]):
            if e not in scene.meshes or scene.parents[e] is not None or e not in scene.bodies or scene.bodies[e].kind!='kinematic':raise ValueError('Invalid door entity')
            scene.doors.add(e)
        return scene
