# Aftershock 0.0.25 — AI World Builder

## Setup (macOS)
1. Install Ollama from https://ollama.com/download and open it. Ollama is a separate local inference application; the model is not bundled.
2. In Terminal run `ollama pull qwen2.5:3b`. You can choose another installed local model with structured-output support using Change model in Studio. Avoid cloud-tagged models for this local-only connector.
3. Open an editable scene, stop Play, and click **AI Chat** in the toolbar.
4. Enter your request, press Return or Send, review the proposed JSON actions (scroll to review the entire plan), then click Apply plan. Discard / Cancel ignores the pending plan; an already-running model request may finish locally before another can be sent.
5. Save the scene normally. Undo/Redo treats a successful plan as one edit. The chat history is session-only.

## Examples
- Build a small suburban neighbourhood on this flat terrain: one 60-metre road, six houses and a park with ten trees. Leave existing objects intact.
- Place 25 trees around X=100, Z=80, within a radius of 20 metres.
- Build a three-storey office block near X=30, Z=40, with a concrete roof.
- Make it rain and set traffic to six cars and pedestrians to twelve.
- Use the imported rock in my project asset library beside the park.

## Scope and safety
The assistant receives a limited, relevance-ranked sample of the scene's named transforms and saved model identifiers, terrain summary, weather and road information, via the local loopback Ollama API. It does not execute scripts, shell commands, arbitrary URLs or direct filesystem edits. It does not generate photorealistic new geometry; it arranges existing geometry, materials and imported models, and creates simple facade/roof building shells, terrain (only when none exists), roads on flat ground, trees, player spawn (if absent) and weather/population changes.

The entire plan is validated on a detached scene before applying. Maximum 40 operations / 500 newly created entities per plan; no arbitrary deletion or terrain replacement. Scene changes made during inference invalidate the proposal. Review geometry and positions manually: the AI does not yet automatically detect intersections, guarantee road connections or generate interiors. Requests may be slow on an 8 GB Mac. Close memory-intensive apps, use lower graphics settings and request small sections. No API key required, but model inference uses your computer's resources. Native Mac UI and actual local model inference require hardware testing.
