# Architect & Spatial Planning — v0.0.26

Open AI Chat after installing the update. No new AI model is required. The local model is still Qwen 2.5 3B by default, but it now plans semantic construction operations, with a larger context window. Its plans are checked on a detached scene before Apply plan is available. If validation fails, one corrective request is sent to Ollama; an invalid corrected plan is rejected. Changes are still one undoable batch and are revalidated before commit.

Try on a new Baseplate scene (away from the existing player spawn):

- Build a six-house suburban neighbourhood centered at X=0 Z=-25. Use 8m wide, 3.2m wall height, 8m deep houses and an 8m road. Use the neighbourhood operation.
- Build a 12m wide, 3.2m high, 8m deep shop at X=30 Z=25 with its front facing south. Use the shop style.
- Plant 12 trees in a clear area with a radius of 20 metres. Keep away from roads.

Architecture includes grouped exteriors, plinths, pitched roofs and triangular gables, trim, individual framed glazing panels, doors, steps, gutters, shop awnings, apartment floor bands and flat roof parapets. The neighbourhood tool builds 2–6 homes facing a shared road, with footpaths and kerbs. It uses procedural geometry and the existing PBR materials, not scanned architecture. Doors/windows are surface details over solid exterior shells; no enterable interiors, functional doors, or transparent window interiors yet.

Placement is conservative: transformed world-space bounding boxes, terrain/baseplate limits, sampled slope/water/foundation height, existing spawn clearance, road and footpath corridors. Roads are processed before independent structures; crossing roads may still require manual junction work. Trees retry seeded candidate positions and reject the plan if the requested count cannot fit. Imported models preserve native proportions by default; explicit dimensions may stretch them. Ground sampling and bounding boxes are approximate, not exact mesh collision or navmesh checks. The 40-action / 500-new-entity caps remain. Existing objects are never deleted or moved by the AI.
