"""Original procedural tree geometry and bounded terrain vegetation batches."""
import math
import numpy as np
from .vehicle_mesh import triangles
from .terrain import surface_ids,STEP
from .ecs import Transform
from .visibility import pack

def profile(rings, sides=9, seed=3):
    rng=np.random.default_rng(seed);points=[]
    for y,r in rings:
        points.append([(math.cos(i*math.tau/sides)*r*rng.uniform(.88,1.12),y,math.sin(i*math.tau/sides)*r*rng.uniform(.88,1.12)) for i in range(sides)])
    faces=[]
    for a,b in zip(points,points[1:]):
        for i in range(sides):j=(i+1)%sides;faces.extend([(a[i],b[i],b[j]),(a[i],b[j],a[j])])
    for i in range(1,sides-1):faces.extend([(points[0][0],points[0][i],points[0][i+1]),(points[-1][0],points[-1][i+1],points[-1][i])])
    return triangles(faces)
GEOMETRY={'tree_trunk':lambda:profile([(-.5,.43),(-.2,.34),(.5,.20)],8,2),'tree_crown':lambda:profile([(-.5,.08),(-.3,.35),(-.06,.43),(.22,.32),(.5,.04)],10,5),'pine_crown':lambda:profile([(-.5,.44),(-.35,.36),(-.35,.40),(-.1,.25),(-.1,.31),(.18,.15),(.18,.21),(.5,.015)],9,8)}

class Forest:
    TILE=64
    def __init__(self):self.terrain=None;self.cache={};self.key=None;self.rows={}
    def patch(self,terrain,key):
        count=18 if terrain.preset=='Forest' else 8 if terrain.preset in ('Tropical','Subtropical','Island','Coastal') else 4
        rng=np.random.default_rng((terrain.seed*29+key[0]*97831+key[1]*43289)&0xffffffff);x=key[0]*self.TILE+rng.uniform(3,self.TILE-3,count);z=key[1]*self.TILE+rng.uniform(3,self.TILE-3,count)
        # Follow the actual sampled terrain triangles at the nearest mesh LOD.
        a=np.floor(x/STEP)*STEP;b=np.floor(z/STEP)*STEP;u=(x-a)/STEP;v=(z-b)/STEP
        h00=terrain.height(a,b);h10=terrain.height(a+STEP,b);h01=terrain.height(a,b+STEP);h11=terrain.height(a+STEP,b+STEP);y=np.where(u+v<=1,h00+(h10-h00)*u+(h01-h00)*v,h11+(h01-h11)*(1-u)+(h10-h11)*(1-v))
        ny=1/np.sqrt(1+((h10-h00)/STEP)**2+((h01-h00)/STEP)**2);ids=surface_ids(terrain,x,z,y,ny)
        keep=(ids==0)&(y>terrain.water+1)&(ny>.86)&(abs(x)<terrain.size/2)&(abs(z)<terrain.size/2)
        return [(float(x[i]),float(y[i]),float(z[i]),float(rng.uniform(3.4,8)),float(rng.uniform(0,360)),float(rng.uniform(.78,1.15))) for i in range(count) if keep[i]]
    def update(self,terrain,position,quality):
        if terrain is not self.terrain:self.cache.clear();self.key=None;self.terrain=terrain
        cx,cz=math.floor(position[0]/self.TILE),math.floor(position[2]/self.TILE);enabled=bool(terrain and terrain.decorations);radius=1 if quality=='Low' else 2 if quality=='Medium' else 3;key=(cx,cz,radius,enabled,quality,math.floor(position[0]/8),math.floor(position[2]/8))
        if key==self.key:return self.rows
        self.key=key;wanted={(x,z) for x in range(cx-radius,cx+radius+1) for z in range(cz-radius,cz+radius+1)} if enabled else set();self.cache={k:v for k,v in self.cache.items() if k in wanted}
        for k in sorted(wanted):
            if k not in self.cache:self.cache[k]=self.patch(terrain,k)
        groups={};trees=sorted([p for v in self.cache.values() for p in v],key=lambda p:(p[0]-position[0])**2+(p[2]-position[2])**2)[:(64 if quality=='Low' else 160 if quality=='Medium' else 260)]
        def add(kind,p,scale,rotation,color,material=0):
            a,b,c=groups.setdefault(kind,([],[],[]));a.append(Transform(p,(0,rotation,0),scale).matrix());b.append(color);c.append((.9,0,0,material))
        for x,y,z,h,angle,tint in trees:
            d=math.hypot(x-position[0],z-position[2]);near,mid={'Low':(12,30),'Medium':(25,65),'High':(40,105),'Ultra':(55,145)}[quality]
            pine=terrain.preset in ('Forest','Alpine','Snow');prefix='pine' if pine else 'tree'
            add('tree_trunk_near' if d<near else 'tree_trunk',(x,y+h*.28,z),(h*.09,h*.56,h*.09),angle,(.55,.43,.32),13)
            kind=prefix+'_leaves_near' if d<near else prefix+'_leaves_mid' if d<mid else 'pine_crown' if pine else 'tree_crown'
            mat=20 if d<mid else 20
            # Three overlapping leaf volumes for a less symmetrical silhouette; cheaper far crowns.
            add(kind,(x,y+h*.70,z),(h*.65,h*.69,h*.65),angle,(.24*tint,.46*tint,.15*tint),mat)
            if not pine:
                add(kind,(x+h*.14,y+h*.79,z),(h*.40,h*.48,h*.42),angle+45,(.30*tint,.50*tint,.18*tint),mat)
                if d<near:add(kind,(x-h*.19,y+h*.65,z+h*.09),(h*.35,h*.43,h*.35),angle+91,(.20*tint,.39*tint,.14*tint),mat)
        self.rows={k:pack(*v)[0] for k,v in groups.items()};return self.rows

# Detailed foliage consists of genuine small leaf geometry, not solid green spheres.
def leaf_cluster(pine=False,detail=0):
    rng=np.random.default_rng(808+int(pine));faces=[];count=(460 if not pine else 600) if detail==0 else 100
    for i in range(count):
        y=rng.uniform(-.45,.48);angle=rng.uniform(0,math.tau)
        radius=(.46*(.5-y)) if pine else (.48*math.sqrt(max(.04,1-(y/.51)**2)))
        rad=radius*rng.uniform(.28,1.);center=np.array((math.cos(angle)*rad,y,math.sin(angle)*rad));a=rng.uniform(0,math.tau)
        direction=np.array((math.cos(a),rng.uniform(-.48,.48),math.sin(a)));direction/=np.linalg.norm(direction)
        right=np.cross(direction,np.array((0.,1.,0.)));right/=max(1e-8,np.linalg.norm(right))
        length=rng.uniform(.035,.085)*(1.5 if detail else 1.);width=length*(.17 if pine else .42)
        start=center-direction*length;end=center+direction*length;left=center-right*width;rightp=center+right*width
        faces.extend([(start,left,end),(start,end,rightp)])
    return triangles(faces)

def branched_trunk():
    # Base trunk normalized to the existing trunk extent, plus tapering lateral branches.
    main=profile([(-.5,.43),(-.33,.36),(.05,.28),(.5,.18)],12,4)
    branches=[]
    for i in range(5):
        angle=i*2.399963;root=np.array((0.,.02+i*.075,0.));end=root+np.array((math.cos(angle)*(.85-i*.07),.22,math.sin(angle)*(.85-i*.07)))
        v=end-root;axis=v/np.linalg.norm(v);r=np.cross(axis,[0.,1.,0.]);r/=np.linalg.norm(r);s=np.cross(axis,r);rings=[]
        for center,radius in ((root,.13),(root+v*.55,.09),(end,.023)):
            rings.append([center+radius*(r*math.cos(j*math.tau/7)+s*math.sin(j*math.tau/7)) for j in range(7)])
        for a,b in zip(rings,rings[1:]):
            for j in range(7):k=(j+1)%7;branches.extend([(a[j],b[j],a[k]),(a[k],b[j],b[k])])
    return np.concatenate((main,triangles(branches)))
GEOMETRY.update({'tree_trunk_near':branched_trunk,'tree_leaves_near':lambda:leaf_cluster(False,0),'tree_leaves_mid':lambda:leaf_cluster(False,1),'pine_leaves_near':lambda:leaf_cluster(True,0),'pine_leaves_mid':lambda:leaf_cluster(True,1)})

# Architectural gable: closed triangular prism with flat outward normals.
def gable_wall():
    a,b,c=(-.5,-.5,.5),(.5,-.5,.5),(0,.5,.5)
    d,e,f=(-.5,-.5,-.5),(.5,-.5,-.5),(0,.5,-.5)
    return triangles([(a,b,c),(d,f,e),(d,e,b),(d,b,a),(a,c,f),(a,f,d),(b,e,f),(b,f,c)])
GEOMETRY['gable_wall']=gable_wall
