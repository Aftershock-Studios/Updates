"""Deterministic architectural templates and conservative spatial placement checks.
Coordinates are metres, Y up, building front is local +Z. No scene edits on failure.
"""
import math
import numpy as np
from .physics import world_matrices
from .city import height
from .assets import asset_metadata, asset_path

STYLES=('house','shop','apartment')

def extents(w,d,yaw):
    a=math.radians(yaw);c,s=abs(math.cos(a)),abs(math.sin(a))
    return ((w*c+d*s)/2,(w*s+d*c)/2)

def bounds(x,y,z,w,h,d,yaw=0):
    u,v=extents(w,d,yaw)
    return (x-u,y,z-v,x+u,y+h,z+v)

def overlap(a,b,tol=.025):
    return all(min(a[i+3],b[i+3])-max(a[i],b[i])>tol for i in range(3))

def segment_hits(a,b,box,margin):
    # Conservative swept axis-aligned clearance: includes the road/sidewalk width.
    lo,hi=0.,1.
    for i,k in ((0,0),(1,2)):
        l,r=box[k]-margin,box[k+3]+margin;delta=b[i]-a[i]
        if abs(delta)<1e-8:
            if not l<=a[i]<=r:return False
        else:
            t,u=sorted(((l-a[i])/delta,(r-a[i])/delta));lo=max(lo,t);hi=min(hi,u)
            if lo>hi:return False
    return True

class Placement:
    def __init__(self,scene):
        self.scene=scene;self.obstacles=[];self.ground=[]
        self.roads=[(a,b,r['width']/2+2.3) for r in (scene.city or {}).get('roads',[]) for a,b in zip(r['points'],r['points'][1:])]
        road_roots={r.get('entity') for r in (scene.city or {}).get('roads',[]) if r.get('entity')}
        for e,m in world_matrices(scene).items():
            if e not in scene.meshes:continue
            root=e
            while scene.parents[root] is not None:root=scene.parents[root]
            if root in road_roots:continue
            q=m[:3,3];half=np.full(3,.5)
            kind=scene.meshes[e].kind
            if kind.startswith('asset:'):
                meta=asset_metadata(asset_path(kind));raw=meta.get('extents');size=meta.get('size',0.)
                if isinstance(raw,(list,tuple)) and len(raw)==3 and size>0:
                    try:
                        extent=np.asarray(raw,dtype=float)/size
                        if np.isfinite(extent).all() and (extent>=0).all() and max(extent)<=1.001:half=np.maximum(.0005,extent*.5)
                    except (TypeError,ValueError):pass
            v=np.abs(m[:3,:3])@half
            b=tuple(map(float,np.r_[q-v,q+v]));label=scene.names[e]
            # Recognise only explicit, broad, flat root ground meshes.
            if e==root and label.casefold() in ('ground','baseplate','terrain ground') and min(v[0],v[2])>=5 and v[1]<=2 and abs(m[1,0])+abs(m[1,2])<.001:
                self.ground.append(b)
            else:self.obstacles.append((label,b))
        for e,n in scene.names.items():
            if n=='Player Spawn' and e not in scene.meshes and scene.parents[e] is None:
                x,y,z=scene.transforms[e].position;self.obstacles.append((n,bounds(x,y,z,1.5,2,1.5)))
    def surface(self,x,z):
        t=self.scene.terrain
        if t is not None and (abs(x)>t.size/2 or abs(z)>t.size/2):raise ValueError('Placement is outside the terrain bounds')
        tops=[b[4] for b in self.ground if b[0]<=x<=b[3] and b[2]<=z<=b[5]]
        if t is None and self.ground and not tops:raise ValueError('Placement is outside the baseplate')
        y=max([height(self.scene,x,z)]+tops) if t is not None else max(tops,default=0.)
        if t is not None and y<=t.water+.05:raise ValueError('Placement is underwater')
        return y
    def foundation(self,x,z,w,d,yaw,maximum_slope=.6):
        u,v=extents(w,d,yaw);ys=[self.surface(x+i*u,z+j*v) for i in (-1,0,1) for j in (-1,0,1)]
        if max(ys)-min(ys)>maximum_slope:raise ValueError('Ground is too uneven for this foundation')
        return max(ys),max(ys)-min(ys)
    def reserve(self,label,b,road_clearance=True):
        for n,old in self.obstacles:
            if overlap(b,old):raise ValueError(f'{label} overlaps {n}; move it to a free location')
        if road_clearance and any(segment_hits(a,c,b,r+.25) for a,c,r in self.roads):raise ValueError(f'{label} overlaps a road or footpath')
        self.obstacles.append((label,b))
    def road(self,points,w):
        new=[]
        for a,b in zip(points,points[1:]):
            length=math.dist(a,b)
            if length<1:raise ValueError('Road points too close')
            margin=w/2+2.3
            for label,box in self.obstacles:
                if segment_hits(a,b,box,margin):raise ValueError('Road crosses '+label)
            # Check ground along the centre and both footpaths. Existing road
            # intersections are permitted, but no promise of traffic graph joining.
            dx,dz=(b[0]-a[0])/length,(b[1]-a[1])/length
            samples=[]
            for i in range(9):
                x,z=a[0]+(b[0]-a[0])*i/8,a[1]+(b[1]-a[1])*i/8
                for s in (-margin,0,margin):samples.append(self.surface(x+dz*s,z-dx*s))
            if max(samples)-min(samples)>.25 or abs(samples[1]-height(self.scene,*a))>.1:raise ValueError('Road requires a flat supported surface')
            new.append((a,b,margin))
        self.roads.extend(new)

def building_parts(w,h,d,style,colour,seed=0):
    """Yield local named facade components, local transforms and material data.
    Exterior shells intentionally remain closed (no furnished or accessible interiors).
    h is the wall/eave height; roof extends above it.
    """
    if style not in STYLES:raise ValueError('Choose house, shop or apartment')
    if not 5<=w<=40 or not 5<=d<=40 or not 2.7<=h<=30:raise ValueError('Building dimensions must be 5–40m wide/deep and 2.7–30m wall height')
    if style=='house' and not 2.7<=h<=7.5:raise ValueError('House wall height must be 2.7–7.5m')
    floor_count=max(1,min(9,round(h/3.2)))
    storey=h/floor_count
    trim=(.76,.75,.70);glass=(.13,.23,.29);frame=(.23,.24,.25);roof=(.28,.29,.31)
    def part(n,p,s,c,mat='Plain',rot=(0,0,0),solid=False,rough=.8,metal=0.):
        return (n,p,s,c,mat,rot,solid,rough,metal)
    yield part('Foundation plinth',(0,.12,0),(w+.22,.24,d+.22),(.56,.56,.53),'Concrete',solid=True)
    yield part('Exterior shell',(0,.24+h/2,0),(w,h,d),colour,'Brick' if style=='house' else 'Concrete',solid=True)
    # Front +Z; back -Z; side facades use a 90-degree yaw.
    for face,span,normal,angle in [('Front',w,(0,1),0),('Back',w,(0,-1),180),('East',d,(1,0),90),('West',d,(-1,0),-90)]:
        edge=(d if angle in (0,180) else w)/2
        u=(math.cos(math.radians(angle)),-math.sin(math.radians(angle)))
        def panel(n,t,y,ww,hh,depth,c,mat='Plain',offset=.02,rough=.8,metal=0):
            p=(normal[0]*(edge+offset+depth/2)+u[0]*t,y,normal[1]*(edge+offset+depth/2)+u[1]*t)
            return part(face+' '+n,p,(ww,hh,depth),c,mat,(0,angle,0),False,rough,metal)
        bays=max(1,min(4,int(span/3.3)))
        for floor in range(floor_count):
            y=.24+floor*storey;win_h=min(1.65,storey*.52);win_w=min(2.25,span/bays*.64)
            if style=='shop' and face=='Front' and floor==0:win_h=min(2.25,storey*.75)
            for j in range(bays):
                t=(j-(bays-1)/2)*span/bays
                # Reserve a central entry bay on the ground-level street facade.
                door=face=='Front' and floor==0 and j==bays//2
                if door:
                    ww=min(1.45,span/bays*.65);hh=min(2.2,storey*.85)
                    yield panel('door surround',t,y+hh/2,ww+.16,hh+.14,.09,trim)
                    yield panel('door',t,y+hh/2,ww,hh,.04,(.24,.16,.11),'Wood',.12)
                    yield panel('door handle',t+ww*.34,y+1.02,.045,.16,.05,(.62,.63,.60),'Metal',.17,.3,.7)
                else:
                    cy=y+storey*.55
                    yield panel('window surround',t,cy,win_w+.14,win_h+.14,.09,frame)
                    yield panel('glazing',t,cy,win_w,win_h,.045,glass,'Plain',.12,.18,.25)
                    yield panel('window mullion',t,cy,.045,win_h,.05,frame,'Plain',.17)
                    yield panel('window sill',t,cy-win_h/2-.08,win_w+.25,.10,.20,trim,'Concrete',.03)
            if style=='apartment':yield panel('floor band',0,y+storey-.10,span,.13,.13,trim,'Concrete')
    if style=='house':
        pitch=28.;a=math.radians(pitch);run=w/2+.35;rise=run*math.tan(a);eave=.24+h
        for sign in (-1,1):
            yield part('Pitched roof', (sign*run/2,eave+rise/2,0),(run/math.cos(a),.18,d+.7),roof,'Plain',(0,0,-sign*pitch),True)
        # True triangular gable infill, rather than stacked rectangular strips.
        for sign in (-1,1):
            yield part('Gable infill',(0,eave+rise/2,sign*(d/2-.08)),(w,rise,.18),colour,'Brick')
        yield part('Ridge flashing',(0,eave+rise,0),(.20,.19,d+.73),roof,'Metal')
        for sign in (-1,1):yield part('Eave gutter',(sign*run,eave-.08,0),(.12,.14,d+.72),frame,'Metal')
        bays=max(1,min(4,int(w/3.3)));door_x=(bays//2-(bays-1)/2)*w/bays
        yield part('Entry step',(door_x,.13,d/2+.27),(min(2.1,w*.36),.24,.55),(.56,.55,.52),'Concrete',solid=True)
    else:
        top=.24+h
        yield part('Flat roof cap',(0,top+.12,0),(w+.30,.24,d+.30),roof,'Concrete',solid=True)
        for sign in (-1,1):
            yield part('Roof parapet',(sign*(w/2-.08),top+.42,0),(.22,.42,d),trim,'Concrete',solid=True)
            yield part('Roof parapet',(0,top+.42,sign*(d/2-.08)),(w,.42,.22),trim,'Concrete',solid=True)
        if style=='shop':
            yield part('Shop awning',(0,min(2.65,h*.8),d/2+.65),(w*.85,.15,1.3),(.23,.34,.39),'Metal',solid=False)
            yield part('Sign panel',(0,min(3.05,h*.9),d/2+.12),(w*.7,.38,.16),(.23,.34,.39),'Plain')
