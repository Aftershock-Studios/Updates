"""Opt-in, bounded CC0 PBR material downloads from Poly Haven (credited in Studio).
Existing project overrides are never replaced. No downloads on startup.
"""
from pathlib import Path
import hashlib, json, tempfile, urllib.request, urllib.parse, zipfile
from .materials import import_pbr

CATALOG={'Grass':'leafy_grass','Sand':'aerial_beach_02','Rock':'aerial_rocks_02','Dirt':'forest_floor','Concrete':'concrete_floor_01','Asphalt':'aerial_asphalt_01','Brick':'brick_wall_02','Wood':'bark_brown_02'}
MAPS={'albedo':('diff','albedo'),'normal_gl':('nor_gl','normal_gl'),'roughness':('rough','roughness')}
UA='AftershockStudio/0.0.19.9 (Poly Haven material importer)'
LIMIT=8*1024*1024

def check_url(url):
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme!='https' or parsed.hostname not in ('api.polyhaven.com','dl.polyhaven.org','cdn.polyhaven.com','dl.polyhaven.com') or parsed.username or parsed.password or parsed.port not in (None,443):raise ValueError('Untrusted Poly Haven download URL')
class Redirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        check_url(newurl);return super().redirect_request(req,fp,code,msg,headers,newurl)

def fetch(url,limit=LIMIT):
    check_url(url);req=urllib.request.Request(url,headers={'User-Agent':UA})
    with urllib.request.build_opener(Redirects()).open(req,timeout=30) as response:
        check_url(response.geturl());data=response.read(limit+1)
    if len(data)>limit:raise ValueError('Download exceeds size limit')
    return data

def map_info(meta,aliases):
    # Provider maps may be keyed by human-readable labels rather than file suffixes.
    if not isinstance(meta,dict):raise ValueError('Invalid provider metadata')
    candidates=[]
    for key,entry in meta.items():
        if not isinstance(entry,dict) or not isinstance(entry.get('1k'),dict):continue
        for ext in ('jpg','png','jpeg'):
            info=entry['1k'].get(ext)
            if not isinstance(info,dict) or not isinstance(info.get('url'),str):continue
            path=urllib.parse.urlsplit(info['url']).path.lower();size=info.get('size',info.get('size_bytes'))
            if not (key.lower() in aliases or any('_'+alias+'_1k.' in path for alias in aliases)):continue
            if type(size) is int and 0<size<=LIMIT and isinstance(info.get('md5'),str) and len(info['md5'])==32:candidates.append((ext,dict(info,size=size)))
    if candidates:return min(candidates,key=lambda x:('jpg','png','jpeg').index(x[0]))
    raise ValueError('Missing verified 1K '+aliases[0]+' map')

def install(project,progress=lambda msg:None,download=fetch):
    target=Path(project)/'assets'/'pbr';target.mkdir(parents=True,exist_ok=True);results={}
    for name,slug in CATALOG.items():
        if (target/(name+'.npz')).exists():results[name]='Already installed (preserved)';continue
        progress('Poly Haven: downloading '+name+'…')
        try:
            meta=json.loads(download('https://api.polyhaven.com/files/'+slug,2*1024*1024))
            with tempfile.TemporaryDirectory(prefix='aftershock-pbr-') as temp:
                for kind,aliases in MAPS.items():
                    ext,info=map_info(meta,aliases);data=download(info['url'],LIMIT)
                    if len(data)!=info['size'] or hashlib.md5(data).hexdigest()!=info['md5'].lower():raise ValueError('Map checksum mismatch')
                    (Path(temp)/(kind+'.'+ext)).write_bytes(data)
                if (target/(name+'.npz')).exists():results[name]='Existing override preserved';continue
                import_pbr(project,name,temp)
            results[name]='Installed';progress('Poly Haven: '+name+' installed')
        except (OSError,ValueError,KeyError,TypeError,RuntimeError) as exc:results[name]='Failed: '+str(exc);progress('Poly Haven: '+name+' failed: '+str(exc))
    return results

PACK_TAG='materials-v1'
PACK_NAME='Aftershock_PolyHaven_Materials_1K.zip'
PACK_LIMIT=96*1024*1024
REPO='Aftershock-Studios/Updates'

def install_release(project,progress=lambda msg:None):
    """Use the optional, verified GitHub-built archive. Never extract arbitrary ZIP paths."""
    import re, zipfile
    from launcher.online_updates import open_url
    target=Path(project)/'assets'/'pbr';target.mkdir(parents=True,exist_ok=True)
    if all((target/(name+'.npz')).exists() for name in CATALOG):return {name:'Already installed (preserved)' for name in CATALOG}
    with open_url(f'https://api.github.com/repos/{REPO}/releases/tags/{PACK_TAG}','application/vnd.github+json') as response:
        raw=response.read(2*1024*1024+1)
    if len(raw)>2*1024*1024:raise ValueError('Material release metadata too large')
    release=json.loads(raw);url=f'https://github.com/{REPO}/releases/download/{PACK_TAG}/{PACK_NAME}'
    asset=next((a for a in release.get('assets',[]) if a.get('name')==PACK_NAME and a.get('state')=='uploaded' and a.get('browser_download_url')==url),None)
    if release.get('draft') or release.get('prerelease') or not asset:raise ValueError('Scanned material release not available')
    size=asset.get('size');digest=asset.get('digest','')
    if type(size) is not int or not 0<size<=PACK_LIMIT or not re.fullmatch(r'sha256:[0-9a-f]{64}',digest):raise ValueError('Invalid material pack metadata')
    with tempfile.TemporaryDirectory(prefix='aftershock-realworld-') as tmp:
        tmp=Path(tmp);archive=tmp/'material-pack.zip';h=hashlib.sha256();done=0
        with open_url(url,'application/octet-stream') as response,archive.open('xb') as out:
            while True:
                chunk=response.read(256*1024)
                if not chunk:break
                done+=len(chunk)
                if done>size:raise ValueError('Material pack too large')
                out.write(chunk);h.update(chunk)
                if done%(2*1024*1024)<len(chunk):progress(f'Poly Haven pack: {done/1048576:.1f}/{size/1048576:.1f} MB')
        if done!=size or h.hexdigest()!=digest[7:]:raise ValueError('Material pack SHA-256 mismatch')
        with zipfile.ZipFile(archive) as z:
            return import_archive(project,z,progress)

def import_archive(project,z,progress=lambda msg:None):
    import re
    target=Path(project)/'assets'/'pbr';target.mkdir(parents=True,exist_ok=True)
    entries=z.infolist()
    if len(entries)>30 or len({i.filename for i in entries})!=len(entries) or any(i.file_size>LIMIT for i in entries) or sum(i.file_size for i in entries)>PACK_LIMIT:raise ValueError('Invalid material archive limits')
    if z.getinfo('manifest.json').file_size>65536:raise ValueError('Material manifest too large')
    manifest=json.loads(z.read('manifest.json'));results={}
    for name,slug in CATALOG.items():
        if (target/(name+'.npz')).exists():results[name]='Already installed (preserved)';continue
        if name not in manifest:continue
        try:
            item=manifest[name];files=item['files']
            if item.get('source')!='https://polyhaven.com/a/'+slug or item.get('license')!='CC0-1.0' or len(files)!=3:raise ValueError('Invalid source manifest')
            with tempfile.TemporaryDirectory(prefix='aftershock-map-') as tmp:
                tmp=Path(tmp)
                for kind in MAPS:
                    path=next((p for p in files if re.fullmatch(re.escape(name+'/'+kind)+r'\.(jpg|jpeg|png)',p)),None)
                    if path is None:raise ValueError('Missing '+kind+' map')
                    data=z.read(path)
                    if hashlib.sha256(data).hexdigest()!=files[path]:raise ValueError('Material map checksum mismatch')
                    (tmp/Path(path).name).write_bytes(data)
                if (target/(name+'.npz')).exists():results[name]='Existing override preserved';continue
                import_pbr(project,name,tmp)
            results[name]='Installed';progress('Poly Haven: '+name+' installed')
        except (OSError,ValueError,KeyError,TypeError,RuntimeError) as exc:results[name]='Failed: '+str(exc);progress('Poly Haven: '+name+' failed: '+str(exc))
    return results

def install_real_world(project,progress=lambda msg:None):
    try:
        progress('Poly Haven: checking optional GitHub material library…');results=install_release(project,progress)
    except (OSError,ValueError,KeyError,TypeError,RuntimeError,zipfile.BadZipFile) as exc:
        progress('Poly Haven: GitHub library unavailable; trying provider directly.');results={}
    if len(results)<len(CATALOG) or any(v.startswith('Failed') for v in results.values()):
        for name,status in install(project,progress).items():
            if results.get(name)!='Installed':results[name]=status
    return results
