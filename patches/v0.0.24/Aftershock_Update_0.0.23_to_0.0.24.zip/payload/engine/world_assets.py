"""Original deterministic seamless PBR library. Maps are generated on demand or in packs.
No external textures or downloads. All generated assets are original procedural assets.
"""
from pathlib import Path
import json, hashlib, math, os, tempfile, zipfile, argparse
import numpy as np
from PIL import Image

# family, default material slot, sRGB colour, roughness, metalness, relief style
FAMILIES=(
 ('Blacktop','Asphalt',(55,57,58),.87,0,'aggregate'),('Weathered Asphalt','Asphalt',(82,81,77),.91,0,'cracked'),('Road Gravel','Rock',(116,112,105),.9,0,'gravel'),('Tar Seal','Asphalt',(40,43,44),.75,0,'aggregate'),
 ('Cast Concrete','Concrete',(158,155,147),.83,0,'concrete'),('Polished Concrete','Concrete',(151,151,148),.38,0,'concrete'),('Concrete Slab','Concrete',(166,162,152),.81,0,'tile'),('Concrete Block','Concrete',(143,140,133),.9,0,'brick'),
 ('Red Brick','Brick',(156,79,55),.86,0,'brick'),('Buff Brick','Brick',(185,153,106),.85,0,'brick'),('Dark Brick','Brick',(83,62,55),.88,0,'brick'),('Stone Pavers','Rock',(137,132,122),.84,0,'paver'),
 ('Granite','Rock',(130,128,125),.64,0,'granite'),('Limestone','Rock',(174,166,144),.88,0,'rock'),('Basalt','Rock',(63,65,66),.83,0,'rock'),('Sandstone','Rock',(184,145,100),.89,0,'strata'),
 ('Slate','Rock',(82,88,93),.69,0,'strata'),('Marble','Rock',(205,202,194),.28,0,'marble'),('Quartzite','Rock',(180,175,162),.62,0,'granite'),('River Pebbles','Rock',(135,127,113),.8,0,'gravel'),
 ('Dry Earth','Dirt',(130,96,62),.95,0,'earth'),('Clay Soil','Dirt',(153,96,66),.91,0,'cracked'),('Forest Floor','Dirt',(81,65,43),.93,0,'earth'),('Mud','Dirt',(87,68,47),.64,0,'earth'),
 ('Beach Sand','Sand',(207,181,130),.91,0,'sand'),('Dune Sand','Sand',(197,160,103),.92,0,'sand'),('Dark Sand','Sand',(99,95,83),.9,0,'sand'),('Coarse Sand','Sand',(169,147,114),.94,0,'aggregate'),
 ('Lawn','Grass',(87,117,54),.91,0,'grass'),('Meadow','Grass',(111,132,68),.92,0,'grass'),('Dry Grass','Grass',(155,143,76),.94,0,'grass'),('Moss','Grass',(72,102,47),.96,0,'moss'),
 ('Oak Planks','Wood',(149,105,63),.58,0,'planks'),('Pine Planks','Wood',(189,145,90),.63,0,'planks'),('Walnut','Wood',(94,59,42),.56,0,'wood'),('Weathered Timber','Wood',(128,121,103),.85,0,'planks'),
 ('Tree Bark','Wood',(90,65,43),.95,0,'bark'),('Paperbark','Wood',(179,162,130),.93,0,'bark'),('Cedar','Wood',(139,80,50),.65,0,'wood'),('Plywood','Wood',(178,142,92),.72,0,'wood'),
 ('Brushed Steel','Metal',(156,163,169),.36,.92,'metal'),('Galvanised Steel','Metal',(160,163,161),.49,.85,'granite'),('Rusty Steel','Metal',(132,76,43),.76,.5,'rust'),('Aluminium','Metal',(188,193,197),.28,.92,'metal'),
 ('Copper','Metal',(183,108,68),.41,.95,'metal'),('Patinated Copper','Metal',(81,132,118),.77,.45,'rust'),('Painted Steel','Metal',(81,98,109),.55,.1,'metal'),('Diamond Plate','Metal',(127,134,142),.45,.85,'diamond'),
 ('Ceramic Tile','Concrete',(202,198,185),.32,0,'tile'),('Terracotta Tile','Brick',(168,91,59),.72,0,'tile'),('Porcelain Tile','Concrete',(223,219,208),.23,0,'tile'),('Roof Shingles','Rock',(78,80,81),.88,0,'brick'),
 ('Plaster','Concrete',(212,207,194),.85,0,'concrete'),('Stucco','Concrete',(198,180,151),.92,0,'aggregate'),('Painted Wall','Concrete',(216,214,206),.72,0,'concrete'),('Rubber','Asphalt',(44,45,47),.77,0,'diamond'),
 ('Canvas','Plain',(161,153,132),.94,0,'fabric'),('Denim','Plain',(62,87,125),.93,0,'fabric'),('Leather','Plain',(98,65,47),.61,0,'leather'),('Carpet','Plain',(112,103,91),.97,0,'fabric'),
 ('Fresh Snow','Snow',(226,234,238),.88,0,'snow'),('Compacted Snow','Snow',(201,217,224),.69,0,'snow'),('Ice','Snow',(145,185,205),.24,0,'cracked'),('Salt Crust','Sand',(210,207,191),.87,0,'granite'),
)
VARIANTS=16
RESOLUTIONS=(512,1024,2048)
COUNT=len(FAMILIES)*VARIANTS

def catalog():
    return tuple(dict(id=f'world-{i:04d}',name=f'{f[0]} {j+1:02d}',family=f[0],slot=f[1],roughness=f[3],metalness=f[4],index=i,license='CC0-1.0') for k,f in enumerate(FAMILIES) for j in range(VARIANTS) for i in (k*VARIANTS+j,))

def index_of(identifier):
    if not isinstance(identifier,str) or not identifier.startswith('world-') or len(identifier)!=10 or not identifier[6:].isdigit():raise ValueError('Invalid material ID')
    i=int(identifier[6:]);
    if i>=COUNT:raise ValueError('Unknown material')
    return i

def noise(rng,n,size):
    """Periodic bicubic value noise (wrapped samples at the boundaries)."""
    grid=rng.standard_normal((n,n),dtype=np.float32)
    padded=np.pad(grid,((2,2),(2,2)),mode='wrap')
    im=Image.fromarray(padded)
    a=np.asarray(im.resize((size,size),Image.Resampling.BICUBIC,box=(2,2,n+2,n+2)),dtype=np.float32)
    return (a/max(float(a.std()),.05)).astype('f4')

def maps(index,size=1024):
    if type(index) is not int or not 0<=index<COUNT or size not in RESOLUTIONS:raise ValueError('Invalid material or resolution')
    family,slot,base,rough,metal,style=FAMILIES[index//VARIANTS];variant=index%VARIANTS
    rng=np.random.default_rng(820317+index*7919)
    y,x=np.ogrid[:size,:size];x=x.astype('f4')/size;y=y.astype('f4')/size
    a=noise(rng,5+variant%4,size);b=noise(rng,22+variant%8,size);c=noise(rng,94+variant*3,size);d=noise(rng,min(size//2,220+variant*7),size)
    micro=rng.standard_normal((size,size),dtype=np.float32)
    h=.14*a+.25*b+.16*c+.07*d+.025*micro
    tint=.045*a+.045*b+.045*c+.025*d+.012*micro
    mask=None; colour=None; rmod=0
    tau=2*np.pi
    if style in ('brick','tile','paver','planks'):
        rows={'brick':8,'tile':4,'paver':9,'planks':3}[style]+(variant%3 if style!='planks' else 0)
        cols={'brick':4,'tile':4,'paver':7,'planks':8}[style]+variant%3
        row=np.floor(y*rows); fx=(x*cols+(row%2)*(.5 if style in ('brick','paver') else 0))%1;fy=(y*rows)%1
        edge=np.minimum(np.minimum(fx,1-fx),np.minimum(fy,1-fy));edge=edge+.012*b
        width=.045 if style in ('brick','paver') else .022
        mask=np.clip((width-edge)/.022,0,1); h=h*.45-.7*mask
        cell=(np.sin(row*12.9898+np.floor(x*cols+(row%2)*.5)*78.233+variant)*.055)
        tint+=cell;colour=(151,143,130) if style in ('brick','paver','tile') else (60,45,30)
        if style=='planks':h+=.13*np.sin(tau*(x*cols*12+.20*a))+.055*np.sin(tau*(x*cols*31+.3*b));tint+=.055*np.sin(tau*(x*cols*7+.15*a))
    elif style in ('wood','bark'):
        f=15+variant*2;grain=np.sin(tau*(x*f+.27*a+.07*b));fine=np.sin(tau*(x*(f*3+1)+.13*b))
        h+=grain*(.35 if style=='bark' else .14)+.065*fine;tint+=.10*grain+.035*fine
    elif style=='marble':
        v=np.abs(np.sin(tau*(x*(2+variant%4)+y*2+.22*a+.09*b)));vein=np.exp(-v*16);tint-=.28*vein;h*=.14;rmod=.06*vein
    elif style in ('rock','strata'):
        layers=np.sin(tau*(y*(7+variant%5)+x*(variant%3)+.23*a));h+=.28*np.tanh(2*b)+.12*layers;tint+=.07*layers
    elif style in ('aggregate','gravel','granite','concrete'):
        stones=np.tanh(c*2.4);pore=np.clip((-d-1.0)*1.6,0,1);h+=.20*stones-.18*pore;tint+=.09*stones-.08*pore
        if style=='gravel':h+=.31*np.maximum(b,0);tint+=.08*b
        if style=='granite':tint+=.08*np.sign(c)*np.clip(np.abs(c),0,1)
    elif style=='cracked':
        v=np.abs(np.sin(tau*(x*(4+variant%4)+y*(2+variant%3)+.4*a+.12*b)));crack=np.exp(-v*24)*np.clip(.8+b*.25,0,1);h-=.60*crack;tint-=.27*crack
    elif style in ('grass','moss'):
        blades=np.sin(tau*(x*(90+variant*3)+y*(32+variant%5)+.22*b));h+=.12*blades+.16*np.maximum(c,0);tint+=.075*blades+.07*b
    elif style=='sand':
        ripple=np.sin(tau*(y*(8+variant%6)+x*(variant%4)+.14*a));h+=.13*ripple;tint+=.025*ripple
    elif style=='fabric':
        weave=np.sin(tau*x*(110+variant*4))*np.sin(tau*y*(112+variant*4));h=.12*h+.19*weave+.04*d;tint=.3*tint+.06*weave
    elif style=='metal':
        grain=np.sin(tau*(y*(160+variant*5)+.12*c));h=.13*h+.05*grain;tint=.35*tint+.025*grain
    elif style=='rust':
        rust=np.clip((a+b*.55)*.75+.35,0,1);mask=rust;colour=(153,77,36);h+=.18*rust*c;tint+=.07*rust;rmod=.13*rust
    elif style=='diamond':
        u=(x*(12+variant%4)+y*(12+variant%4))%1;v=(x*(12+variant%4)-y*(12+variant%4))%1;ridge=np.clip(1-np.abs(u-.5)*4-np.abs(v-.5)*9,0,1);h=.13*h+.38*ridge;tint+=.07*ridge
    elif style=='leather':h+=.18*np.tanh(b*3);tint+=.05*b
    elif style=='snow':h*=.65;tint*=.55
    # Variation is material-specific, not just a colour tint: every seed changes all noise fields.
    rgb=np.array(base,dtype='f4')*(.88+.016*variant);rgb+=rng.uniform(-5,5,3)
    albedo=np.clip(rgb[None,None,:]*(1+tint[:,:,None]),0,255)
    if mask is not None:albedo=albedo*(1-mask[:,:,None])+np.array(colour,dtype='f4')*mask[:,:,None]
    roughmap=np.clip(rough+.035*a+.035*b+.026*d+rmod,.05,1)
    # Normal Y is OpenGL (+Y up), while image rows increase down.
    strength=size/1024*1.75;gx=(np.roll(h,-1,1)-np.roll(h,1,1))*strength;gy=(np.roll(h,-1,0)-np.roll(h,1,0))*strength
    inv=1/np.sqrt(1+gx*gx+gy*gy);normal=np.stack((-gx*inv,gy*inv,inv),axis=-1)
    u8=lambda z:np.uint8(np.clip(np.rint(z),0,255))
    return {'albedo':u8(albedo),'normal_gl':u8((normal*.5+.5)*255),'roughness':u8(roughmap*255),'height':u8((h*.36+.5)*255)}

def create_material(project,identifier,resolution=1024):
    """Store a material atomically; do not overwrite a prior material."""
    i=index_of(identifier);folder=Path(project)/'assets'/'world_materials';folder.mkdir(parents=True,exist_ok=True)
    destination=folder/f'{identifier}-{resolution}'
    if destination.exists():
        if not (destination/'material.json').is_file():raise ValueError('Existing incomplete asset; move it before retrying')
        return destination
    meta=dict(catalog()[i],resolution=resolution,source='Aftershock original procedural generation')
    with tempfile.TemporaryDirectory(dir=folder,prefix='build-') as temp:
        tmp=Path(temp)/'material';tmp.mkdir()
        for key,arr in maps(i,resolution).items():
            p=tmp/(key+'.png');Image.fromarray(arr).save(p,compress_level=2)
        (tmp/'material.json').write_text(json.dumps(meta,indent=2))
        os.rename(tmp,destination)
    return destination

def apply_material(project,identifier,resolution,slot):
    from .materials import import_pbr
    folder=create_material(project,identifier,resolution)
    return import_pbr(project,slot,folder)

# Pack generation writes compact JPEG colour/roughness maps and lossless normals/height.
# The on-demand editor path retains all maps as PNG.
def pack_member(index,size):
    import io
    meta=dict(catalog()[index],resolution=size,source='Aftershock original procedural generation')
    output={}
    for key,arr in maps(index,size).items():
        stream=io.BytesIO();ext='jpg' if key in ('albedo','roughness') else 'png'
        if ext=='jpg':Image.fromarray(arr).save(stream,format='JPEG',quality=94,subsampling=0)
        else:Image.fromarray(arr).save(stream,format='PNG',compress_level=1)
        output[f'{key}.{ext}']=stream.getvalue()
    meta['files']={k:hashlib.sha256(v).hexdigest() for k,v in output.items()}
    output['material.json']=json.dumps(meta,indent=2).encode()
    return index,output

def compile_pack(path,start,end,size=1024,workers=2):
    from concurrent.futures import ProcessPoolExecutor
    if not 0<=start<end<=COUNT or size not in RESOLUTIONS:raise ValueError('Invalid pack range')
    path=Path(path);tmp=path.with_suffix('.partial');manifest={}
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_STORED,allowZip64=True) as z, ProcessPoolExecutor(max_workers=workers) as pool:
            for i,files in pool.map(pack_member,range(start,end),[size]*(end-start),chunksize=1):
                identifier=f'world-{i:04d}';manifest[identifier]=json.loads(files['material.json'])
                for filename,content in files.items():z.writestr(f'{identifier}-{size}/{filename}',content)
            z.writestr('manifest.json',json.dumps(manifest,indent=2));z.writestr('LICENSE.txt','Original procedural materials, released under CC0 1.0. https://creativecommons.org/publicdomain/zero/1.0/\n')
        with zipfile.ZipFile(tmp) as z:
            if z.testzip() is not None:raise ValueError('Corrupt pack')
        os.replace(tmp,path)
    finally:tmp.unlink(missing_ok=True)
    return path

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('output');parser.add_argument('--start',type=int,default=0);parser.add_argument('--end',type=int,default=COUNT);parser.add_argument('--size',type=int,default=1024,choices=RESOLUTIONS);parser.add_argument('--workers',type=int,default=2);args=parser.parse_args()
    print(compile_pack(args.output,args.start,args.end,args.size,args.workers))

# The pack importer never extracts paths supplied by an archive directly. It
# validates every filename, map checksum and image dimensions before committing.
def import_pack(project,path,progress=lambda msg:None):
    root=Path(project)/'assets'/'world_materials';root.mkdir(parents=True,exist_ok=True)
    from shutil import disk_usage
    source=Path(path);limit=2*1024**3;installed=0;skipped=0
    with zipfile.ZipFile(source) as z:
        entries=z.infolist();names={e.filename for e in entries}
        if len(entries)>642 or len(names)!=len(entries) or any(e.is_dir() or e.flag_bits&1 or e.file_size>32*1024**2 for e in entries) or sum(e.file_size for e in entries)>limit:raise ValueError('Invalid material pack limits')
        if 'manifest.json' not in names or z.getinfo('manifest.json').file_size>512*1024:raise ValueError('Missing pack manifest')
        manifest=json.loads(z.read('manifest.json'))
        if not isinstance(manifest,dict) or not 1<=len(manifest)<=128:raise ValueError('Invalid material manifest')
        expected={'manifest.json','LICENSE.txt'}
        for identifier,meta in manifest.items():
            i=index_of(identifier);size=meta.get('resolution');ref=catalog()[i]
            if size not in RESOLUTIONS or any(meta.get(k)!=ref[k] for k in ('id','name','index','license','family','slot','metalness','roughness')) or meta.get('source')!='Aftershock original procedural generation':raise ValueError('Invalid material metadata')
            folder=f'{identifier}-{size}';maps_expected={'albedo.jpg','normal_gl.png','roughness.jpg','height.png'}
            if not isinstance(meta.get('files'),dict) or set(meta['files'])!=maps_expected:raise ValueError('Invalid map manifest')
            expected.add(folder+'/material.json');expected.update(folder+'/'+k for k in maps_expected)
        if names!=expected:raise ValueError('Unexpected material archive entries')
        if disk_usage(root).free<sum(e.file_size for e in entries)+64*1024**2:raise ValueError('Not enough storage for this material pack')
        import io
        for identifier,meta in manifest.items():
            size=meta['resolution'];folder=f'{identifier}-{size}';dest=root/folder
            if dest.exists():skipped+=1;continue
            progress('Installing '+meta['name'])
            with tempfile.TemporaryDirectory(dir=root,prefix='import-') as temp:
                target=Path(temp)/'material';target.mkdir()
                for name,digest in meta['files'].items():
                    data=z.read(folder+'/'+name)
                    if hashlib.sha256(data).hexdigest()!=digest:raise ValueError('Texture checksum mismatch: '+name)
                    with Image.open(io.BytesIO(data)) as im:
                        if im.size!=(size,size) or im.mode!=('RGB' if name.startswith(('albedo','normal')) else 'L'):raise ValueError('Invalid texture map size or mode')
                        im.load()
                    (target/name).write_bytes(data)
                (target/'material.json').write_text(json.dumps(meta,indent=2))
                os.rename(target,dest);installed+=1
    return installed,skipped
