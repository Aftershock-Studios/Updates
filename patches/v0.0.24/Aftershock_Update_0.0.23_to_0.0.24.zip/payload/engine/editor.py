"""Aftershock Studio: scene editing, viewport tools and non-destructive play preview."""
from dataclasses import replace
from pathlib import Path
import math, shlex, sys, subprocess, os, uuid, threading, queue
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from .ecs import Scene, Transform, Mesh
from .camera import perspective
from .viewport_tools import plane_hit, axis_parameter, nearest_segment, axes_for, circle_points, frame_selection
from .assets import ROOT, import_model, asset_info, asset_metadata, list_assets, asset_path, write_metadata, SOURCES
from . import config
from .code_editor import CodeEditor
from . import theme
from .hidpi import canvas
from .terrain import Terrain, PRESETS as TERRAIN_PRESETS, MATERIALS
from .materials import PATTERNS, SPECS

SCENES=ROOT.parent.parent/'scenes'

def world_matrices(scene):
    out={}
    for eid in scene.ordered():
        t=scene.transforms[eid].matrix(); p=scene.parents[eid]
        out[eid]=t if p is None else out[p]@t
    return out

def pick(scene, origin, direction):
    """Ray against transformed unit bounds; nearest positive hit, not triangle exact."""
    best=None; distance=float('inf')
    for eid,m in world_matrices(scene).items():
        if eid not in scene.meshes: continue
        inv=np.linalg.inv(m); o=(inv@np.r_[origin,1])[:3]; d=(inv@np.r_[direction,0])[:3]
        lo,hi=-float('inf'),float('inf')
        for axis in range(3):
            if abs(d[axis])<1e-8:
                if abs(o[axis])>.5: lo,hi=1,0; break
            else:
                a,b=sorted(((-.5-o[axis])/d[axis],(.5-o[axis])/d[axis])); lo=max(lo,a); hi=min(hi,b)
        if hi>=max(lo,0):
            hit=lo if lo>=0 else hi
            if hit<distance: best,distance=eid,hit
    return best

class Editor:
    def __init__(self):
        self.visible=True; self.dirty=True; self.typing=False; self.command=''; self.scene=None; self.selected=None
        self.history=[]; self.future=[]; self.playing=False; self.saved_edit=None; self.index=0; self.offset=0; self.asset_offset=0
        self.debug_colliders=False; self.output=[]; self.search=''; self.code=None; self.script_tab=False; self.buttons=[]; self.message='Ready | Character & environment update'; self.mode='move'; self.view_mode='Perspective'; self.ortho_size=70.; self.drag=None; self.gizmo=[]; self.rings=[]; self.camera_drag=None; self.gizmo_axes=np.eye(3); self.path=SCENES/'project_city.json'; self.ids=[]; self.depth={}; self.revision=-1
        self.terrain_tab=False; self.surface_dropdown=False; self.terrain_dropdown=False; self.terrain_preset="Tropical"; self.terrain_seed=42; self.terrain_size=4096; self.terrain_water=0.; self.terrain_decorations=False; self.brush_mode="Raise"; self.brush_radius=48; self.brush_strength=12; self.brush_material="Grass"; self.brush_hit=None
        self.font=theme.font(13); self.small=theme.font(12); self.large=theme.font(17,True); self.pointer=(-1,-1); self.output_expanded=False; self.update_close=False; self.update_checker=None; self.character_status=""; self.on_play_start=None; self.on_play_stop=None;self.animation_preview=None;self.world_tools=False;self.asset_search="";self.library_selection=None;self.library_offset=0;self.road_points=None;self.picker=None;self.camera=None;self.pack_thread=None;self.pack_messages=queue.Queue();self.market=None;self.market_material=None;self.market_material_offset=0
    def log(self,s):
        self.message=str(s); self.output.append(self.message); self.output=self.output[-80:]; self.dirty=True
    def script_editor(self):
        from .luau import script_path
        if self.code is None:
            path=script_path(); self.code=CodeEditor(path.parent); self.code.open(path)
        self.script_tab=True; self.terrain_tab=False; self.typing=False; self.drag=None; self.camera_drag=None; self.dirty=True
    def scene_tab(self):
        self.script_tab=False; self.terrain_tab=False; self.typing=False; self.dirty=True
    def open_terrain(self):
        self.script_tab=False;self.terrain_tab=True;self.terrain_dropdown=False;self.typing=False;self.drag=None;self.camera_drag=None;self.dirty=True
        if self.scene.terrain:
            t=self.scene.terrain;self.terrain_preset=t.preset;self.terrain_seed=t.seed;self.terrain_size=t.size;self.terrain_water=t.water;self.terrain_decorations=t.decorations
    def set_preset(self,preset):
        self.terrain_preset=preset;self.terrain_dropdown=False;self.dirty=True
    def generate_terrain(self):
        self.terrain_dropdown=False
        t=Terrain(self.terrain_preset,self.terrain_seed,self.terrain_size,self.terrain_water,decorations=self.terrain_decorations)
        def op():self.scene.terrain=t;self.scene.revision+=1
        self.change(op)
        if self.camera is not None:
            self.camera.position[:]=(0,float(t.height(0,0))+150,180);self.camera.yaw,self.camera.pitch=-90,-35;self.view_mode='Perspective'
        self.log('Generated '+t.preset+' terrain; existing entities retained')
    def toggle_decorations(self):
        if self.playing:raise ValueError('Stop play mode before editing')
        t=self.scene.terrain
        self.terrain_decorations=not (t.decorations if t else self.terrain_decorations)
        if t:
            def op():self.scene.terrain=replace(t,decorations=self.terrain_decorations);self.scene.revision+=1
            self.change(op)
        self.log('Decorations '+('enabled' if self.terrain_decorations else 'disabled'))
    def terrain_stamp(self,x,y):
        if self.playing or self.scene.terrain is None:return
        hit=self.scene.terrain.ray(*self.ray(x,y))
        if hit is None:return
        new=self.scene.terrain.brush(float(hit[0]),float(hit[2]),self.brush_radius,self.brush_strength,self.brush_mode,self.brush_material)
        def op():self.scene.terrain=new;self.scene.revision+=1
        self.change(op);self.log(self.brush_mode+' terrain (click to stamp; Undo supported)')
    def terrain_remove(self):
        def op():self.scene.terrain=None;self.scene.revision+=1
        self.change(op);self.log('Terrain removed; Undo available')
    def terrain_map(self,path,export=False):
        if self.scene.terrain is None:raise ValueError('Generate terrain first')
        t=self.scene.terrain.heightmap(path,export)
        if not export:
            def op():self.scene.terrain=t;self.scene.revision+=1
            self.change(op)
        self.log(('Exported ' if export else 'Imported ')+str(path))
    def save_scripts(self):
        if self.code is not None: self.code.save(all=True)
    def show_output(self):
        self.output_expanded=not self.output_expanded; self.dirty=True
    def choose(self,action):
        if sys.platform!="darwin": self.command_prefix(action+" "); return
        if self.playing: raise ValueError("Stop Play before editing")
        prompt={"open":"Open an Aftershock scene","save":"Save scene as","import":"Import an OBJ, GLB or glTF model"}[action]
        expression=(f'POSIX path of (choose file name with prompt "{prompt}" default name "project_city.json")' if action=="save" else f'POSIX path of (choose file with prompt "{prompt}")')
        result=subprocess.run(["osascript","-e",expression],capture_output=True,text=True)
        if result.returncode==0:
            self.command=action+" "+shlex.quote(result.stdout.strip()); self.execute(self.graphics)
    def open_asset_library(self):
        if self.playing:raise ValueError('Stop Play before importing or placing assets')
        self.scene_tab();self.picker='assets';self.library_offset=0;self.dirty=True
    def open_world_library(self):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads')
        self.scene_tab();self.picker='worldlibrary';self.world_query='';self.world_mode=getattr(self,'world_mode','materials');self.world_offset=0;self.world_selection=None;self.world_resolution=getattr(self,'world_resolution',1024);self.dirty=True
    def world_rows(self):
        from . import world_assets,world_meshes
        rows=world_assets.catalog() if self.world_mode=='materials' else world_meshes.catalog()
        query=self.world_query.casefold().strip()
        return [r for r in rows if query in (r['name']+' '+r['id']+' '+r.get('slot','')).casefold()]
    def world_mode_set(self,mode):
        self.world_mode=mode;self.world_offset=0;self.world_selection=None;self.dirty=True
    def world_select(self,identifier):
        self.world_selection=identifier;self.dirty=True
    def world_generate(self,apply=False):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads')
        if self.pack_thread and self.pack_thread.is_alive():raise ValueError('Wait for the current asset operation')
        from . import world_assets,world_meshes
        identifier=self.world_selection
        if not identifier:raise ValueError('Select an asset first')
        if self.world_mode=='meshes':
            kind,_,name=world_meshes.import_prop(identifier);self.open_asset_library();self.library_selection=kind;self.asset_search=name;self.log('Generated '+name+'; choose a collision mode to place it');return
        project=ROOT.parent.parent;size=self.world_resolution
        if apply:
            from .materials import NAMES
            choices=', '.join('"'+n+'"' for n in NAMES if n!='Water')
            if sys.platform!='darwin':self.command_prefix('worldapply '+identifier+' ');return
            r=subprocess.run(['/usr/bin/osascript','-e','choose from list {'+choices+'} with prompt "Choose an existing world material slot. This changes all objects using that slot after restart."'],capture_output=True,text=True)
            if r.returncode or r.stdout.strip()=='false':return
            slot=r.stdout.strip();world_assets.apply_material(project,identifier,size,slot);self.log('Applied '+identifier+' to '+slot+'. Restart Studio to reload the material.');return
        p=world_assets.create_material(project,identifier,size);self.log('Saved '+p.name+' to the project.');self.dirty=True
    def world_import_pack(self):
        if self.playing or self.market_busy() or (self.pack_thread and self.pack_thread.is_alive()):raise ValueError('Stop Play and wait for other asset operations')
        if sys.platform!='darwin':self.command_prefix('worldpack ');return
        r=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose file with prompt "Select an Aftershock World Materials ZIP pack")'],capture_output=True,text=True)
        if r.returncode==0:self.world_start_pack(r.stdout.strip())
    def world_start_pack(self,path):
        if self.playing or self.market_busy() or (self.pack_thread and self.pack_thread.is_alive()):raise ValueError('Stop Play and wait for other asset operations')
        from .world_assets import import_pack
        self.world_pack_active=True
        def run():
            try:
                n,k=import_pack(ROOT.parent.parent,path,self.pack_messages.put);self.pack_messages.put(f'World pack imported: {n} new, {k} already saved.')
            except Exception as exc:self.pack_messages.put('World pack stopped: '+str(exc)+'; completed materials preserved.')
            finally:self.world_pack_active=False
        self.pack_thread=threading.Thread(target=run,daemon=True);self.pack_thread.start();self.log('Importing World Materials pack…')
    def open_marketplace(self):
        if self.playing:raise ValueError('Stop Play before opening Marketplace')
        from .marketplace import Marketplace
        if self.market is None:self.market=Marketplace(ROOT.parent.parent)
        self.scene_tab();self.picker='marketplace';self.dirty=True
        if not self.market.items and not self.market.busy:self.market.refresh()
    def market_busy(self):
        return (self.market is not None and self.market.operation=='download') or bool(getattr(self,'world_pack_active',False))
    def market_download(self):
        if self.playing or self.update_close:raise ValueError('Stop Play before downloading')
        if self.market and self.market.native:raise ValueError('Close the previous download results first')
        if self.pack_thread and self.pack_thread.is_alive():raise ValueError('Wait for the material pack download to finish')
        if self.update_checker is not None and (self.update_checker.running or self.update_checker.visible):raise ValueError('Close the update check first')
        if not self.market or not self.market.start():return
        if self.update_checker is not None:
            try:self.update_checker.panel.asset_begin(len(self.market.cart));self.market.native=True
            except Exception as exc:self.log('Native download panel unavailable: '+str(exc))
        self.dirty=True
    def poll_marketplace(self):
        m=self.market
        if m is None:return
        if m.native and self.update_checker is not None:
            action=self.update_checker.panel.asset_action()
            if action==2:m.stop.set();m.status='Cancelling after the current file…'
            elif action==1:
                m.native=False
                try:self.restart_after_assets()
                except Exception as exc:self.log('Restart failed: '+str(exc))
            elif action==3:m.native=False;self.dirty=True
        if not m.poll():return
        self.dirty=True
        if m.native and self.update_checker is not None:
            panel=self.update_checker.panel
            if m.result is not None and not m.busy:
                n=sum(row[2] for row in m.result)
                panel.asset_result(n,'\n'.join(name+': '+('Installed' if ok else msg[:120]) for _,name,ok,msg in m.result) or 'Cancelled. No assets installed.')
            elif m.operation=='download':panel.asset_progress(m.fraction,m.status)
        if m.result is not None and not m.busy:
            for _,name,ok,msg in m.result:
                if not ok:self.log(name+': '+msg)
            self.log(m.status)
    def restart_after_assets(self):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads')
        if sys.platform!='darwin':self.log('Restart Studio manually to reload materials');return
        self.save_scripts();self.save()
        from launcher.update_manager import UpdateManager,atomic_json
        from launcher.update_progress import app_bundle,clean_environment
        manager=UpdateManager();bundle=app_bundle()
        with manager.lock():
            state=manager.state();state['resume_scene']=str(self.path.resolve());atomic_json(manager.state_path,state)
        python=os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE',sys.executable)
        worker="import os,sys,time,subprocess; pid=int(sys.argv[1]); end=time.monotonic()+60\nwhile time.monotonic()<end:\n try: os.kill(pid,0)\n except ProcessLookupError: subprocess.run(['/usr/bin/open','-n',sys.argv[2]]); break\n time.sleep(.15)"
        subprocess.Popen([python,'-c',worker,str(os.getpid()),str(bundle)],env=clean_environment(),start_new_session=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.update_close=True
    def open_market_materials(self):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads')
        self.scene_tab();self.picker='marketmaterials';self.market_material_offset=0;self.dirty=True
    def apply_market_material(self,slug):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads')
        from .materials import NAMES
        from .marketplace import apply_material
        if sys.platform!='darwin':self.command_prefix('marketapply '+slug+' ');return
        choices=', '.join('"'+n+'"' for n in NAMES if n!='Water')
        r=subprocess.run(['/usr/bin/osascript','-e','choose from list {'+choices+'} with prompt "Choose the existing material slot to replace (restart required)"'],capture_output=True,text=True)
        if r.returncode or r.stdout.strip()=='false':return
        slot=r.stdout.strip();apply_material(ROOT.parent.parent,slug,slot);self.log('Applied '+slug+' to '+slot+'. Restart Studio to load the maps.')
    def open_human_creator(self):
        if self.playing:raise ValueError('Stop Play before changing the player')
        self.picker='human';self.dirty=True
    def set_human_seed(self,seed):
        from .human import profile
        profile(seed)
        def op():self.scene.player_appearance=seed;self.scene.revision+=1
        self.change(op);self.log(f'Player appearance #{seed} saved in scene. Press Play to see it.')
    def random_human_seed(self):
        import random
        self.set_human_seed(random.SystemRandom().randrange(2**31))
    def native_menu_action(self,action):
        actions={10:lambda:self.open_template('Baseplate'),11:lambda:self.choose('open'),12:self.open_template_picker,13:self.save,14:lambda:self.choose('save'),15:self.save_scripts,16:self.export_dialog,20:self.undo,21:self.redo,30:self.scene_tab,31:self.script_editor,32:self.open_terrain,33:lambda:setattr(self,'world_tools',not self.world_tools),34:self.weather,35:lambda:self.set_environment(audio=not self.scene.environment.audio),36:self.open_human_creator,40:self.open_asset_library,41:self.open_marketplace,42:self.import_library_dialog,43:self.open_market_materials,44:self.import_pbr_dialog,50:lambda:setattr(self,'picker','graphics'),51:self.show_output,52:lambda:self.set_view('Perspective'),53:lambda:self.set_view('Top'),54:lambda:self.set_view('Front'),55:lambda:self.set_view('Side')}
        try:
            if action in actions:
                if self.market_busy() and action not in (40,41,51):raise ValueError('Wait for marketplace downloads to finish')
                if self.playing and action not in (30,51,52,53,54,55):raise ValueError('Stop Play first')
                actions[action]();self.dirty=True
        except Exception as exc:self.log(str(exc))
    def import_library_dialog(self):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads before importing models')
        if sys.platform!='darwin':self.command_prefix('assetimport ');return
        expression='set selectedFiles to choose file with prompt "Select extracted GLB, glTF or OBJ models (keep companion textures beside them)" with multiple selections allowed\nset resultText to ""\nrepeat with selectedFile in selectedFiles\nset resultText to resultText & (POSIX path of selectedFile) & linefeed\nend repeat\nreturn resultText'
        r=subprocess.run(['/usr/bin/osascript','-e',expression],capture_output=True,text=True)
        if r.returncode==0:self.import_library_paths(r.stdout.splitlines())
    def import_library_paths(self,paths):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads before importing models')
        if not paths:raise ValueError('Choose at least one model')
        success=0;errors=[]
        for path in paths:
            try:
                kind,_,name=import_model(path);self.library_selection=kind;success+=1
            except Exception as exc:errors.append(Path(path).name+': '+str(exc));self.log(errors[-1])
        self.asset_search='';self.asset_offset=self.library_offset=0;self.dirty=True
        self.log(f'Imported {success} asset(s); {len(errors)} failed'+(' | '+errors[-1][:160] if errors else '. Saved to project library.'))
    def select_library_asset(self,kind):
        self.library_selection=kind;self.dirty=True
    def insert_library_asset(self,kind=None,collider='box'):
        if self.playing:raise ValueError('Stop Play before inserting assets')
        kind=kind or self.library_selection
        if not kind:raise ValueError('Select an asset first')
        path=asset_path(kind)
        if not path.is_file():raise ValueError('Asset is missing from this project')
        data=asset_metadata(path);size=data['size'];height=float(data.get('extents',[size]*3)[1]);pos=self.placement(height)
        from .physics import Body
        def op():
            self.selected=self.scene.create(data['name'],Transform(pos,scale=(size,)*3),Mesh(color=(1.,1.,1.) if data.get('parts') else (.6,.6,.6),kind=kind))
            if collider=='mesh':self.scene.set_body(self.selected,Body('static','mesh'))
            elif collider=='box':
                # Fitted AABB is cheaper than triangle-mesh collision.
                self.scene.set_body(self.selected,Body('static','box'))
            return self.selected
        self.change(op);self.dismiss_picker();self.reveal();self.log('Placed '+data['name']+' | '+collider+' collider')
    def asset_source(self):
        if not self.library_selection:raise ValueError('Select an asset first')
        p=asset_path(self.library_selection);d=asset_metadata(p)
        if sys.platform!='darwin':self.command_prefix('assetcredit ');return
        # Only static prompt strings reach AppleScript; user text is passed as argv.
        script='on run argv\nset answer to display dialog (item 1 of argv) default answer (item 2 of argv) buttons {"Cancel", "Save"} default button "Save"\nreturn text returned of answer\nend run'
        for key,label in [('source','Original asset page URL'),('author','Creator / attribution'),('licence','Licence (e.g. CC0, CC BY 4.0)')]:
            r=subprocess.run(['/usr/bin/osascript','-e',script,label,str(d.get(key,''))],capture_output=True,text=True)
            if r.returncode!=0:return
            d[key]=r.stdout.strip()[:2048]
        write_metadata(p,d);self.log('Saved asset source and licence')
    def asset_folder(self):
        ROOT.mkdir(parents=True,exist_ok=True)
        if sys.platform=='darwin':subprocess.Popen(['/usr/bin/open',str(ROOT)])
        else:self.log(str(ROOT))
    def browse_asset_site(self,url):
        import webbrowser
        webbrowser.open(url)

    def import_pbr_dialog(self):
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads before importing materials')
        if sys.platform!='darwin':self.dismiss_picker();self.command_prefix('importpbr ');return
        from .materials import NAMES
        choices=', '.join('"'+n+'"' for n in NAMES if n!='Water')
        selection=subprocess.run(['/usr/bin/osascript','-e','choose from list {'+choices+'} with prompt "Choose the material to replace"'],capture_output=True,text=True)
        if selection.returncode or selection.stdout.strip()=='false':return
        folder=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose folder with prompt "Select folder with albedo, roughness and OpenGL normal maps")'],capture_output=True,text=True)
        if folder.returncode:return
        self.dismiss_picker();self.command='importpbr '+shlex.quote(selection.stdout.strip())+' '+shlex.quote(folder.stdout.strip());self.execute(self.graphics)
    def install_scanned_pack(self):
        if self.market_busy():raise ValueError('Wait for marketplace downloads')
        if self.playing or self.market_busy():raise ValueError('Stop Play and wait for downloads before importing materials')
        if self.pack_thread and self.pack_thread.is_alive():self.log('Poly Haven material download already running');return
        if sys.platform=='darwin':
            result=subprocess.run(['/usr/bin/osascript','-e','display dialog "Download eight 1K CC0 materials from Poly Haven into this project? Existing overrides are preserved. Allow disk space for up to about 64 MB of imported maps. Restart Studio afterwards." buttons {"Cancel", "Download"} default button "Download" with title "Poly Haven Material Pack"'],capture_output=True,text=True)
            if result.returncode:return
        from .scanned_pack import install_real_world
        def work():
            try:
                results=install_real_world(ROOT.parent.parent,self.pack_messages.put)
                n=sum(v=='Installed' for v in results.values());self.pack_messages.put(f'Poly Haven pack: {n} installed; '+str(sum(v.startswith("Failed") for v in results.values()))+' failed. Restart Studio to load imported maps.')
            except Exception as exc:self.pack_messages.put('Poly Haven pack failed: '+str(exc))
        self.pack_thread=threading.Thread(target=work,daemon=True);self.pack_thread.start();self.log('Downloading Poly Haven scanned material pack…')
    def poll_material_pack(self):
        while True:
            try:self.log(self.pack_messages.get_nowait())
            except queue.Empty:break
    def update_error(self,exc):
        self.log('Update failed: '+str(exc));self.output_expanded=True
        if sys.platform=='darwin':
            dialog='on run argv\n display dialog (item 1 of argv) buttons {"OK"} with title "Aftershock Update Failed" with icon stop\nend run'
            subprocess.run(['/usr/bin/osascript','-e',dialog,str(exc)],capture_output=True,text=True)
    def update_menu(self):
        if self.market_busy():self.log('Wait for marketplace downloads');return
        try:
            if self.update_checker is not None:self.update_checker.start()
            else:self._update_menu()
        except Exception as exc:self.update_error(exc)
    def update_options(self):
        if self.market_busy():self.log('Wait for marketplace downloads');return
        try:self._update_menu()
        except Exception as exc:self.update_error(exc)
    def _update_menu(self):
        if self.playing: raise ValueError('Stop Play before updating')
        if sys.platform!='darwin': self.command_prefix('update ');return
        from launcher.update_manager import UpdateManager
        manager=UpdateManager();state=manager.state()
        from launcher.online_updates import get_repo, set_repo, check
        choices=['Check GitHub for updates','Configure GitHub repository','Install ZIP…','Refresh startup screen…','Restore original startup screen…']
        if state['previous'] is not None:choices.append('Restore previous version…')
        # choose from list supports more than three native dialog buttons.
        source='on run argv\n set resultList to choose from list argv with title "Aftershock Updates" with prompt "Engine '+config.VERSION+' | Choose an update action" default items {item 1 of argv}\n if resultList is false then return ""\n return item 1 of resultList\nend run'
        result=subprocess.run(['/usr/bin/osascript','-e',source,*choices],capture_output=True,text=True)
        if result.returncode:return
        action=result.stdout.strip()
        if action in ('Refresh startup screen…','Restore original startup screen…'):
            restore=action.startswith('Restore')
            source='display dialog "This will change only the native developer launcher. Your engine and projects stay intact. The original launcher is backed up. Changes appear next time you open Studio." buttons {"Cancel", "Continue"} default button "Cancel" with title "Aftershock Startup Screen"'
            answer=subprocess.run(['/usr/bin/osascript','-e',source],capture_output=True,text=True)
            if answer.returncode or 'Continue' not in answer.stdout:return
            from launcher.refresh_host import refresh
            backup=refresh(restore=restore);self.log('Startup screen refreshed; changes apply on next launch. Original launcher backup: '+str(backup));self.output_expanded=True
            return
        if action=='Restore previous version…':self.request_rollback();return
        if action=='Configure GitHub repository':
            source='on run argv\n display dialog "Only use a public repository you trust. Releases contain executable engine code." default answer (item 1 of argv) buttons {"Cancel", "Save"} default button "Cancel" with title "GitHub Update Source"\n return text returned of result\nend run'
            result=subprocess.run(['/usr/bin/osascript','-e',source,get_repo(manager)],capture_output=True,text=True)
            if result.returncode==0:self.log('Update repository: '+set_repo(manager,result.stdout.strip()))
            return
        if action=='Check GitHub for updates':
            if self.update_checker is not None:self.update_checker.start();return
            repo=get_repo(manager);asset=check(repo,config.VERSION)
            if asset is None:
                source='on run argv\n display dialog (item 1 of argv) buttons {"OK"} with title "Aftershock Updates"\nend run'
                subprocess.run(['/usr/bin/osascript','-e',source,'No compatible published update found for '+config.VERSION+' in '+repo+'.'],capture_output=True,text=True);return
            self.request_online_update(asset);return
        if action!='Install ZIP…':return
        choice=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose file with prompt "Select an Aftershock update ZIP")'],capture_output=True,text=True)
        if choice.returncode==0:self.request_update(choice.stdout.strip())
    def request_online_update(self,asset,confirmed=False):
        if self.market_busy():raise ValueError('Wait for marketplace downloads')
        if self.playing:raise ValueError('Stop Play before updating')
        if not os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):raise ValueError('Open Aftershock Studio.app to use updates')
        target=asset['target'];size=asset['size']/1048576
        if not confirmed and not self.confirm_update(f"Download Aftershock {target} ({size:.2f} MB) from {asset['repository']}?\n\nOnly install executable updates from a repository you trust. Studio will save, close, download and install the patch, then reopen automatically."):return
        self.save_scripts();self.save()
        from launcher.update_manager import ROOT as engine_root
        from launcher.update_progress import start_update
        start_update(engine_root,None,target,self.path,online=asset)
        self.log('Downloading update '+target+' and restarting…');self.update_close=True
    def confirm_update(self,message):
        if sys.platform!='darwin':raise ValueError('Offline update confirmation is supported in the macOS app')
        source='on run argv\n display dialog (item 1 of argv) buttons {"Cancel", "Install & Restart"} default button "Cancel" cancel button "Cancel" with title "Aftershock Updates"\nend run'
        result=subprocess.run(['/usr/bin/osascript','-e',source,message],capture_output=True,text=True)
        return result.returncode==0 and 'Install & Restart' in result.stdout
    def request_update(self,path):
        if self.market_busy():raise ValueError('Wait for marketplace downloads')
        if self.playing:raise ValueError('Stop Play before updating')
        if not os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):raise ValueError('Open Aftershock Studio.app to use updates')
        from launcher.update_manager import UpdateManager, ROOT as engine_root
        manager=UpdateManager();manifest=manager.inspect(Path(path).expanduser(),engine_root)
        target=manifest['target']
        if not self.confirm_update('Install Aftershock Engine '+target+'?\n\nOnly install ZIPs you trust. Checksums detect corruption but do not authenticate the publisher. Studio will save your scene and scripts, close, show installation progress, and reopen automatically.'):return
        self.save_scripts();self.save()
        from launcher.update_progress import start_update
        start_update(engine_root,Path(path).expanduser(),target,self.path)
        self.log('Installing update '+target+' and restarting…');self.update_close=True
    def request_rollback(self):
        if self.market_busy():raise ValueError('Wait for marketplace downloads')
        if self.playing:raise ValueError('Stop Play before restoring')
        if not os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):raise ValueError('Open Aftershock Studio.app to use updates')
        from launcher.update_manager import UpdateManager
        manager=UpdateManager()
        if not self.confirm_update('Restore the previous engine version?\n\nYour current scene and scripts will be saved, then Studio will close. Newer project formats may not be readable by older engines. Studio will reopen automatically.'):return
        self.save_scripts();self.save()
        from launcher.update_progress import start_update
        from launcher.update_manager import ROOT as engine_root
        start_update(engine_root,None,None,self.path);self.update_close=True
    def open_template_picker(self):
        if self.playing:raise ValueError('Stop Play before opening a template')
        self.scene_tab();self.picker='templates';self.dirty=True
    def dismiss_picker(self):
        self.picker=None;self.dirty=True
    def open_template(self,name):
        from .templates import make_template,template_view
        if self.playing:raise ValueError('Stop Play before opening a template')
        template=make_template(name)
        self.change(lambda:self.restore((template.to_data(),None)))
        # New filename avoids overwriting the current scene or another template instance.
        self.path=SCENES/(name.lower().replace(' ','_')+'_'+uuid.uuid4().hex[:8]+'.json')
        self.scene_tab();self.close_world_tools();self.dismiss_picker();self.search='';self.offset=0;self.view_mode='Perspective'
        if self.camera is not None:
            x,y,z,yaw,pitch=template_view(template,name);self.camera.position[:]=(x,y,z);self.camera.yaw,self.camera.pitch=yaw,pitch
        self.log(name+' opened | Play to spawn automatically. Save to keep this new scene. Undo restores the previous scene.')
    def add_menu(self):
        if self.playing:raise ValueError('Stop Play before adding objects')
        self.picker='objects';self.dirty=True
    def placement(self,size=2.):
        # Place on the ground under the middle of the viewport when possible.
        if self.camera is None:return (0.,0. if size==0 else max(2.,size/2),0.)
        origin=self.camera.position;direction=self.camera.forward
        if self.scene.terrain is not None:
            hit=self.scene.terrain.ray(origin,direction)
            if hit is not None and np.linalg.norm(hit-origin)<120:return (float(hit[0]),float(hit[1])+size/2,float(hit[2]))
        elif direction[1]<-.01:
            k=-origin[1]/direction[1]
            if 2<k<80:
                hit=origin+direction*k;return (float(hit[0]),size/2,float(hit[2]))
        return tuple(origin+direction*8)
    def add_object(self,kind):
        from .physics import Body
        from .templates import add_spawn
        if kind=='Player Spawn':
            pos=self.placement(0.);self.change(lambda:setattr(self,'selected',add_spawn(self.scene,pos)))
        elif kind=='Ground':
            def op():
                self.selected=self.scene.create('Ground',Transform((0,-.5,0),scale=(160,1,160)),Mesh((.48,.52,.50),material=(.88,0,0,PATTERNS.index('Concrete'))));self.scene.set_body(self.selected,Body())
            self.change(op)
        elif kind=='Dynamic Crate':
            def op():
                pos=self.placement(1.);self.selected=self.scene.create('Crate',Transform((pos[0],pos[1]+1,pos[2])),Mesh((.8,.65,.45),material=(.8,0,0,PATTERNS.index('Wood'))));self.scene.set_body(self.selected,Body('dynamic'))
            self.change(op)
        elif kind=='Tree':
            from .city import box
            def op():
                x,y,z=self.placement(0.);self.selected=box(self.scene,'Tree trunk',(x,y+1.6,z),(.42,3.2,.42),(.38,.23,.14),solid=True,kind='builtin:tree_trunk');box(self.scene,'Tree canopy',(x,y+4,z),(3.5,3,3.5),(.20,.43,.15),kind='builtin:tree_crown')
            self.change(op)
        elif kind=='Empty':self.create('empty',1.,'Empty')
        elif kind=='Cube':
            def op():
                self.selected=self.scene.create('Cube',Transform(self.placement(2.),scale=(2,2,2)),Mesh());self.scene.set_body(self.selected,Body())
            self.change(op)
        else:raise ValueError('Unknown object')
        self.dismiss_picker();self.clear_search();self.reveal();self.log(kind+' added')
    def export_dialog(self):
        if self.playing:raise ValueError('Stop Play before exporting')
        if sys.platform!='darwin':self.command_prefix('export ');return
        ask='on run argv\n text returned of (display dialog "Game name" default answer (item 1 of argv) with title "Export Aftershock Game")\nend run'
        result=subprocess.run(['/usr/bin/osascript','-e',ask,self.scene.name],capture_output=True,text=True)
        if result.returncode:return
        name=result.stdout.strip()
        folder=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose folder with prompt "Choose a folder for the exported game app")'],capture_output=True,text=True)
        if folder.returncode:return
        mode=subprocess.run(['/usr/bin/osascript','-e','display dialog "Include your current project Luau scripts? Scene Only is useful for testing templates." buttons {"Cancel", "Scene Only", "Include Scripts"} default button "Include Scripts" cancel button "Cancel" with title "Export Aftershock Game"'],capture_output=True,text=True)
        if mode.returncode:return
        self.export_game(folder.stdout.strip(),name,run_scripts='Include Scripts' in mode.stdout)
    def export_game(self,folder,name,run_scripts=True):
        if self.playing:raise ValueError('Stop Play before exporting')
        from .game_export import export_game
        self.save_scripts()
        quality=getattr(getattr(self,'graphics',None),'quality',None)
        path=export_game(self.scene,folder,name,quality=quality.name.lower() if quality else 'medium',run_scripts=run_scripts)
        self.log('Game exported: '+str(path));self.output_expanded=True
        if sys.platform=='darwin':subprocess.run(['/usr/bin/open','-R',str(path)],capture_output=True)
        return path
    def city_demo(self):
        from .city import demo
        self.change(lambda:self.restore((demo().to_data(),None)))
        self.path=SCENES/"living_district.json";self.scene_tab();self.world_tools=True
        if getattr(self,"camera",None) is not None:
            self.camera.position[:]=(10,22,40);self.camera.yaw,self.camera.pitch=-105,-24
        self.log("Living District created. Play > G > E near blue car; WASD, Space brake, E exit.")
    def close_world_tools(self):
        self.road_points=None;self.world_tools=False;self.dirty=True
    def road_tool(self):
        if self.playing:raise ValueError('Stop Play before road editing')
        self.road_points=[];self.world_tools=True;self.log('Click ground to add road points, then Finish road.')
    def road_finish(self):
        from .city import add_road
        if self.road_points is None or len(self.road_points)<2:raise ValueError('Place at least two road points')
        points=list(self.road_points);self.change(lambda:add_road(self.scene,points,10));self.road_points=None;self.log('Road built; Undo supported')
    def city_setting(self,**changes):
        from .city import validate
        data=validate({**(self.scene.city or {}),**changes})
        def op():self.scene.city=data;self.scene.revision+=1
        self.change(op)
    def weather(self):
        from .environment import PRESETS
        names=list(PRESETS); old=self.scene.environment
        self.set_environment(weather=names[(names.index(old.weather)+1)%len(names)])
    def set_environment(self,**values):
        def op():self.scene.environment=replace(self.scene.environment,**values)
        if self.playing:op();self.dirty=True
        else:self.change(op)
    def clear_search(self): self.search=""; self.offset=0; self.dirty=True
    def sync(self,scene):
        if self.scene is not scene:
            self.history.clear(); self.future.clear(); self.drag=None; self.camera_drag=None; self.selected=None; self.offset=0; self.revision=-1
        self.scene=scene
        if self.revision!=scene.revision:
            self.ids=[]; self.depth={}; pending=[(e,0) for e in sorted(scene.children[None],key=lambda e:(scene.names[e],e),reverse=True)]
            while pending:
                e,d=pending.pop(); self.ids.append(e); self.depth[e]=d
                pending.extend((c,d+1) for c in sorted(scene.children[e],key=lambda c:(scene.names[c],c),reverse=True))
            if self.selected not in scene.names: self.selected=None
            self.offset=min(self.offset,max(0,len(self.ids)-1)); self.revision=scene.revision; self.dirty=True
    def remember(self):
        self.history.append((self.scene.to_data(),self.selected)); self.history=self.history[-12:]; self.future.clear()
    def restore(self,snapshot,restored=None):
        data,selection=snapshot; restored=Scene.from_data(data) if restored is None else restored
        # preserve identity shared with application, but invalidate renderer caches
        revision=self.scene.revision+1; self.scene.__dict__.update(restored.__dict__); self.scene.revision=revision; self.selected=selection; self.sync(self.scene)
    def undo(self):
        if self.history and not self.playing:
            self.future.append((self.scene.to_data(),self.selected)); self.restore(self.history.pop()); self.log('Undo')
    def redo(self):
        if self.future and not self.playing:
            self.history.append((self.scene.to_data(),self.selected)); self.restore(self.future.pop()); self.log('Redo')
    def select(self,eid):
        self.sync(self.scene)
        self.surface_dropdown=False;self.selected=eid if eid in self.scene.names else None; self.dirty=True
        if eid in self.ids:
            i=self.ids.index(eid); self.offset=min(self.offset,i) if i<self.offset else self.offset
    def change(self,fn):
        if self.playing: raise ValueError('Stop play mode before editing')
        before=(self.scene.to_data(),self.selected)
        result=fn(); self.history.append(before); self.history=self.history[-12:]; self.future.clear(); self.sync(self.scene); self.dirty=True; return result
    def require(self):
        if self.selected not in self.scene.names: raise ValueError('Select an entity first')
        return self.selected
    def create(self,kind='cube',size=2.,name='Cube'):
        def op():
            pos=(0,2,0)
            if self.camera is not None: pos=self.placement(size)
            self.selected=self.scene.create(name,Transform(pos,scale=(size,)*3),None if kind=='empty' else Mesh(kind=kind)); return self.selected
        self.change(op); self.reveal()
    def reveal(self):
        if self.selected in self.ids: self.offset=max(0,self.ids.index(self.selected)-2)
    def duplicate(self):
        source=self.require()
        def op():
            mapping={}; pending=[source]
            while pending:
                e=pending.pop(); p=self.scene.parents[e]; t=self.scene.transforms[e]
                if e==source: t=replace(t,position=(t.position[0]+2,t.position[1],t.position[2]))
                mapping[e]=self.scene.create(self.scene.names[e]+(' Copy' if e==source else ''),t,self.scene.meshes.get(e),mapping.get(p,p),self.scene.spins.get(e)); pending.extend(list(self.scene.children[e]))
            for old,new in mapping.items():
                if old in self.scene.bodies: self.scene.set_body(new,self.scene.bodies[old])
            self.selected=mapping[source]
        self.change(op); self.reveal()
    def delete(self):
        e=self.require(); self.change(lambda:self.scene.destroy(e)); self.selected=None
    def edit_vector(self,field,values):
        e=self.require(); self.change(lambda:self.scene.set_transform(e,replace(self.scene.transforms[e],**{field:tuple(values)})))
    def material(self,color=None,values=None):
        e=self.require(); m=self.scene.meshes.get(e)
        if m is None: raise ValueError('Entity has no mesh')
        new=replace(m,**({'color':tuple(color)} if color is not None else {'material':tuple(values)}))
        def op(): self.scene.meshes[e]=new; self.scene.revision+=1
        self.change(op)
    def surface_material(self,name):
        self.surface_dropdown=False
        if name not in PATTERNS:raise ValueError('Unknown material preset')
        e=self.require();m=self.scene.meshes[e];i=PATTERNS.index(name)
        if i>=4:
            _,_,rough,metal=SPECS[i-4];self.material(values=(rough,metal,0,i))
        else:self.material(values=(m.material[0],m.material[1],m.material[2],i))
    def play(self):
        if self.market_busy():raise ValueError('Wait for marketplace downloads')
        if not self.playing:
            self.save_scripts()
            self.scene_tab()
            self.road_points=None;self.saved_edit=(self.scene.to_data(),self.selected)
            if self.on_play_start: self.on_play_start()
            self.drag=None; self.playing=True; self.log('PLAY PREVIEW | fixed-step systems running')
        else:
            # Validate the saved snapshot before stopping the live world.
            restored=Scene.from_data(self.saved_edit[0])
            if self.on_play_stop: self.on_play_stop()
            self.restore(self.saved_edit,restored); self.saved_edit=None; self.playing=False; self.drag=None; self.log('Stopped | edit scene restored')
    def save(self,path=None):
        if self.playing: raise ValueError('Stop play mode before saving')
        target=Path(path).expanduser() if path else self.path
        self.scene.save(target); self.path=target; self.log('Saved '+target.name)
    def open(self,path):
        target=Path(path).expanduser(); data=Scene.load(target).to_data(); self.change(lambda:self.restore((data,None))); self.path=target; self.log('Opened '+target.name)
    def command_prefix(self,s): self.command=s; self.typing=True; self.dirty=True
    def execute(self,g):
        raw=self.command; self.command=''; self.typing=False
        try:
            args=shlex.split(raw); cmd=args.pop(0).lower() if args else ''
            if not cmd: return
            if cmd=='worldfind':
                self.world_query=' '.join(args);self.world_offset=0;self.dirty=True;return
            if cmd=='worldpack':
                if len(args)!=1:raise ValueError('worldpack ZIP')
                self.world_start_pack(args[0]);return
            if cmd=='worldapply':
                if self.playing or self.market_busy() or len(args)!=2:raise ValueError('worldapply ID MATERIAL')
                from .world_assets import apply_material
                apply_material(ROOT.parent.parent,args[0],getattr(self,'world_resolution',1024),args[1].title());self.log('Material applied; restart Studio');return
            if cmd=='marketfind':
                if self.market:self.market.query=' '.join(args);self.market.offset=0;self.dirty=True
                return
            if cmd=='marketapply':
                if self.playing or self.market_busy() or len(args)!=2:raise ValueError('marketapply SLUG MATERIAL')
                from .marketplace import apply_material
                apply_material(ROOT.parent.parent,args[0],args[1].title());self.log('Material applied; restart Studio');return
            if cmd=='assetimport':
                self.import_library_paths(args);return
            if cmd=='assetcredit':
                if not self.library_selection or len(args)!=3:raise ValueError('assetcredit "SOURCE URL" "AUTHOR" "LICENCE"')
                p=asset_path(self.library_selection);d=asset_metadata(p);d.update(zip(('source','author','licence'),args));write_metadata(p,d);self.log('Saved asset credits');return
            if cmd=='importpbr':
                if self.playing or len(args)!=2:raise ValueError('Stop Play and use importpbr MATERIAL FOLDER')
                from .materials import import_pbr
                import_pbr(ROOT.parent.parent,args[0].title(),args[1]);self.log('PBR material imported. Restart Studio to load it.');self.output_expanded=True;return
            if cmd=='find': self.search=' '.join(args).casefold(); self.offset=0; self.log('Explorer filter: '+(self.search or 'All')); return
            if cmd=='help': self.log('new/save/open/import/pos/rot/scale/mat/body/velocity/solid/playground/time'); return
            if cmd=='citydemo':self.city_demo();return
            elif cmd=='road':
                from .city import add_road
                if len(args)<5 or len(args)%2!=1:raise ValueError('road WIDTH X1 Z1 X2 Z2 [X3 Z3 ...]')
                width=float(args[0]);points=list(zip(map(float,args[1::2]),map(float,args[2::2])));self.change(lambda:add_road(self.scene,points,width))
            elif cmd=='population':self.city_setting(traffic=int(args[0]),pedestrians=int(args[1]))
            elif cmd=='vehicle':self.city_setting(vehicle=args[0].title())
            elif cmd=='human':
                if len(args)!=1:raise ValueError('human SEED (0 to 2147483647)')
                self.set_human_seed(int(args[0]))
            elif cmd=='clip':
                from .animation import load_clips,clip_data
                if len(args)!=2:raise ValueError('clip NAME DURATION')
                name=args[0];duration=float(args[1]);data=clip_data(self.scene.clips);data[name]=dict(duration=duration,keys=[(0,0,0,0),(duration,0,0,0)])
                clips=load_clips(data);self.change(lambda:setattr(self.scene,'clips',clips));self.log('Clip '+name+' created; key NAME TIME STRIDE CROUCH AIR');return
            elif cmd=='key':
                from .animation import load_clips,clip_data
                if len(args)!=5:raise ValueError('key NAME TIME STRIDE CROUCH AIR')
                data=clip_data(self.scene.clips);item=data[args[0]];key=tuple(map(float,args[1:]));item['keys']=sorted([k for k in item['keys'] if k[0]!=key[0]]+[key]);clips=load_clips(data);self.change(lambda:setattr(self.scene,'clips',clips))
            elif cmd=='animation':
                from .animation import CLIPS
                value=args[0];names={n.casefold():n for n in (*CLIPS,*self.scene.clips)}
                if value.casefold()=='auto':self.animation_preview=None
                elif value.casefold() in names:self.animation_preview=names[value.casefold()]
                else:raise ValueError('Unknown animation clip; choose Auto or a built-in/custom clip')
            elif cmd=='assetfind':self.asset_search=' '.join(args).casefold();self.asset_offset=self.library_offset=0
            elif cmd=='door':
                from .interactions import register
                eid=self.require();self.change(lambda:register(self.scene,eid))
            elif cmd=='emitter':
                from .audio import validate_emitter
                if len(self.scene.emitters)>=32:raise ValueError('Maximum 32 sound emitters')
                if len(args)!=7:raise ValueError('emitter SOUND X Y Z VOLUME RADIUS INTERVAL')
                e=validate_emitter(dict(sound=args[0],position=list(map(float,args[1:4])),volume=float(args[4]),radius=float(args[5]),interval=float(args[6])))
                self.change(lambda:self.scene.emitters.append(e))
            elif cmd=='clearemitters':self.change(lambda:self.scene.emitters.clear())
            elif cmd=='skinning':g.skinning=not g.skinning
            elif cmd=='adaptive':g.adaptive=not g.adaptive
            elif cmd=='terrainseed':
                seed=int(args[0]);Terrain(self.terrain_preset,seed,self.terrain_size,self.terrain_water);self.terrain_seed=seed
            elif cmd=='terrainwater':
                level=float(args[0]);Terrain(self.terrain_preset,self.terrain_seed,self.terrain_size,level);self.terrain_water=level
            elif cmd=='heightimport':self.terrain_map(args[0])
            elif cmd=='heightexport':self.terrain_map(args[0],True)
            elif cmd=='new': self.open_template('Baseplate');return
            elif cmd=='template': self.open_template(' '.join(args));return
            elif cmd=='export':
                if len(args)!=2:raise ValueError('export FOLDER NAME (quote spaces)')
                self.export_game(args[0],args[1]);return
            elif cmd=='save': self.save(args[0] if args else None); return
            elif cmd=='update': self.request_update(args[0]); return
            elif cmd=='rollback': self.request_rollback(); return
            elif cmd=='open': self.open(args[0]); return
            elif cmd=='import':
                if self.playing: raise ValueError('Stop play mode first')
                k,size,name=import_model(args[0]); self.insert_library_asset(k,'none')
            elif cmd=='colliders': self.debug_colliders=not self.debug_colliders
            elif cmd=='playground':
                from .world import playground
                count=int(args[0]) if args else 60
                if not 0<=count<=1000: raise ValueError('Choose 0-1000 crates')
                self.change(lambda:self.restore((playground(count).to_data(),None)))
            elif cmd=='solid':
                from .world import solid_city
                self.change(lambda:solid_city(self.scene))
            elif cmd=='body':
                from .physics import Body
                e=self.require()
                if args==['remove']: self.change(lambda:self.scene.set_body(e,None))
                else:
                    if len(args)<2 or len(args)>7: raise ValueError('body static/dynamic/kinematic box/sphere/capsule/cylinder/convex/mesh [mass friction bounce gravity(0/1) ccd(0/1)]')
                    v=args[2:]; flags=[bool(int(x)) for x in v[3:]]
                    if any(x not in ('0','1') for x in v[3:]): raise ValueError('Gravity and CCD use 0 or 1')
                    b=Body(args[0],args[1],*map(float,v[:3]),*flags)
                    self.change(lambda:self.scene.set_body(e,b))
            elif cmd=='velocity':
                e=self.require(); b=replace(self.scene.bodies[e],velocity=tuple(map(float,args)))
                self.change(lambda:self.scene.set_body(e,b))
            elif cmd=='rename':
                e=self.require(); name=' '.join(args).strip()
                if not name: raise ValueError('Enter a name')
                def op(): self.scene.names[e]=name; self.scene.revision+=1
                self.change(op)
            elif cmd=='parent':
                e=self.require(); i=int(args[0])-1 if args[0]!='root' else None
                if i is not None and not 0<=i<len(self.ids): raise ValueError('Invalid hierarchy row')
                self.change(lambda:self.scene.reparent(e,None if i is None else self.ids[i]))
            elif cmd in ('pos','rot','scale'): self.edit_vector({'pos':'position','rot':'rotation','scale':'scale'}[cmd],map(float,args))
            elif cmd=='color': self.material(color=list(map(float,args)))
            elif cmd=='mat': self.material(values=list(map(float,args)))
            elif cmd=='material': self.surface_material(next((n for n in PATTERNS if n.casefold()==' '.join(args).casefold()),''))
            elif cmd=='weather':
                from .environment import PRESETS
                self.set_environment(weather=next(n for n in PRESETS if n.casefold()==args[0].casefold()))
            elif cmd=='audio':self.set_environment(audio=args[0].lower()=='on')
            elif cmd=='volume':self.set_environment(volume=float(args[0]))
            elif cmd=='time':
                v=float(args[0]);
                if not math.isfinite(v): raise ValueError('Time must be finite')
                g.hour=v%24
            elif cmd=='exposure':
                v=float(args[0]);
                if not math.isfinite(v): raise ValueError('Exposure must be finite')
                g.exposure=max(.1,min(4,v))
            elif cmd=='select':
                i=int(args[0])-1
                if not 0<=i<len(self.ids): raise ValueError('Invalid hierarchy row')
                self.select(self.ids[i]); self.reveal()
            elif cmd=='undo': self.undo(); return
            elif cmd=='redo': self.redo(); return
            else: raise ValueError('Unknown command; type help')
            self.log('Applied '+cmd)
        except Exception as exc: self.log(exc)
    def viewport(self,w,h):
        left=min(220,max(130,w//5)); right=min(275,max(150,w//4)); top=108; bottom=max(top+1,h-(238 if self.output_expanded else 144))
        return left,top,max(1,w-left-right),max(1,bottom-top)
    def projection(self,w,h):
        if self.view_mode=='Perspective': return perspective(config.FOV,w/max(1,h),config.NEAR,2600. if self.scene.terrain is not None else 2200. if self.scene.name=='Stress City' else config.FAR)
        size=self.ortho_size; aspect=w/max(1,h); n,f=.1,2200.; p=np.diag([1/(size*aspect),1/size,-2/(f-n),1]).astype('f4'); p[2,3]=-(f+n)/(f-n); return p
    def ray(self,x,y):
        l,t,w,h=self.rect; u=2*(x-l)/w-1; v=1-2*(y-t)/h
        inv=np.linalg.inv(self.projection(w,h)@self.camera.view()); a=inv@np.array([u,v,-1,1]); b=inv@np.array([u,v,1,1]); a=a[:3]/a[3]; b=b[:3]/b[3]; d=b-a; return a,d/np.linalg.norm(d)
    def project(self,p):
        l,t,w,h=self.rect; v=self.projection(w,h)@self.camera.view()@np.r_[p,1]
        if v[3]<=0: return None
        q=v[:3]/v[3]; return np.array([l+(q[0]+1)*w/2,t+(1-q[1])*h/2])
    def set_view(self,mode):
        self.view_mode=mode; target=np.zeros(3)
        if self.selected: target=world_matrices(self.scene)[self.selected][:3,3]
        c=self.camera
        if mode=='Top': c.yaw,c.pitch=-90,-89.9
        elif mode=='Front': c.yaw,c.pitch=-90,0
        elif mode=='Side': c.yaw,c.pitch=180,0
        else: c.yaw,c.pitch=-122,-23
        c.position[:]=target-c.forward*85; self.dirty=True
    def focus_selection(self):
        if self.playing or self.picker or self.script_tab or self.typing or self.terrain_tab or self.selected not in self.scene.names or self.camera is None:return False
        mats=world_matrices(self.scene); pending=[self.selected]; points=[]
        corners=np.array([[x,y,z,1.] for x in (-.5,.5) for y in (-.5,.5) for z in (-.5,.5)])
        while pending:
            e=pending.pop();pending.extend(self.scene.children[e])
            if e in self.scene.meshes:points.extend((mats[e]@corners.T).T[:,:3])
        if not points:points=[mats[self.selected][:3,3]]
        self.view_mode='Perspective'; self.drag=None; self.camera_drag=None
        frame_selection(self.camera,points,self.rect[2]/max(1,self.rect[3]),config.FOV,config.NEAR)
        self.dirty=True;return True
    def start_drag(self,e,axis,q,delta=None,ring=None):
        mat=world_matrices(self.scene);p=mat[e][:3,3].copy();parent=self.scene.parents[e]
        basis=mat[parent][:3,:3].copy() if parent is not None else np.eye(3)
        original=self.scene.transforms[e]; a=axes_for(original,basis,self.mode)[axis] if axis is not None else None
        o,d=self.ray(*q);normal=self.camera.forward.copy();hit=plane_hit(o,d,p,normal)
        param=axis_parameter(o,d,p,a) if a is not None else None
        self.drag=dict(e=e,axis=axis,start=q,delta=delta,original=original,mode=self.mode,length=getattr(self,'gizmo_length',1.),point=p,basis=basis,vector=a,normal=normal,hit=hit,param=param,ring=ring,remembered=False)
    def click(self,x,y,control=False):
        self.typing=False
        try:
            for x1,y1,x2,y2,fn in reversed(self.buttons):
                if x1<=x<x2 and y1<=y<y2: fn(); self.dirty=True; return
            if self.picker:return
            if self.script_tab:
                self.code.click(x,y); self.dirty=True; return
            l,t,w,h=self.rect
            if not self.playing and l<=x<l+w and t<=y<t+h:
                if control:
                    self.drag=None;self.camera_drag=(x,y);self.view_mode='Perspective';self.dirty=True;return
                if self.terrain_tab:self.terrain_stamp(x,y);return
                if self.road_points is not None:
                    origin,direction=self.ray(x,y)
                    if self.scene.terrain is not None:hit=self.scene.terrain.ray(origin,direction)
                    else:
                        k=-origin[1]/direction[1] if abs(direction[1])>1e-7 else -1;hit=origin+direction*k if k>=0 else None
                    if hit is not None and len(self.road_points)<64:
                        point=(round(float(hit[0])/2)*2,round(float(hit[2])/2)*2)
                        if not self.road_points or math.dist(point,self.road_points[-1])>=1:self.road_points.append(point);self.log(f'Road point {len(self.road_points)}: {point}')
                    return
                q=np.array([x,y],dtype=float)
                if self.selected in self.scene.names:
                    if self.mode=='rotate':
                        hits=[]
                        for axis,segments in self.rings:
                            for a,b,wa,wb in segments:
                                dist,f=nearest_segment(q,a,b)
                                if dist<9:hits.append((dist,axis,b-a,wa+(wb-wa)*f))
                        if hits:
                            _,axis,tangent,point=min(hits,key=lambda h:h[0]);self.start_drag(self.selected,axis,q,tangent,point);return
                    else:
                        hits=[]
                        for axis,a,b in self.gizmo:
                            dist,f=nearest_segment(q,a,b)
                            if f>.18 and dist<10:hits.append((dist,axis,b-a))
                        if hits:
                            _,axis,delta=min(hits,key=lambda h:h[0]);self.start_drag(self.selected,axis,q,delta);return
                self.select(pick(self.scene,*self.ray(x,y))); self.reveal()
                if self.mode=='move' and self.selected is not None:self.start_drag(self.selected,None,q)
        except Exception as exc: self.log(exc)
        self.dirty=True
    def motion(self,x,y,down):
        old=self.pointer; self.pointer=(x,y)
        # Redraw only when entering or leaving a control, not for every mouse movement.
        def hover(p): return next((i for i,(a,b,c,d,_) in enumerate(self.buttons) if a<=p[0]<c and b<=p[1]<d),None)
        if hover(old)!=hover(self.pointer): self.dirty=True
        if self.camera_drag is not None:
            if not down or self.playing or self.picker or self.script_tab:self.camera_drag=None;return
            px,py=self.camera_drag;self.camera.look(x-px,y-py);self.camera_drag=(x,y);self.dirty=True;return
        if self.script_tab:
            if self.code: self.code.motion(x,y,down)
            return
        if self.terrain_tab or self.picker or self.playing:self.drag=None;return
        if not self.drag:return
        if not down:self.drag=None;self.dirty=True;return
        drag=self.drag;e=drag['e'];original=drag['original'];axis=drag['axis'];mode=drag['mode']
        if e not in self.scene.names or e!=self.selected:self.drag=None;return
        q=np.array([x,y]);motion=q-drag['start']
        if not drag['remembered'] and np.linalg.norm(motion)<3:return
        o,d=self.ray(x,y);p=drag['point'];a=drag['vector'];delta=drag['delta']
        if mode=='move' and axis is None:
            hit=plane_hit(o,d,p,drag['normal'])
            if hit is None or drag['hit'] is None:return
            displacement=hit-drag['hit']
            new=replace(original,position=tuple(np.array(original.position)+np.linalg.solve(drag['basis'],displacement)))
        elif mode=='rotate':
            start_vec=drag['ring']-p; hit=plane_hit(o,d,p,a)
            if hit is not None and abs(np.dot(d,a))>.15 and np.linalg.norm(hit-p)>1e-6:
                # Reference is the clicked ray, so the first movement never jumps.
                so,sd=self.ray(*drag['start']);start=plane_hit(so,sd,p,a)
                if start is not None:start_vec=start-p
                current=hit-p
                angle=math.degrees(math.atan2(float(np.dot(a,np.cross(start_vec,current))),float(np.dot(start_vec,current))))
                prev=drag.get('last_angle',0.);angle=prev+((angle-prev+180)%360-180);drag['last_angle']=angle
            else:
                # Edge-on rings are nearly a line; use the tangent at the hit.
                angle=float(np.dot(motion,delta)/max(np.linalg.norm(delta),1))*1.2
            v=list(original.rotation);v[axis]+=angle;new=replace(original,rotation=tuple(v))
        else:
            param=axis_parameter(o,d,p,a)
            f=float(np.dot(motion,delta)/max(1,np.dot(delta,delta)))
            displacement=(param-drag['param']) if param is not None and drag['param'] is not None else f*drag['length']
            if mode=='move':new=replace(original,position=tuple(np.array(original.position)+np.linalg.solve(drag['basis'],a*displacement)))
            else:
                v=list(original.scale);v[axis]=max(.01,v[axis]*max(.01,1+displacement/drag['length']));new=replace(original,scale=tuple(v))
        if self.scene.transforms[e]!=new:
            if not drag['remembered']:self.remember();drag['remembered']=True
            self.scene.set_transform(e,new);self.dirty=True
    def visible_entities(self):
        # Luau and physics can mutate the scene after the frame's initial sync.
        self.sync(self.scene)
        return [e for e in self.ids if e in self.scene.names and self.search in self.scene.names[e].casefold()]
    def scroll(self,delta,x,y):
        if self.picker=='worldlibrary':
            self.world_offset=max(0,min(max(0,len(self.world_rows())-1),self.world_offset-int(delta*3)));self.dirty=True;return
        if self.picker=='marketplace' and self.market:
            self.market.offset=max(0,min(max(0,len(self.market.rows())-1),self.market.offset-int(delta*3)));self.dirty=True;return
        if self.picker=='marketmaterials':
            self.market_material_offset=max(0,self.market_material_offset-int(delta*3));self.dirty=True;return
        if self.picker=='assets':
            self.library_offset=max(0,min(max(0,len(list_assets(self.asset_search))-1),self.library_offset-int(delta*3)));self.dirty=True;return
        if self.picker:return
        if self.script_tab:
            self.code.scroll(delta,x); self.dirty=True; return
        l,t,w,h=self.rect
        if x<l: self.offset=max(0,min(max(0,len(self.visible_entities())-1),self.offset-int(delta*3)))
        elif y>=t+h: self.asset_offset=max(0,min(max(0,len(list(ROOT.glob('*.npz')))-1),self.asset_offset-int(delta)))
        elif l<=x<l+w and t<=y<t+h:
            if self.view_mode!='Perspective': self.ortho_size=max(2,min(1000,self.ortho_size*math.exp(-delta*.1)))
            else: self.camera.position+=self.camera.forward*float(delta)*3
        self.dirty=True
    camera=None
    rect=(0,0,1,1)
    def image(self,g,stats,w,h,camera,pixel_size=None):
        self.sync(self.scene)
        self.graphics=g; self.camera=camera; self.rect=self.viewport(w,h); l,t,vw,vh=self.rect; r=l+vw; b=t+vh
        im,d=canvas(w,h,pixel_size); self.buttons=[]; self.gizmo=[]; self.rings=[]
        bg=theme.BG; panel=theme.PANEL; border=theme.BORDER; accent=theme.ACCENT; fg=theme.TEXT; muted=theme.MUTED
        def text(x,y,s,fill=fg,font=None): d.text((x,y),str(s),fill=fill,font=font or self.font)
        def button(x,y,bw,label,fn,active=False):
            hover=x<=self.pointer[0]<x+bw and y<=self.pointer[1]<y+24
            color=('#a43f48' if label=='Stop' else theme.GREEN if label=='Play' else theme.SELECT) if active else theme.HOVER if hover else theme.SURFACE
            d.rounded_rectangle((x,y,x+bw,y+23),radius=5,fill=color,outline=theme.BORDER); text(x+7,y+4,label,font=self.small); self.buttons.append((x,y,x+bw,y+24,fn))
        d.rectangle((0,0,w,t),fill=bg); d.rectangle((0,t,l,b),fill=panel); d.rectangle((r,t,w,b),fill=panel); d.rectangle((0,b,w,h),fill=bg)
        d.rectangle((l,t,r-1,b-1),outline=border); im.alpha_composite(theme.emblem(round(38*d.scale)),d.point((9,3))); text(53,5,'Aftershock Studio',fg,self.large); text(54,26,self.scene.name+'  ·  '+stats,muted,self.small); text(w-265,12,'PLAYING' if self.playing else 'EDIT  /  '+config.VERSION,'#63df9d' if self.playing else muted,self.small)
        d.line((0,42,w,42),fill=border); d.line((0,74,w,74),fill=border)
        buttons=[('New',lambda:self.open_template('Baseplate')),('Open',lambda:self.choose('open')),('Open Template',self.open_template_picker),('Save',self.save),('Save as',lambda:self.choose('save')),('Undo',self.undo),('Redo',self.redo),('Stop' if self.playing else 'Play',self.play),('Assets',self.open_asset_library),('Output',self.show_output),('Check for Updates',self.update_menu),('Export Game',self.export_dialog)]
        if self.script_tab:
            buttons=[('Save all',self.save_scripts),('Stop' if self.playing else 'Play',self.play),('Output',self.show_output),('Check for Updates',self.update_menu)]
        native=bool(self.update_checker and self.update_checker.menu_installed)
        if native:buttons=[('Stop' if self.playing else 'Play',self.play),('Assets',self.open_asset_library),('Marketplace',self.open_marketplace),('World Library',self.open_world_library)]
        x=10
        for label,fn in buttons:
            bw={'Open Template':112,'Export Game':96,'Check for Updates':128,'Marketplace':98,'World Library':110}.get(label,60);button(x,47,bw,label,fn,label in ('Play','Stop')); x+=bw+5
        if not native and not self.script_tab and x+200<w:
            button(x,47,116,'Weather: '+self.scene.environment.weather,self.weather);x+=121
            button(x,47,76,'Audio: '+('On' if self.scene.environment.audio else 'Off'),lambda:self.set_environment(audio=not self.scene.environment.audio),self.scene.environment.audio)
        if self.picker=='worldlibrary':
            from . import world_assets,world_meshes
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg);text(24,90,'WORLD MATERIALS & MESHES',accent,self.large)
            text(24,116,'Original procedural PBR library | 1,024 materials | 128 textured props | generate only what you need',muted,self.small)
            button(w-106,90,82,'Done',self.dismiss_picker);button(24,144,112,'Materials',lambda:self.world_mode_set('materials'),self.world_mode=='materials');button(142,144,88,'Meshes',lambda:self.world_mode_set('meshes'),self.world_mode=='meshes')
            button(236,144,110,'Search…',lambda:self.command_prefix('worldfind '));button(352,144,92,'Clear',lambda:(setattr(self,'world_query',''),setattr(self,'world_offset',0)));button(450,144,120,'Import pack…',self.world_import_pack);button(576,144,140,'Project library',self.open_asset_library)
            if self.world_mode=='materials':button(722,144,145,'Maps: '+str(self.world_resolution)+' px',lambda:(setattr(self,'world_resolution',world_assets.RESOLUTIONS[(world_assets.RESOLUTIONS.index(self.world_resolution)+1)%3])))
            rows=self.world_rows();divider=max(400,int(w*.55));count=max(1,(h-280)//29);self.world_offset=min(self.world_offset,max(0,len(rows)-count));d.line((divider,184,divider,h-72),fill=border)
            text(24,181,f'{len(rows)} assets | '+(self.world_query or 'All')+' | scroll to browse',muted,self.small)
            for i,meta in enumerate(rows[self.world_offset:self.world_offset+count]):
                y=207+i*29;button(24,y,divider-47,meta['name'][:max(10,(divider-90)//7)],lambda v=meta['id']:self.world_select(v),self.world_selection==meta['id'])
            xx=divider+20;yy=184;selection=self.world_selection
            if selection:
                meta=(world_assets.catalog()[world_assets.index_of(selection)] if self.world_mode=='materials' else world_meshes.catalog()[world_meshes.index_of(selection)])
                text(xx,yy,meta['name'],fg,self.large);text(xx,yy+28,'CC0 | original procedural asset',muted,self.small);text(xx,yy+48,selection,muted,self.small)
                if self.world_mode=='materials':
                    folder=ROOT.parent.parent/'assets'/'world_materials'/f'{selection}-{self.world_resolution}';present=(folder/'material.json').is_file()
                    text(xx,yy+68,('Saved to project' if present else 'Generated on demand')+' | '+str(self.world_resolution)+' px',muted,self.small)
                    button(xx,yy+96,184,'Generate / Save maps',lambda:self.world_generate(False),True);button(xx,yy+127,184,'Apply to world slot…',lambda:self.world_generate(True))
                    text(xx,yy+160,'Colour, normal, roughness, height',muted,self.small);text(xx,yy+181,'Active world slots use 1K maps.',muted,self.small)
                    if present:
                        try:
                            preview=next(p for p in (folder/'albedo.png',folder/'albedo.jpg') if p.is_file())
                            with Image.open(preview) as thumb:
                                px=min(164,max(56,w-xx-26),max(56,h-(yy+232)-70));thumb=thumb.convert('RGBA').resize((round(px*d.scale),round(px*d.scale)),Image.Resampling.BILINEAR);im.alpha_composite(thumb,d.point((xx,yy+205)))
                        except (OSError,StopIteration):pass
                else:
                    text(xx,yy+68,'Textured GLB with PBR maps',muted,self.small);button(xx,yy+96,188,'Generate to project…',lambda:self.world_generate(False),True);text(xx,yy+130,'Then insert using Project Library.',muted,self.small)
            else:text(xx,yy,'Select an asset to inspect or generate.',muted,self.small)
            text(24,h-67,self.message[:max(10,(w-50)//7)],muted,self.small)
            d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border);text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small);self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
            self.dirty=False;return im
        if self.picker=='marketplace':
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg);m=self.market
            text(24,90,'ASSET MARKETPLACE',accent,self.large);text(24,116,'Powered by Poly Haven | verified CC0 | 1K PBR materials and glTF models',muted,self.small)
            button(w-106,90,82,'Done',self.dismiss_picker);button(24,143,110,'Search…',lambda:self.command_prefix('marketfind '));button(140,143,80,'Refresh',m.refresh)
            for i,k in enumerate(('All','Model','Material','Cart')):button(226+i*66,143,60,k,lambda k=k:(setattr(m,'kind',k),setattr(m,'offset',0)),m.kind==k)
            button(490,143,110,'Project library',self.open_asset_library);button(606,143,132,'Saved materials',self.open_market_materials)
            divider=int(w*.60);d.line((divider,180,divider,h-100),fill=border);rows=m.rows();max_rows=max(1,(h-305)//29);m.offset=min(m.offset,max(0,len(rows)-max_rows))
            text(24,179,f'{len(rows)} results | '+(m.query or 'All assets'),muted,self.small)
            for i,item in enumerate(rows[m.offset:m.offset+max_rows]):
                y=203+i*29;present=(m.project/'assets'/'marketplace'/item.slug).exists();label=('Saved' if present else 'Remove' if item.slug in m.cart else '+ Add')
                button(24,y,divider-121,(item.name+'  |  '+item.kind)[:max(12,(divider-130)//7)],lambda item=item:setattr(m,'selection',item),m.selection==item)
                button(divider-90,y,80,label,lambda item=item:m.toggle(item),item.slug in m.cart)
            xx=divider+12;text(xx,180,f'CART  ({len(m.cart)}/12)',accent,self.large);yy=209
            if m.selection:
                item=m.selection;text(xx,yy,item.name[:max(10,(w-xx-18)//8)],fg,self.small);text(xx,yy+20,'CC0 · '+item.author[:35],muted,self.small);button(xx,yy+42,110,'Source page',lambda item=item:self.browse_asset_site(item.source));yy+=76
            for item in list(m.cart.values())[:max(1,(h-yy-168)//27)]:
                button(xx,yy,w-xx-20,('− '+item.name)[:max(10,(w-xx-26)//7)],lambda item=item:m.toggle(item));yy+=27
            button(xx,h-145,155,'Download cart…',self.market_download,bool(m.cart));button(xx+160,h-145,92,'Clear cart',lambda:m.cart.clear() if not m.busy else None)
            if m.operation=='download':
                d.rounded_rectangle((24,h-95,w-24,h-86),4,fill=border);d.rectangle((24,h-95,24+(w-48)*m.fraction,h-86),fill=accent);button(xx,h-113,90,'Cancel',m.stop.set)
            elif m.result and any(row[2] for row in m.result) and not m.native:button(xx,h-113,155,'Restart Studio…',self.restart_after_assets)
            text(24,h-70,m.status[:max(10,(w-50)//7)],muted,self.small)
            d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border);text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small);self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
            self.dirty=False;return im
        if self.picker=='marketmaterials':
            from .marketplace import installed_materials
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg);text(24,90,'DOWNLOADED MATERIALS',accent,self.large);text(24,120,'Apply a saved material to a world material slot. The original maps stay in the library.',muted,self.small);button(w-106,90,82,'Done',self.dismiss_picker);button(24,144,126,'Marketplace',self.open_marketplace);button(160,144,138,'World Library',self.open_world_library)
            rows=installed_materials(ROOT.parent.parent);count=max(1,(h-240)//34);self.market_material_offset=min(self.market_material_offset,max(0,len(rows)-count))
            for i,(slug,meta) in enumerate(rows[self.market_material_offset:self.market_material_offset+count]):
                y=184+i*34;text(24,y+4,meta['name'][:75]+'  |  CC0',fg,self.small);button(w-186,y,160,'Apply to material…',lambda slug=slug:self.apply_market_material(slug))
            if not rows:text(24,184,'No marketplace materials downloaded yet.',muted,self.small)
            text(24,h-60,self.message[:max(10,(w-50)//7)],muted,self.small);self.dirty=False;return im
        if self.picker=='assets':
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg)
            text(24,90,'PROJECT ASSET LIBRARY',accent,self.large);text(24,116,'Import once, reuse in any project scene. Textures are cached locally.',muted,self.small)
            button(w-106,90,82,'Done',self.dismiss_picker)
            button(24,143,146,'Import models…',self.import_library_dialog);button(176,143,108,'Open folder',self.asset_folder)
            button(290,143,112,'Find assets…',lambda:self.command_prefix('assetfind '));button(408,143,92,'Clear search',lambda:(setattr(self,'asset_search',''),setattr(self,'library_offset',0)))
            button(506,143,150,'Import PBR maps…',self.import_pbr_dialog);button(662,143,110,'Marketplace',self.open_marketplace);button(778,143,132,'World Library',self.open_world_library)
            divider=max(420,int(w*.56));d.line((divider,184,divider,h-65),fill=border)
            rows=list_assets(self.asset_search);max_rows=max(1,(h-335)//34);self.library_offset=min(self.library_offset,max(0,len(rows)-max_rows))
            text(24,184,f'{len(rows)} asset(s) | '+(self.asset_search or 'All models'),muted,self.small)
            for i,(p,meta) in enumerate(rows[self.library_offset:self.library_offset+max_rows]):
                y=207+i*34;kind='asset:'+p.name;label=meta['name'][:max(12,(divider-155)//7)];button(24,y,divider-47,label,lambda k=kind:self.select_library_asset(k),self.library_selection==kind)
                text(divider-129,y+5,meta.get('format','Legacy')+' · '+str(meta.get('triangles','?'))+' tris',muted,self.small)
            if not rows:text(24,213,'No models yet. Download GLB/glTF/OBJ and import.',muted,self.small)
            xx=divider+20;yy=184
            if self.library_selection:
                p=asset_path(self.library_selection);meta=asset_metadata(p)
                if p.is_file():
                    text(xx,yy,meta['name'][:max(10,(w-xx-18)//9)],fg,self.large);text(xx,yy+28,f"{meta.get('triangles','?')} triangles · {meta.get('parts',0)} material groups",muted,self.small)
                    text(xx,yy+48,f"Size: {meta['size']:.2f} m | {p.stat().st_size/1048576:.2f} MB cached",muted,self.small)
                    text(xx,yy+68,'Licence: '+(meta.get('licence') or 'Not recorded')[:36],muted,self.small)
                    button(xx,yy+95,172,'Insert with mesh collider',lambda:self.insert_library_asset(collider='mesh'),True)
                    button(xx,yy+124,172,'Insert with fitted box',lambda:self.insert_library_asset(collider='box'))
                    button(xx,yy+153,172,'Insert without collision',lambda:self.insert_library_asset(collider='none'))
                    button(xx,yy+182,172,'Source / licence…',self.asset_source);yy+=224
                    if meta.get('alpha_blend_approximate'):text(xx,yy,'Transparent materials use cutouts.',muted,self.small);yy+=20
            else:text(xx,yy,'Select a model to place it.',muted,self.small);yy+=35
            text(24,h-128,'FREE ASSET SOURCES  /  opens in browser',accent,self.small)
            bw=min(116,(divider-52)//4-4)
            for i,(name,url,desc) in enumerate(SOURCES):
                button(24+i*(bw+5),h-105,bw,name,lambda u=url:self.browse_asset_site(u))
            text(24,h-65,self.message[:max(10,(w-50)//7)],muted,self.small)
            d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border);text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small);self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
            self.dirty=False;return im
        if self.picker=='human':
            from .human import profile
            p=profile(self.scene.player_appearance);self.buttons=[];d.rectangle((0,76,w,h),fill=bg)
            text(24,90,'Human Generator',accent,self.large);text(24,120,'Seeded adult player appearance. NPCs generate their own identities.',muted,self.small)
            button(w-108,90,84,'Done',self.dismiss_picker)
            text(24,164,f'Appearance seed: {p.seed}',font=self.large)
            for i,(label,value) in enumerate([('Height scale',f'{p.height:.2f}'),('Body build',f'{p.build:.2f}'),('Face shape',str(p.face+1)),('Hair style',str(p.hair_style+1))]):text(24,202+i*27,label+': '+value)
            for i,(label,color) in enumerate([('Skin',p.skin),('Hair',p.hair),('Eyes',p.iris),('Shirt',p.shirt),('Trousers',p.trousers)]):
                x=260+i*82;d.rounded_rectangle((x,205,x+58,252),radius=6,fill=tuple(int(255*v) for v in color));text(x,260,label,muted,self.small)
            button(24,335,175,'Randomise appearance',self.random_human_seed);button(212,335,145,'Set seed…',lambda:(self.dismiss_picker(),self.command_prefix('human ')));button(370,335,145,'Reset default',lambda:self.set_human_seed(0))
            text(24,382,'Save the scene, then Play in third person to preview your character.',muted,self.small)
            text(24,406,'Procedural anatomy; collisions and movement retain the existing capsule.',muted,self.small)
            self.dirty=False;return im
        if self.picker=='graphics':
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg)
            text(24,90,'Graphics settings',accent,self.large);text(24,120,'Fine-tune performance and visual quality for this session.',muted,self.small)
            button(w-108,90,84,'Done',self.dismiss_picker)
            items=[('Preset: '+g.quality.name,g.cycle),('Render scale: '+f'{g.scale:.0%}',g.cycle_scale),('Shadow cap: '+str(g.shadow_limit),g.cycle_shadows),('Light cap: '+str(g.light_limit),g.cycle_lights)]
            for attr,label in [('shadows','Shadows'),('bloom','Bloom'),('fxaa','Anti-aliasing'),('adaptive','Adaptive resolution'),('material_detail','Material microdetail'),('ambient_occlusion','Ambient occlusion'),('grass','Grass'),('terrain_shadows','Terrain shadows'),('weather_effects','Rain effects'),('water_detail','Water detail'),('hair_wind','Hair wind'),('cloud_detail','Cloud detail'),('skinning','Legacy skinning (detail off)'),('human_detail','Detailed humans')]:
                items.append((label+': '+('On' if getattr(g,attr) else 'Off'),lambda attr=attr:setattr(g,attr,not getattr(g,attr))))
            bw=(w-80)//3
            for i,(label,fn) in enumerate(items):button(24+(i%3)*(bw+16),160+(i//3)*36,bw,label,fn)
            button(24,395,200,'Import scanned PBR maps…',self.import_pbr_dialog);
            if hasattr(g,'preferences_path'):button(237,395,190,'Save graphics preferences',lambda:(g.save_preferences(g.preferences_path),self.log('Graphics preferences saved')))
            button(24,433,300,'Download Poly Haven CC0 material pack…',self.install_scanned_pack)
            text(24,470,'Quality presets control vegetation LOD. Imported textures load on restart.',muted,self.small)
            text(24,489,'Scanned materials supplied by Poly Haven (polyhaven.com).',muted,self.small)
            if self.message.startswith('Poly Haven') or self.message.startswith('Downloading Poly Haven'):text(24,513,self.message[:100],accent,self.small)
            self.dirty=False;return im
        if self.picker:
            from .templates import TEMPLATES
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg)
            if self.picker=='templates':
                entries=[(n,v[0],lambda n=n:self.open_template(n)) for n,v in TEMPLATES.items()]
                title='Open a world template';subtitle='Creates a new editable scene. Save your current work first; Undo restores the previous scene.'
            else:
                entries=[(n,desc,lambda n=n:self.add_object(n)) for n,desc in [('Cube','Solid building block'),('Ground','160 metre concrete baseplate'),('Dynamic Crate','Physical wooden crate'),('Player Spawn','Starting position for Play and exported games'),('Tree','Trunk and foliage'),('Empty','Non-rendered grouping object')]]
                title='Add object';subtitle='Choose an object to place in your scene.'
            text(24,91,title,accent,self.large);text(24,119,subtitle,muted,self.small);button(w-104,90,82,'Cancel',self.dismiss_picker)
            cw=(w-64)//2;ch=91
            for i,(label,desc,fn) in enumerate(entries):
                xx=24+(i%2)*(cw+16);yy=152+(i//2)*(ch+10)
                d.rounded_rectangle((xx,yy,xx+cw,yy+ch),8,fill=panel,outline=border)
                text(xx+12,yy+10,label,fg,self.large);text(xx+12,yy+34,desc,muted,self.small)
                button(xx+12,yy+60,102,'Open template' if self.picker=='templates' else 'Add object',fn,True)
            self.dirty=False;return im
        if self.script_tab:
            d.rectangle((0,76,w,h),fill=bg)
            button(10,78,96,'3D Scene',self.scene_tab); button(111,78,120,'Luau Scripts',self.script_editor,True); d.line((115,103,227,103),fill=accent,width=2)
            button(236,78,90,'Terrain',self.open_terrain); text(340,83,'Enter: accept  ·  Tab: indent  ·  Ctrl+Space: suggestions',muted,self.small)
            output_top=h-(176 if self.output_expanded else 82)
            self.code.draw(d,w,h,108,output_top,self.log)
            text(12,output_top+6,'OUTPUT  /  '+self.code.status,accent,self.small)
            for i,message in enumerate(self.output[-(9 if self.output_expanded else 3):]): text(12,output_top+25+i*16,message[:max(10,(w-20)//7)],muted,self.small)
            self.dirty=False;return im
        button(10,78,96,'3D Scene',self.scene_tab,not self.terrain_tab); button(111,78,120,'Luau Scripts',self.script_editor); button(236,78,90,'Terrain',self.open_terrain,self.terrain_tab)
        d.line((240,103,322,103) if self.terrain_tab else (14,103,102,103),fill=accent,width=2)
        x=340
        for mode in ('move','rotate','scale'):
            button(x,78,68,mode.title(),lambda m=mode:setattr(self,'mode',m),self.mode==mode); x+=73
        x+=12
        for mode in (() if native else ('Perspective','Top','Front','Side')):
            bw=90 if mode=='Perspective' else 54
            button(x,78,bw,mode,lambda m=mode:self.set_view(m),self.view_mode==mode); x+=bw+5
        if not native:button(w-103,8,94,'Graphics…',lambda:setattr(self,'picker','graphics'))
        if not native and x+92<w:button(x+5,78,86,'World tools',self.close_world_tools if self.world_tools else lambda:setattr(self,'world_tools',True),self.world_tools)
        if self.world_tools and not self.terrain_tab:
            # A compact floating palette leaves the editor viewport and hierarchy usable.
            px=l+10;py=t+36;pw=min(204,max(145,(vw-30)//2)); cols=2 if vw>=2*pw+30 else 1
            d.rounded_rectangle((px-3,py-3,px+cols*(pw+5)-2,py+22+((14+cols-1)//cols)*25+3),6,fill=panel,outline=accent)
            text(px+5,py+2,'WORLD / SIMULATION',accent,self.small)
            for idx,(label,fn) in enumerate([('Create living district',self.city_demo),('Finish road' if self.road_points is not None else 'Draw road (click points)',self.road_finish if self.road_points is not None else self.road_tool),('Traffic / pedestrians',lambda:self.command_prefix('population ')),('Vehicle preset',lambda:self.command_prefix('vehicle ')),('Animation preview',lambda:self.command_prefix('animation ')),('New animation clip',lambda:self.command_prefix('clip ')),('Edit animation key',lambda:self.command_prefix('key ')),('Adaptive resolution',lambda:setattr(g,'adaptive',not g.adaptive)),('Skinning: '+('On' if g.skinning else 'Off'),lambda:setattr(g,'skinning',not g.skinning)),('Make selected a door',lambda:self.command_prefix('door')),('Sound emitter',lambda:self.command_prefix('emitter horn ')),('Weather: '+self.scene.environment.weather,self.weather),('Audio: '+('On' if self.scene.environment.audio else 'Off'),lambda:self.set_environment(audio=not self.scene.environment.audio)),('Cancel road / close' if self.road_points is not None else 'Close tools',self.close_world_tools)]):
                button(px+(idx%cols)*(pw+5),py+22+(idx//cols)*25,pw,label,fn)
        if self.terrain_tab:
            if self.scene.terrain:self.terrain_decorations=self.scene.terrain.decorations
            text(10,t+8,'TERRAIN / WORLD',accent); y=t+32
            button(10,y,l-20,'Biome: '+self.terrain_preset+'  ▾',lambda:setattr(self,'terrain_dropdown',not self.terrain_dropdown)); dropdown_y=y+25;y+=30
            button(10,y,l-20,'Seed: '+str(self.terrain_seed),lambda:self.command_prefix('terrainseed '));y+=28
            sizes=(1024,2048,4096,8192,16384)
            button(10,y,l-20,f'World: {self.terrain_size/1000:g} km square',lambda:setattr(self,'terrain_size',sizes[(sizes.index(self.terrain_size)+1)%len(sizes)]));y+=28
            button(10,y,l-20,f'Water level: {self.terrain_water:g}m',lambda:self.command_prefix('terrainwater '));y+=31
            button(10,y,l-20,'Generate / replace terrain',self.generate_terrain,True);y+=31
            button(10,y,l-20,'Remove terrain',self.terrain_remove);y+=32
            text(10,y,'SCULPT / PAINT',accent);y+=20
            for i,mode in enumerate(('Raise','Lower','Smooth','Flatten','Paint','Erase')):
                bw=(l-25)//2;button(10+(i%2)*(bw+5),y+(i//2)*28,bw,mode,lambda m=mode:setattr(self,'brush_mode',m),self.brush_mode==mode)
            y+=90
            text(10,y,'Click terrain to apply brush',muted,self.small)
            if self.terrain_dropdown:
                # Draw menu last over the underlying controls; reversed hit testing prioritizes rows.
                d.rounded_rectangle((8,dropdown_y,l-8,dropdown_y+len(TERRAIN_PRESETS)*24+4),4,fill=bg,outline=accent)
                for i,preset in enumerate(TERRAIN_PRESETS):button(10,dropdown_y+2+i*24,l-20,preset,lambda p=preset:self.set_preset(p),preset==self.terrain_preset)
            ix=r+10; iw=w-ix-10;y=t+8;text(ix,y,'BRUSH SETTINGS',accent);y+=28
            radii=(16,32,48,64,96,128,192,256); strengths=(2,6,12,24,48,80); mats=tuple(m for m in MATERIALS if m!='Water')
            button(ix,y,iw,f'Radius: {self.brush_radius} m',lambda:setattr(self,'brush_radius',radii[(radii.index(self.brush_radius)+1)%len(radii)]));y+=29
            button(ix,y,iw,f'Strength: {self.brush_strength}',lambda:setattr(self,'brush_strength',strengths[(strengths.index(self.brush_strength)+1)%len(strengths)]));y+=29
            button(ix,y,iw,'Paint: '+self.brush_material,lambda:setattr(self,'brush_material',mats[(mats.index(self.brush_material)+1)%len(mats)]));y+=35
            text(ix,y,'DECORATIONS',accent);y+=21
            button(ix,y,iw,'Decorations: '+('On' if self.terrain_decorations else 'Off'),self.toggle_decorations,self.terrain_decorations);y+=29
            text(ix,y,'Wind-animated grass',muted,self.small);y+=25
            text(ix,y,'WORLD DATA',accent);y+=23
            tr=self.scene.terrain
            if tr:
                text(ix,y,f'{tr.preset} | {tr.size:,}m square',muted,self.small);y+=18;text(ix,y,f'{len(tr.edits):,} height edits / {len(tr.paint):,} painted',muted,self.small);y+=22
            else:text(ix,y,'No terrain. Choose a preset.',muted,self.small);y+=24
            button(ix,y,iw,'Import heightmap PNG...',lambda:self.command_prefix('heightimport '));y+=29
            button(ix,y,iw,'Export heightmap PNG...',lambda:self.command_prefix('heightexport '));y+=35
            if y+60<b:
                text(ix,y,'GRAPHICS',accent);y+=20;button(ix,y,iw,'Quality: '+g.quality.name,g.cycle);y+=28;button(ix,y,iw,f'Render scale: {g.scale:.0%}',g.cycle_scale)
            d.rounded_rectangle((l+7,t+7,l+265,t+30),5,fill=(20,29,40,225));text(l+15,t+10,'Terrain  ·  '+self.brush_mode+'  ·  Tab: fly',fg,self.small)
            text(10,b+8,'TERRAIN OUTPUT',accent,self.small)
            for row,message in enumerate(self.output[-2:] or ['Generate terrain or open a saved terrain scene.']):text(10,b+30+row*16,message[:max(10,(w-20)//7)],muted,self.small)
            d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border);text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small);self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
            self.dirty=False;return im
        text(8,t+7,'Explorer',accent); text(8,t+26,f'{len(self.ids):,} entities',muted,self.small)
        button(8,t+45, min(l-16,105),'+ Add Object',self.add_menu)
        button(8,t+74,l-50,('Filter: '+self.search)[:23] if self.search else 'Find entity...',lambda:self.command_prefix('find ')); button(l-36,t+74,28,'X',self.clear_search)
        row_index={e:i for i,e in enumerate(self.ids)};display=self.visible_entities(); self.offset=min(self.offset,max(0,len(display)-1))
        rows=max(0,(vh-130)//19)
        for row,e in enumerate(display[self.offset:self.offset+rows]):
            i=row_index[e]; y=t+104+row*19
            if e==self.selected: d.rounded_rectangle((4,y,l-4,y+18),3,fill=theme.SELECT); d.rectangle((4,y+2,6,y+16),fill=accent)
            elif 0<=self.pointer[0]<l and y<=self.pointer[1]<y+19: d.rounded_rectangle((4,y,l-4,y+18),3,fill=theme.HOVER)
            text(7,y+2,str(i+1),muted,self.small)
            indent=34+min(5,self.depth[e])*11
            if e in self.scene.meshes:
                d.rounded_rectangle((indent,y+5,indent+9,y+14),2,outline='#8299b1',width=1)
            else:
                d.rounded_rectangle((indent,y+6,indent+11,y+14),2,fill='#c5a46b')
            text(indent+16,y+2,self.scene.names[e][:max(1,(l-indent-20)//7)],font=self.small)
            self.buttons.append((0,y,l,y+19,lambda e=e:self.select(e)))
        text(8,b-22,'Scroll to browse',muted,self.small); d.line((l-1,t,l-1,b),fill=border); d.line((r,t,r,b),fill=border)
        ix=r+9; iw=max(40,w-ix-9); y=t+8; text(ix,y,'Properties',accent); y+=24
        if self.selected in self.scene.names:
            e=self.selected; tr=self.scene.transforms[e]; m=self.scene.meshes.get(e); text(ix,y,self.scene.names[e][:30]); y+=22
            button(ix,y,72,'Rename',lambda:self.command_prefix('rename ')); button(ix+76,y,72,'Duplicate',self.duplicate); y+=28
            button(ix,y,72,'Delete',self.delete); button(ix+76,y,72,'Parent',lambda:self.command_prefix('parent ')); y+=30
            for field,cmd in [('position','pos'),('rotation','rot'),('scale','scale')]:
                text(ix,y,field.title(),muted,self.small); y+=15
                vals=' '.join(f'{v:.3g}' for v in getattr(tr,field)); button(ix,y,iw,vals,lambda cmd=cmd:self.command_prefix(cmd+' ')); y+=30
            if m:
                text(ix,y,'Material / RGB',accent,self.small); y+=17
                vals=' '.join(f'{v:.3g}' for v in m.color); button(ix,y,iw,vals,lambda:self.command_prefix('color ')); y+=30
                text(ix,y,'Roughness / Metal / Emission / Pattern',muted,self.small); y+=16
                vals=' '.join(f'{v:.3g}' for v in m.material); button(ix,y,iw,vals,lambda:self.command_prefix('mat ')); y+=31
                if y+25<b:
                    button(ix,y,iw,'Surface: '+PATTERNS[int(m.material[3])]+'  ▾',lambda:setattr(self,'surface_dropdown',not self.surface_dropdown));y+=28
            if not self.playing:
                mats=world_matrices(self.scene);p=mats[e][:3,3];center=self.project(p)
                depth=float(np.dot(p-camera.position,camera.forward));self.gizmo_length=max(.05,min(500.,(self.ortho_size*2 if self.view_mode!='Perspective' else depth*2*math.tan(math.radians(config.FOV)/2))*75/max(vh,1)))
                parent=self.scene.parents[e];basis=mats[parent][:3,:3] if parent is not None else np.eye(3)
                self.gizmo_axes=axes_for(tr,basis,self.mode)
                def inside(pt):return pt is not None and l<=pt[0]<r and t<=pt[1]<b
                if inside(center):
                    for axis,col in enumerate(('#fa6868','#65e48a','#70aaff')):
                        color='#ffffff' if self.drag and self.drag['axis']==axis else col
                        if self.mode=='rotate':
                            pts=circle_points(p,self.gizmo_axes[axis],self.gizmo_length);screen=[self.project(pt) for pt in pts];segments=[]
                            for i,(a,b2) in enumerate(zip(screen,screen[1:])):
                                if inside(a) and inside(b2):d.line((*a,*b2),fill=color,width=3);segments.append((a,b2,pts[i],pts[i+1]))
                            if segments:
                                self.rings.append((axis,segments));label=max((seg[0] for seg in segments),key=lambda q:q[1] if axis==0 else q[0] if axis==1 else -q[0]);text(label[0]+4,label[1]-8,'XYZ'[axis],color,self.small)
                        else:
                            end=self.project(p+self.gizmo_axes[axis]*self.gizmo_length)
                            if inside(end) and np.linalg.norm(end-center)>6:
                                d.line((*center,*end),fill=color,width=3);v=(end-center)/np.linalg.norm(end-center);n=np.array([-v[1],v[0]])
                                if self.mode=='scale':d.rectangle((end[0]-5,end[1]-5,end[0]+5,end[1]+5),fill=color)
                                else:
                                    for sign in (-1,1):d.line((*end,*(end-v*11+n*5*sign)),fill=color,width=3)
                                text(end[0]+6,end[1]-7,'XYZ'[axis],color,self.small);self.gizmo.append((axis,center,end))
                    d.ellipse((center[0]-3,center[1]-3,center[0]+3,center[1]+3),fill='white')
        else: text(ix,y,'Select an entity',muted); y+=27
        if self.selected in self.scene.names and y+42<b:
            body=self.scene.bodies.get(self.selected)
            text(ix,y,'PHYSICS',accent,self.small); y+=15
            button(ix,y,iw,'Body: '+(body.kind+' / '+body.shape if body else 'None'),lambda:self.command_prefix('body ')); y+=28
        if y+105<b:
            text(ix,y,'GRAPHICS',accent); y+=19; button(ix,y,iw,'Quality: '+g.quality.name,g.cycle); y+=27
            button(ix,y,iw,f'Render scale: {g.scale:.0%}',g.cycle_scale); y+=27
            button(ix,y,iw,f'Time {g.hour:.1f} | +1 hour',lambda:g.adjust(1)); y+=27
            if y+17<b and hasattr(g,'render_size'): text(ix,y,f'Viewport: {g.render_size[0]} × {g.render_size[1]} px',muted,self.small)
        if self.surface_dropdown and self.selected in self.scene.meshes:
            current=int(self.scene.meshes[self.selected].material[3]); top=max(t+25,b-8*26-10);bw=(iw-5)//2
            d.rounded_rectangle((ix-3,top-5,ix+iw+3,top+8*26+4),4,fill=bg,outline=accent)
            for i,name in enumerate(PATTERNS):
                button(ix+(i%2)*(bw+5),top+(i//2)*26,bw,name,lambda n=name:self.surface_material(n),i==current)
        if self.debug_colliders:
            # Project unit box outlines as a coarse bounds preview, not exact shape wireframes.
            mats=world_matrices(self.scene)
            corners=np.array([(x,y,z,1) for x in (-.5,.5) for y in (-.5,.5) for z in (-.5,.5)])
            edges=[(a,b) for a in range(8) for b in range(a+1,8) if (a^b) in (1,2,4)]
            ids=list(self.scene.bodies)
            if self.selected in self.scene.bodies: ids.remove(self.selected); ids.insert(0,self.selected)
            for e in ids[:150]:
                pts=[self.project(p[:3]) for p in (mats[e]@corners.T).T]
                col='#f6c65c' if self.scene.bodies[e].kind=='dynamic' else '#65e48a'
                for a,j in edges:
                    if pts[a] is not None and pts[j] is not None and all(l<=p[0]<r and t<=p[1]<b for p in (pts[a],pts[j])):
                        d.line((*pts[a],*pts[j]),fill=col,width=1)
        if self.road_points:
            from .city import height
            pts=[self.project((x,height(self.scene,x,z)+.2,z)) for x,z in self.road_points]
            for a,bp in zip(pts,pts[1:]):
                if a is not None and bp is not None and all(l<=p[0]<r and t<=p[1]<b for p in (a,bp)):d.line((*a,*bp),fill=accent,width=3)
            for p in pts:
                if p is not None and l<=p[0]<r and t<=p[1]<b:d.ellipse((p[0]-4,p[1]-4,p[0]+4,p[1]+4),fill=accent)
        d.rounded_rectangle((l+7,t+7,min(r-6,l+490),t+30),5,fill=(20,29,40,225)); text(l+15,t+10,('G: character · B: view · '+self.character_status) if self.playing else self.view_mode+'  ·  Tab: fly camera',fg,self.small)
        text(10,b+5,'Asset browser',accent); button(10,b+24,72,'Library…',self.open_asset_library)
        models=[p for p in sorted(ROOT.glob('*.npz')) if self.asset_search in asset_info(p)[0].casefold()]; x=190
        button(88,b+24,96,('Find: '+self.asset_search)[:13] if self.asset_search else 'Find asset...',lambda:self.command_prefix('assetfind '))
        for p in models[self.asset_offset:]:
            if x+105>=w: break
            name,size=asset_info(p); button(x,b+24,102,name[:14],lambda p=p:self.insert_library_asset('asset:'+p.name,collider='mesh')); x+=108
        text(10,b+52,'OUTPUT  /  '+('Play session' if self.playing else 'Editor'),accent,self.small)
        for row,message in enumerate(self.output[-(8 if self.output_expanded else 2):] or [self.message]): text(10,b+69+row*15,message[:max(10,(w-20)//7)],muted,self.small)
        d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border); text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small); self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
        self.dirty=False; return im
