"""Reusable dimensioned world props with authored UVs and generated PBR textures."""
from pathlib import Path
import tempfile
import numpy as np
from PIL import Image
from . import world_assets as materials

# name, material family index, geometry class, nominal dimensions (metres)
PROPS=(('Granite Boulder',12,'rock',(1.6,1.0,1.3)),('Basalt Rock',14,'rock',(.8,.55,.7)),('Sandstone Boulder',15,'rock',(2.0,1.1,1.7)),('River Stone',19,'rock',(.5,.25,.4)),('Concrete Bollard',4,'bollard',(.25,1.0,.25)),('Steel Bollard',40,'bollard',(.18,.95,.18)),('Kerb Stone',6,'kerb',(1,.23,.28)),('Concrete Barrier',4,'barrier',(2.2,.8,.65)),('Square Planter',4,'planter',(.9,.6,.9)),('Terracotta Pot',49,'pot',(.55,.6,.55)),('Fallen Log',36,'log',(2.4,.4,.4)),('Tree Stump',36,'stump',(.55,.48,.55)),('Timber Beam',32,'beam',(2.0,.18,.18)),('Paving Slab',11,'slab',(.75,.08,.75)),('Brick Stack',8,'bricks',(.6,.4,.45)),('Drain Cover',47,'drain',(.8,.06,.6)))
VARIANTS=8
COUNT=len(PROPS)*VARIANTS

def catalog():
    return tuple(dict(id=f'prop-{i:03d}',name=f'{p[0]} {j+1:02d}',family=p[0],index=i,license='CC0-1.0') for k,p in enumerate(PROPS) for j in range(VARIANTS) for i in (k*VARIANTS+j,))

def index_of(identifier):
    if not isinstance(identifier,str) or not identifier.startswith('prop-') or len(identifier)!=8 or not identifier[5:].isdigit():raise ValueError('Invalid prop ID')
    i=int(identifier[5:]);
    if i>=COUNT:raise ValueError('Unknown prop')
    return i

def geometry(index):
    import trimesh
    if type(index) is not int or not 0<=index<COUNT:raise ValueError('Invalid mesh index')
    name,family,style,dims=PROPS[index//VARIANTS];v=index%VARIANTS;rng=np.random.default_rng(8111+index*199)
    dims=np.asarray(dims,dtype=float)*rng.uniform(.86,1.16,3)
    parts=[]
    def box(size,pos=(0,0,0)):
        m=trimesh.creation.box(extents=size);m.apply_translation(pos);parts.append(m)
    def cyl(radius,height,pos=(0,0,0),axis='y',sections=32):
        m=trimesh.creation.cylinder(radius=radius,height=height,sections=sections)
        if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[1,0,0]))
        elif axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[0,1,0]))
        m.apply_translation(pos);parts.append(m)
    def profile(points):
        m=trimesh.creation.revolve(np.asarray(points),sections=48);m.apply_transform(trimesh.transformations.rotation_matrix(-np.pi/2,[1,0,0]));parts.append(m)
    w,h,d=dims
    if style=='rock':
        m=trimesh.creation.icosphere(subdivisions=4);p=m.vertices.copy();phase=rng.uniform(0,2*np.pi,3);factor=1+.12*np.sin(p[:,0]*5+phase[0])*np.cos(p[:,2]*6+phase[1])+.045*np.sin(p[:,1]*19+phase[2]);p*=factor[:,None];p[:,1]=np.maximum(p[:,1],-.73);m.vertices=p;parts.append(m)
    elif style=='bollard':profile([(0,-h/2),(w*.43,-h/2),(w*.5,-h*.43),(w*.5,h*.38),(w*.44,h*.46),(w*.28,h*.5),(0,h*.5)])
    elif style=='pot':profile([(0,-h*.5),(w*.29,-h*.5),(w*.32,-h*.43),(w*.49,h*.42),(w*.5,h*.5),(w*.42,h*.5),(w*.38,h*.40),(w*.23,-h*.36),(0,-h*.36)])
    elif style=='planter':
        t=.10*w;box((w,t,d),(0,-h/2+t/2,0));box((t,h,d),(-w/2+t/2,0,0));box((t,h,d),(w/2-t/2,0,0));box((w-2*t,h,t),(0,0,-d/2+t/2));box((w-2*t,h,t),(0,0,d/2-t/2))
    elif style=='barrier':
        # Joined tapered cross-section, built as closed triangular extrusion.
        yz=np.array([[-h/2,-d/2],[-h/2,d/2],[-h*.25,d/2],[h*.5,d*.17],[h*.5,-d*.17],[-h*.25,-d/2]])
        vertices=np.array([[x,y,z] for x in (-w/2,w/2) for y,z in yz]);faces=[];n=len(yz)
        for i in range(1,n-1):faces.extend([(0,i+1,i),(n,n+i,n+i+1)])
        for i in range(n):j=(i+1)%n;faces.extend([(i,j,n+j),(i,n+j,n+i)])
        m=trimesh.Trimesh(vertices=vertices,faces=faces,process=True);m.fix_normals();parts.append(m)
    elif style in ('log','stump'):
        axis='x' if style=='log' else 'y';length=w if style=='log' else h;rad=min(h,d)/2 if style=='log' else min(w,d)/2
        cyl(rad,length,axis=axis,sections=48)
        m=parts[-1];p=m.vertices.copy();k=0 if axis=='x' else 1;other=[i for i in range(3) if i!=k];ang=np.arctan2(p[:,other[0]],p[:,other[1]]);wave=1+.055*np.sin(7*ang+v)+.035*np.sin(13*ang+v);p[:,other]*=wave[:,None];m.vertices=p
    elif style=='bricks':
        for j in range(3):
            for k in range(3):box((w*.31,h*.30,d*.92),((k-1)*w*.33+(j%2)*w*.025,(j-1)*h*.33,0))
    elif style=='drain':
        box((w,h*.5,d*.10),(0,-h*.2,-d*.45));box((w,h*.5,d*.10),(0,-h*.2,d*.45));box((w*.07,h,d),(-w*.465,0,0));box((w*.07,h,d),(w*.465,0,0))
        for j in range(12):box((w*.035,h*.75,d*.82),((j-5.5)*w*.075,0,0))
    else:box(dims)
    m=trimesh.util.concatenate(parts);ext=np.maximum(m.extents,1e-9);m.vertices=(m.vertices-m.bounds.mean(axis=0))*dims/ext;m.fix_normals()
    return m,family*materials.VARIANTS+v

def export_prop(index,path,resolution=512):
    """GLB with PBR maps. Split face vertices at UV seams; metres, Y up."""
    import trimesh
    from trimesh.visual.material import PBRMaterial
    m,mat=geometry(index);faces=m.faces;verts=m.vertices[faces];n=m.vertex_normals[faces];dominant=np.abs(m.face_normals).argmax(axis=1);uv=np.empty((len(faces),3,2),dtype=np.float32)
    # dominant-plane atlas, world-space texture scale. No tiny degenerate UVs.
    extent=max(m.extents);scale=1/max(extent,.25)
    for axis in range(3):
        mask=dominant==axis;other=[i for i in range(3) if i!=axis];uv[mask]=verts[mask][:,:,other]*scale+.5
    tex=materials.maps(mat,resolution);rough=tex['roughness'];metal=np.full_like(rough,round(materials.FAMILIES[mat//materials.VARIANTS][4]*255));mr=np.stack((np.full_like(rough,255),rough,metal),axis=-1)
    material=PBRMaterial(name=materials.catalog()[mat]['name'],baseColorFactor=[255,255,255,255],baseColorTexture=Image.fromarray(tex['albedo']),normalTexture=Image.fromarray(tex['normal_gl']),metallicRoughnessTexture=Image.fromarray(mr),metallicFactor=1.,roughnessFactor=1.)
    visual=trimesh.visual.TextureVisuals(uv=uv.reshape(-1,2),material=material)
    model=trimesh.Trimesh(vertices=verts.reshape(-1,3),faces=np.arange(len(faces)*3).reshape(-1,3),vertex_normals=n.reshape(-1,3),visual=visual,process=False)
    path=Path(path);path.write_bytes(trimesh.exchange.gltf.export_glb(trimesh.Scene(model)));return path

def import_prop(identifier):
    from .assets import import_model
    index=index_of(identifier);name=catalog()[index]['name']
    with tempfile.TemporaryDirectory(prefix='aftershock-prop-') as folder:
        path=export_prop(index,Path(folder)/(name+'.glb'))
        return import_model(path,source='Aftershock original procedural generation',licence='CC0-1.0',author='Aftershock Studios')
