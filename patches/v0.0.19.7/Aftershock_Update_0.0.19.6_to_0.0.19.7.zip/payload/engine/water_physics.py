"""Analytic water surface and bounded buoyancy helpers, metres and seconds."""
import math

def water_surface(terrain,x,z,t):
    if terrain is None or abs(x)>terrain.size/2 or abs(z)>terrain.size/2:return None
    ground=float(terrain.height(x,z));depth=terrain.water-ground
    if depth<=0:return None
    # Same displacement bands as the terrain water vertex shader.
    f=max(0.,min(1.,depth/6.));f=f*f*(3-2*f)
    return terrain.water+f*(.10*math.sin(x*.18+z*.11-t*.7)+.065*math.sin(z*.25-x*.09+t*.9))

def immersion(surface,y,height):
    return 0. if surface is None else max(0.,min(1.,(surface-y+height/2)/max(.01,height)))

def collider_volume(scale,shape):
    x,y,z=map(abs,scale);r=max(x,z)*.5
    if shape=='sphere':return 4*math.pi*(max(x,y,z)/2)**3/3
    if shape=='capsule':return math.pi*r*r*max(.001,y-2*r)+4*math.pi*r**3/3
    if shape=='cylinder':return math.pi*r*r*y
    return x*y*z  # bounding volume for convex meshes

def buoyancy(mass,velocity,fraction,volume=None):
    volume=mass/570. if volume is None else volume
    # Archimedes force from an approximate submerged collider volume, with a solver stability cap.
    lift=min(mass*9.81*3.,1000.*volume*9.81*fraction)
    return (-mass*velocity[0]*1.8*fraction,lift-mass*3.2*velocity[1]*fraction,-mass*velocity[2]*1.8*fraction)

def swim_velocity(direction,vy,y,surface,ascend,dive):
    target=2.0 if ascend else -1.6 if dive else max(-1.5,min(1.5,(surface-y-.30)*3.))
    return (float(direction[0])*.55,vy+(target-vy)*.18,float(direction[2])*.55)
