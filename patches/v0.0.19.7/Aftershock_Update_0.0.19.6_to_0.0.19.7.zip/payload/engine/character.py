"""Procedural articulated prototype, independent of the collision capsule."""
import math
import numpy as np
from .visibility import pack
from .camera import unit

class Character:
    def __init__(self,appearance=None):
        self.velocity=np.zeros(3); self.heading=0.; self.phase=0.; self.blend=0.; self.crouch=0.; self.state='Idle'; self.position=np.zeros(3); self.grounded=False; self.footstep=False; self.third=True; self.distance=4.5; self.breath=0.
        from .animation import Animator
        self.animator=Animator();self.preview=None;self.appearance=appearance;self.wind=0.;self.wind_time=0.
    def movement(self,direction,sprint,crouch,dt):
        d=np.asarray(direction,dtype=float);d[1]=0.; d=d/max(1.,np.linalg.norm(d));target=d*(2.0 if crouch else 7.5 if sprint else 4.0)
        delta=target-self.velocity;limit=(20 if np.linalg.norm(target)>.01 else 26)*dt
        self.velocity+=delta*min(1.,limit/max(np.linalg.norm(delta),1e-8));self.crouch+=(float(crouch)-self.crouch)*min(1.,dt*12)
        return self.velocity.copy()
    def animate(self,position,velocity,grounded,dt):
        self.breath+=dt*2.2; self.position=np.asarray(position,dtype=float);speed=float(np.linalg.norm(np.asarray(velocity)[[0,2]]));self.grounded=grounded
        if speed>.12:
            goal=math.atan2(velocity[0],velocity[2]);diff=(goal-self.heading+math.pi)%math.tau-math.pi;self.heading+=diff*min(1.,dt*14)
        self.state=('Jump' if velocity[1]>.15 else 'Fall') if not grounded else ('Crouch' if self.crouch>.5 else 'Sprint' if speed>5.3 else 'Walk' if speed>.18 else 'Idle')
        self.blend+=(min(speed/3.,1.)-self.blend)*min(1.,dt*10)
        self.animator.step(self.preview or self.state,dt)
        old=int(self.phase/math.pi);self.phase+=dt*speed*1.8;self.footstep=grounded and speed>.4 and int(self.phase/math.pi)!=old
    def camera_position(self,eye,forward,raycast,player=None):
        eye=np.asarray(eye,dtype=float)
        if not self.third:return eye
        f=unit(np.asarray(forward,dtype=float)); right=unit(np.cross(f,[0,1,0]));anchor=eye+np.array([0,.38,0]); offset=-f*self.distance+right*.55
        # Cast from above the capsule; shorten the boom against scenery.
        hit=raycast(anchor,anchor+offset)
        if hit and (player is None or hit.get('entity')!=player):offset*=max(.04,float(hit['fraction'])-.10)
        return anchor+offset
    def batches(self):
        """Joint-driven, tailored low-poly human. +Z is the front of the body."""
        a,b,c=self.phase,self.blend,self.crouch
        if self.preview:
            b,c,_=self.animator.pose
            a=self.animator.time*math.tau*1.5
        swimming=self.state=='Swimming' and not self.preview
        if swimming:a=self.breath*2.4;b=.85;c=0.
        air=self.animator.pose[2] if self.preview else (0. if self.grounded else 1.)
        stride=min(1.,float(np.linalg.norm(self.velocity[[0,2]]))/7.5)
        if swimming:air=0.;stride=.6
        bob=(.018*math.cos(2*a)*b+.005*math.sin(self.breath)*(1-b))*(1-air)
        hip=np.array([0.,.91-.25*c+bob,0.]); waist=hip+[0,.15,.03*c]; shoulder=waist+[0,.35,.14*c+.07*stride]; neck=shoulder+[0,.045,.012]; head=neck+[0,.155,.008]
        root=self.position-np.array([0,.9,0]); sn,cs=math.sin(self.heading),math.cos(self.heading); rot=np.array([[cs,0,sn],[0,1,0],[-sn,0,cs]])
        groups={}
        def add(kind,p,q,width,depth,color,extra=0.):
            p,q=np.asarray(p,dtype=float),np.asarray(q,dtype=float); delta=q-p; y=unit(delta)
            # Keep the front of each segment facing anatomical +Z, even when pitched.
            ref=np.array([0.,0.,1.]) if abs(y[2])<.97 else np.array([0.,1.,0.]); x=unit(np.cross(y,ref)); z=np.cross(x,y)
            m=np.eye(4);m[:3,:3]=rot@np.column_stack((x*width,y*(np.linalg.norm(delta)+extra),z*depth));m[:3,3]=root+rot@((p+q)*.5)
            rows,colors=groups.setdefault(kind,([],[]));rows.append(m);colors.append(color)
        def upright(kind,center,w,h,d,color):
            center=np.asarray(center);add(kind,center-[0,h/2,0],center+[0,h/2,0],w,d,color)
        skin=(.72,.53,.40); shirt=(.23,.36,.45); trim=(.15,.24,.31); pants=(.22,.27,.32); shoe=(.13,.15,.18); hair=(.16,.105,.075)
        if self.appearance is not None:
            import random
            rng=random.Random(self.appearance)
            skin=rng.choice([(.82,.64,.50),(.72,.53,.40),(.57,.37,.26),(.38,.24,.16),(.89,.72,.61)])
            shirt=rng.choice([(.23,.36,.45),(.36,.18,.15),(.52,.49,.40),(.19,.22,.24),(.26,.41,.25),(.68,.65,.60)])
            pants=rng.choice([(.19,.24,.32),(.29,.27,.23),(.18,.19,.21)]);hair=rng.choice([(.16,.105,.075),(.09,.065,.05),(.46,.30,.17),(.28,.27,.25)]);trim=tuple(v*.67 for v in shirt)
        # Tapered hips, fitted shirt, collar and continuous neck.
        add('pelvis',hip-[0,.105,0],waist,.34,.24,pants,.04)
        add('torso',waist-[0,.025,0],shoulder,.43,.255,shirt,.055)
        upright('collar',neck-[0,.035,0],.17,.055,.16,trim)
        upright('limb',neck+[0,.035,0],.105,.12,.105,skin)
        upright('head',head,.158,.235,.19,skin)
        upright('hair',head+[0,.069,-.012],.169,.13,.198,hair)
        # Layered scalp tufts retain the same rig topology for CPU skinning.
        for i in range(3):
            x=(i-1)*.043;root_hair=head+[x,.0725,-.009]
            gust=self.wind*(.72*math.sin(self.wind_time*3.7+i*.8+self.position[0]*.19)+.28*math.sin(self.wind_time*7.2+i))
            # Wind bends the free ends in world space while roots stay anchored.
            offset=rot.T@np.array([.020*gust,0.,.014*self.wind])
            add('hair',root_hair,root_hair+[0,.065,0]+offset,.054,.136,tuple(v*(1.04+.05*i) for v in hair))
        for side in (-1,1):
            upright('detail',head+[side*.078,-.012,.002],.035,.058,.045,skin)
            upright('detail',head+[side*.036,.015,.089],.029,.013,.012,(.87,.83,.76))
            upright('detail',head+[side*.035,.015,.095],.011,.011,.008,(.16,.20,.21))
            upright('detail',head+[side*.035,.015,.099],.0048,.005,.003,(.025,.025,.025))
            upright('detail',head+[side*.035-.002,.018,.101],.0025,.0025,.0015,(.92,.94,.96))
            upright('detail',head+[side*.036,.035,.087],.034,.009,.009,hair)
        upright('nose',head+[0,-.01,.092],.032,.055,.041,skin)
        upright('detail',head+[0,-.052,.088],.052,.009,.008,tuple(v*.63 for v in skin))
        upright('detail',head+[0,-.058,.089],.041,.007,.006,tuple(v*.80 for v in skin))
        for side in (-1,1):
            phase=a+(0 if side==1 else math.pi); swing=math.sin(phase)*b*(1-air); lift=max(0.,math.cos(phase))*b*(1-air)
            h=hip+[side*.105,-.035,0.]
            # Alternating foot plant/lift, knees flex forward and avoid backwards bending.
            ankle=np.array([side*.115,.105+.13*lift+.20*air+.015*c,.26*swing-.14*c+.08*air]); k=(h+ankle)*.5+np.array([0.,.012,.09+.15*c+.13*lift+.07*air])
            add('thigh',k,h,.205,.205,pants,.075);add('calf',ankle,k,.155,.17,pants,.065)
            upright('shoe',ankle+[0,-.052,.064],.153,.105,.28,shoe)
            upright('sole',ankle+[0,-.088,.065],.158,.038,.285,(.42,.43,.43))
            sh=shoulder+[side*.195,-.055,0.];el=sh+[side*.035,-.26,-.19*swing+.12*air];hand=el+[side*.005,-.225,.075+.18*stride+.12*c+.12*air-.12*swing]
            if swimming:
                el=sh+[side*.15,-.06+.10*math.cos(phase),.18+.12*math.sin(phase)]
                hand=el+[side*.055,.06*math.cos(phase),.19]
            if self.preview=='Wave' and side==1:
                t=min(1.2,self.animator.time);weight=min(1.,t/.2,(1.2-t)/.2)*self.animator.fade
                target=sh+[.22,.13,0.];el=el*(1-weight)+target*weight;hand=hand*(1-weight)+(target+[.06*math.sin(t*18),.25,.025])*weight
            add('sleeve',el,sh,.15,.155,shirt,.065)
            add('forearm',hand,el,.103,.115,skin,.045)
            add('hand',hand+[0,-.086,.018],hand,.092,.065,skin,.022)
        cloth={'torso','pelvis','collar','thigh','calf','sleeve'};skin_parts={'head','limb','forearm','hand','nose'}
        return {kind:pack(rows,colors,[(.88,0,0,15) if kind in cloth else (.53,0,0,16) if kind in skin_parts else (.65,0,0,19) if kind=='hair' else (.78,0,0,0)]*len(rows))[0] for kind,(rows,colors) in groups.items()}
    def instances(self):
        return np.concatenate(list(self.batches().values()))

# Each ring is (normalized height, width factor, depth factor, front/back offset).
# Longitudinal profiles form human anatomy instead of scaling spheres.
PROFILES={
 'torso':([(-.5,.72,.83,0),(-.38,.77,.89,0),(-.10,.86,.93,0),(.18,1.,1.,0),(.36,1.,.94,0),(.49,.61,.70,0)],2.5),
 'pelvis':([(-.5,.66,.75,0),(-.38,.94,.94,0),(-.10,1,1,-.025),(.30,.90,.92,0),(.5,.78,.82,0)],2.5),
 'head':([(-.5,.34,.50,-.04),(-.42,.68,.76,.03),(-.24,.84,.93,.035),(-.04,.97,1,0),(.20,1.,.97,-.025),(.37,.83,.84,-.045),(.5,.40,.46,-.05)],2.0),
 'hair':([(-.5,.91,.83,-.035),(-.32,1.,1.,-.02),(.09,1.,1.,0),(.36,.84,.90,-.01),(.5,.47,.52,-.02)],2.3),
 'collar':([(-.5,1,1,0),(.5,.95,.95,0)],2.3),
 'limb':([(-.5,.87,.89,0),(-.30,1,1,0),(.5,.89,.89,0)],2.),
 'thigh':([(-.5,.68,.77,0),(-.26,.77,.86,0),(.08,.92,.98,0),(.34,1.,1.,0),(.5,.92,.88,0)],2.4),
 'calf':([(-.5,.65,.72,0),(-.29,.72,.76,0),(.04,.91,.93,-.04),(.28,1.,1.,-.025),(.5,.87,.88,0)],2.4),
 'sleeve':([(-.5,.72,.73,0),(-.22,.79,.83,0),(.15,.96,1,0),(.35,1,1,0),(.5,.8,.84,0)],2.3),
 'forearm':([(-.5,.67,.72,0),(-.32,.74,.82,0),(.12,.93,.96,0),(.35,1,1,0),(.5,.87,.86,0)],2.2),
 'hand':([(-.5,.62,.67,0),(-.34,.83,.82,0),(.04,1.,1,0),(.37,.77,.8,0),(.5,.67,.72,0)],2.8),
 'shoe':([(-.5,.92,.96,0),(-.32,1,1,0),(.08,1,.98,0),(.33,.75,.79,-.08),(.5,.63,.55,-.17)],3.1),
 'sole':([(-.5,.96,.98,0),(.5,1,1,0)],3.7),
 'nose':([(-.5,.42,.54,0),(-.25,1,1,0),(.1,.71,.7,-.12),(.5,.33,.3,-.22)],2.),
 'detail':([(-.5,.44,.45,0),(0,1,1,0),(.5,.44,.45,0)],2.0),
}

def human_geometry(kind,sides=28):
    """Closed, smooth-normal profile mesh; no external character assets."""
    profile,power=PROFILES[kind]; vertices=[]
    # Interpolate width and depth without overshooting endpoints or creating poles.
    dense=[]
    for i,(a,b) in enumerate(zip(profile,profile[1:])):
        for t in (0.,.5):
            smooth=t*t*(3-2*t);dense.append((a[0]+(b[0]-a[0])*t,*(a[k]+(b[k]-a[k])*smooth for k in (1,2,3))))
    profile=dense+[profile[-1]]
    for y,w,d,offset in profile:
        for j in range(sides):
            theta=math.tau*j/sides; co,si=math.cos(theta),math.sin(theta)
            vertices.append((.5*w*math.copysign(abs(co)**(2/power),co),y,.5*d*math.copysign(abs(si)**(2/power),si)+offset))
    vertices.extend([(0,profile[0][0],profile[0][3]),(0,profile[-1][0],profile[-1][3])]);v=np.array(vertices,dtype=float);faces=[]
    for i in range(len(profile)-1):
        for j in range(sides):
            a=i*sides+j;b=i*sides+(j+1)%sides;c=a+sides;d=b+sides
            faces.extend([(a,c,b),(b,c,d)])
    for j in range(sides):
        n=(j+1)%sides;end=(len(profile)-1)*sides
        faces.extend([(len(v)-2,j,n),(len(v)-1,end+n,end+j)])
    normals=np.zeros_like(v)
    for f in faces:
        a,b,c=v[list(f)];normal=np.cross(b-a,c-a)
        for i in f:normals[i]+=normal
    normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-12)
    indices=np.array(faces).ravel();return np.ascontiguousarray(np.column_stack((v[indices],normals[indices])),dtype='f4')

def rounded_geometry(rings=10,sides=16):
    def v(i,j):
        phi=math.pi*i/rings; theta=math.tau*j/sides;n=(math.sin(phi)*math.cos(theta),math.cos(phi),math.sin(phi)*math.sin(theta));return (*[x*.5 for x in n],*n)
    return np.array([v(a,b) for i in range(rings) for j in range(sides) for a,b in ((i,j),(i+1,j),(i+1,j+1),(i,j),(i+1,j+1),(i,j+1))],dtype='f4')
