from dataclasses import dataclass
from pathlib import Path
import json, os, tempfile
import math
import numpy as np
from .camera import unit

@dataclass(frozen=True)
class Quality:
    name: str
    scale: float
    shadow: int
    distance: float
    lights: int
    bloom: bool
    fxaa: bool

PRESETS = (Quality('Low',.70,512,45,4,False,True), Quality('Medium',1.,1536,60,8,True,True), Quality('High',1.,2048,120,16,True,True), Quality('Ultra',1.,4096,180,16,True,True))

class Graphics:
    def __init__(self, preset=1):
        self.index = preset
        self.hour = 16.5
        self.running = False
        self.shadows = True
        self.bloom = True
        self.fxaa = True
        self.adaptive = False
        self.skinning = False
        self.material_detail = True
        self.ambient_occlusion = True
        self.grass = True
        self.terrain_shadows = True
        self.weather_effects = True
        self.water_detail = True
        self.hair_wind = True
        self.cloud_detail = True
        self.light_limit = 16
        self.shadow_limit = 4096
        self.scale = self.quality.scale
        self.exposure = 1.0
        self.target_fps = 60
        self._slow = self._fast = 0
    @property
    def quality(self): return PRESETS[self.index]
    def cycle(self):
        self.index = (self.index+1)%len(PRESETS); self.scale = self.quality.scale; self._slow=self._fast=0
    def cycle_scale(self):
        values=(.5,.7,.85,1.)
        i=min(range(len(values)),key=lambda i:abs(values[i]-self.scale)); self.scale=values[(i+1)%len(values)]; self.adaptive=False
    def cycle_lights(self):
        values=(4,8,16);self.light_limit=values[(values.index(self.light_limit)+1)%len(values)]
    def cycle_shadows(self):
        values=(512,1024,2048,4096);self.shadow_limit=values[(values.index(self.shadow_limit)+1)%len(values)]
    PREF_BOOLS=('shadows','bloom','fxaa','adaptive','skinning','material_detail','ambient_occlusion','grass','terrain_shadows','weather_effects','water_detail','hair_wind','cloud_detail')
    def load_preferences(self,path):
        try:
            data=json.loads(Path(path).read_text())
            if not isinstance(data,dict):return False
            if type(data.get('index')) is int and 0<=data['index']<len(PRESETS):self.index=data['index'];self.scale=self.quality.scale
            if type(data.get('scale')) in (int,float) and .5<=data['scale']<=1.:self.scale=float(data['scale'])
            for key in self.PREF_BOOLS:
                if type(data.get(key)) is bool:setattr(self,key,data[key])
            for key,values in [('light_limit',(4,8,16)),('shadow_limit',(512,1024,2048,4096))]:
                if type(data.get(key)) is int and data[key] in values:setattr(self,key,data[key])
            return True
        except (OSError,ValueError):return False
    def save_preferences(self,path):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
        data={key:getattr(self,key) for key in (*self.PREF_BOOLS,'index','scale','light_limit','shadow_limit')}
        with tempfile.NamedTemporaryFile('w',dir=path.parent,delete=False) as f:
            tmp=Path(f.name);json.dump(data,f)
        try:os.replace(tmp,path)
        finally:tmp.unlink(missing_ok=True)
    def adjust(self, delta): self.hour = (self.hour+delta)%24
    def step(self, dt):
        if self.running: self.adjust(dt/12)
    def feedback(self, fps):
        if not self.adaptive: return
        self._slow = self._slow+1 if fps < self.target_fps*.88 else 0
        self._fast = self._fast+1 if fps > self.target_fps*1.15 else 0
        if self._slow >= 3:
            self.scale = max(.50,round(self.scale-.05,2)); self._slow=0
        if self._fast >= 5:
            self.scale = min(self.quality.scale,round(self.scale+.05,2)); self._fast=0
    def sun(self):
        a = (self.hour-6)*math.pi/12
        d = unit(np.array([math.cos(a),math.sin(a),.38],dtype='f4'))
        daylight = max(0.,min(1.,float(d[1])*4+.12))
        warmth = max(0.,1.-abs(float(d[1]))*3)
        color = (1.,.91-.28*warmth,.78-.40*warmth)
        return d, color, daylight

def light_matrix(center, direction, distance, resolution):
    """Texel-snapped orthographic sun camera, world Y-up."""
    f = -unit(direction); up=np.array([0,1,0],dtype='f4')
    if abs(float(f@up))>.97: up=np.array([0,0,1],dtype='f4')
    r=unit(np.cross(f,up)); u=np.cross(r,f)
    c=np.array(center,dtype='f4'); texel=2*distance/resolution
    c += r*(round(float(r@c)/texel)*texel-float(r@c))
    c += u*(round(float(u@c)/texel)*texel-float(u@c))
    eye=c+direction*distance*2
    view=np.array([[*r,-r@eye],[*u,-u@eye],[*-f,f@eye],[0,0,0,1]],dtype='f4')
    n,far=.1,distance*4
    proj=np.diag([1/distance,1/distance,-2/(far-n),1]).astype('f4'); proj[2,3]=-(far+n)/(far-n)
    return proj@view
