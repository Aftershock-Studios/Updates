#version 330 core
in vec2 uv;out vec4 frag;uniform sampler2D u_hdr,u_bloom;uniform float u_exposure,u_rain,u_time,u_wind,u_submerged;uniform int u_use_bloom,u_fxaa,u_ao,u_perspective;uniform sampler2D u_depth;uniform mat4 u_inverse_projection;uniform float u_projection_y;
vec3 tone(vec3 x){x*=u_exposure;return pow(clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.),vec3(1./2.2));}
vec3 read_color(vec2 p){return tone(texture(u_hdr,p).rgb+(u_use_bloom==1?texture(u_bloom,p).rgb*.20:vec3(0)));}
float luma(vec3 c){return dot(c,vec3(.299,.587,.114));}
float hash2(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
vec3 viewPos(vec2 p,float d){vec4 v=u_inverse_projection*vec4(p*2.-1.,d*2.-1.,1.);return v.xyz/v.w;}
float ambientOcclusion(vec2 p){
    float d=texture(u_depth,p).r;if(d>=.999999)return 0.;vec3 pos=viewPos(p,d);
    vec2 px=1./vec2(textureSize(u_depth,0));
    vec3 right=viewPos(p+vec2(px.x,0.),texture(u_depth,p+vec2(px.x,0.)).r)-pos;
    vec3 left=pos-viewPos(p-vec2(px.x,0.),texture(u_depth,p-vec2(px.x,0.)).r);
    vec3 up=viewPos(p+vec2(0.,px.y),texture(u_depth,p+vec2(0.,px.y)).r)-pos;
    vec3 down=pos-viewPos(p-vec2(0.,px.y),texture(u_depth,p-vec2(0.,px.y)).r);
    vec3 n=cross(length(right)<length(left)?right:left,length(up)<length(down)?up:down);
    if(length(n)<1e-9)return 0.;n=normalize(n);if(n.z<0.)n=-n;
    float radius=.85;float pixelRadius=clamp(radius*u_projection_y*.5/px.y/(u_perspective==1?max(.2,-pos.z):1.),2.,30.);
    float ao=0.;
    for(int i=0;i<8;i++){
        float angle=float(i)*2.399963+hash2(floor(p/px))*.6;float ring=i<4?.48:1.;vec2 q=p+vec2(cos(angle),sin(angle))*px*pixelRadius*ring;
        if(any(lessThan(q,vec2(0.)))||any(greaterThan(q,vec2(1.))))continue;
        float sampleDepth=texture(u_depth,q).r;if(sampleDepth>=.999999)continue;
        vec3 delta=viewPos(q,sampleDepth)-pos;float dist=length(delta);if(dist<.01)continue;
        ao+=max(0.,dot(n,delta)/dist-.12)*(1.-smoothstep(.08,radius,dist));
    }
    return clamp(ao/8.*2.3,0.,.75);
}
void main(){vec3 c=read_color(uv);if(u_fxaa==1){vec2 p=1./vec2(textureSize(u_hdr,0));float a=luma(read_color(uv+vec2(-1,-1)*p)),b=luma(read_color(uv+vec2(1,-1)*p)),d=luma(read_color(uv+vec2(-1,1)*p)),e=luma(read_color(uv+p)),m=luma(c);float lo=min(m,min(min(a,b),min(d,e))),hi=max(m,max(max(a,b),max(d,e)));if(hi-lo>max(.045,hi*.125)){vec2 dir=vec2(-((a+b)-(d+e)),(a+d)-(b+e));float reduce=max((a+b+d+e)*.03125,.0078125);dir=clamp(dir/(min(abs(dir.x),abs(dir.y))+reduce),-8.,8.)*p;vec3 q=.5*(read_color(uv+dir*(-1./6.))+read_color(uv+dir*(1./6.)));vec3 r=q*.5+.25*(read_color(uv-dir*.5)+read_color(uv+dir*.5));float l=luma(r);c=(l<lo||l>hi)?q:r;}}if(u_ao==1)c*=1.-ambientOcclusion(uv)*.55;if(u_rain>.01 && u_submerged<.1){vec2 p=uv*vec2(190.,24.);p.x+=uv.y*(13.+18.*u_wind);p.y+=u_time*24.;vec2 cell=floor(p);vec2 f=fract(p);float n=hash2(cell);float streak=(1.-smoothstep(.025,.13,abs(f.x-n)))*smoothstep(.0,.16,f.y)*(1.-smoothstep(.37,.82,f.y));c=mix(c,vec3(.72,.81,.91),streak*step(.44,n)*u_rain*.23);vec2 nearP=uv*vec2(95.,13.);nearP.x+=uv.y*(7.+14.*u_wind);nearP.y+=u_time*15.;vec2 nf=fract(nearP);float seed=hash2(floor(nearP)+23.);float closeDrop=(1.-smoothstep(.015,.065,abs(nf.x-seed)))*smoothstep(.0,.12,nf.y)*(1.-smoothstep(.48,.94,nf.y));c=mix(c,vec3(.82,.88,.94),closeDrop*step(.82,seed)*u_rain*.29);}if(u_submerged>.001){float depth=texture(u_depth,uv).r;float dist=depth>=.99999?45.:length(viewPos(uv,depth));float scatter=1.-exp(-dist*.065);vec3 filtered=c*exp(-dist*vec3(.12,.035,.025));c=mix(c,mix(filtered,vec3(.055,.24,.28),scatter),u_submerged);}frag=vec4(c,1.);}
