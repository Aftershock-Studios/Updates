"""Original seamless surface maps. Layer order is shared with GLSL and the editor."""
from pathlib import Path
import os, tempfile
import numpy as np
from PIL import Image

NAMES=('Grass','Sand','Rock','Dirt','Snow','Water','Concrete','Asphalt','Brick','Wood','Metal')
PATTERNS=('Plain','Facade','Pavement','Emissive')+NAMES
ROOT=Path(__file__).resolve().parent.parent/'assets'/'materials'
# metres per repeat, base RGB (sRGB), roughness, metalness
SPECS=((2.4,(89,122,53),.91,0),(2.,(194,168,116),.87,0),(3.,(125,123,117),.85,0),(2.,(115,81,52),.94,0),(3.,(220,231,237),.82,0),(5.,(29,96,120),.16,0),(2.,(153,153,148),.82,0),(2.,(60,64,68),.89,0),(2.,(147,77,55),.84,0),(2.,(133,90,54),.67,0),(2.,(159,165,172),.32,.85))
def maps(index,size=512):
    rng=np.random.default_rng(9081+index); y,x=np.mgrid[:size,:size]/size
    def noise(n):
        # Fourier filtering of periodic noise; no hard tile seams.
        a=rng.normal(size=(size,size)); f=np.fft.fftfreq(size)*size; k=np.hypot(f[:,None],f[None,:]); v=np.fft.ifft2(np.fft.fft2(a)*np.exp(-.5*(k/n)**2)).real
        return v/max(v.std(),1e-9)
    broad=noise(5); mid=noise(22); fine=noise(110); micro=noise(205); h=.30*broad+.35*mid+.18*fine+.07*micro
    if index==0: h=.22*broad+.35*mid+.24*fine+.14*micro
    if index==1: h=.15*broad+.22*mid+.12*fine+.15*np.sin(2*np.pi*(8*y+2*x)+broad*.65)
    if index==2: h=.48*broad+.20*mid+.10*fine; h+=.19*np.tanh(3*mid)
    if index==4: h=.12*broad+.16*mid+.10*fine
    if index==5: h=.15*np.sin(2*np.pi*(3*x+5*y))+.10*np.sin(2*np.pi*(7*x-3*y))+.08*mid
    if index==6: h=.12*broad+.22*mid+.24*fine+.12*micro
    if index==7: h=.09*broad+.32*mid+.34*fine+.12*micro
    if index==8:
        row=np.floor(y*8); xx=(x*4+.5*(row%2))%1; yy=(y*8)%1; edge=np.minimum(np.minimum(xx,1-xx),np.minimum(yy,1-yy)); mortar=np.clip((.055-edge)/.027,0,1); h=.10*mid+.08*fine-.65*mortar
    if index==9: h=.23*np.sin(2*np.pi*(15*x)+.9*broad)+.08*mid+.05*fine
    if index==10: h=.05*broad+.06*mid+.08*np.sin(2*np.pi*96*y)
    # Physically motivated periodic feature masks: granular aggregate, cracks,
    # wood pores and brick relief, with independent roughness response.
    speck=noise(155); pores=np.clip((-speck-1.15)*1.3,0,1)
    if index in (0,3): h+=.11*np.tanh(2.5*fine)+.09*speck-.11*pores
    if index in (2,6): h+=.11*np.tanh(4*mid)+.08*speck-.18*pores
    if index==7:h+=.18*np.tanh(2.8*fine)+.13*speck-.16*pores
    if index==8:h+=.055*speck-.13*pores*(1-mortar)
    if index==9:h+=.09*np.sin(2*np.pi*(47*x)+1.8*mid)+.07*speck
    if index==10:h+=.035*speck
    scale,rgb,rough,metal=SPECS[index]; tint=np.clip(1+.19*h+.055*broad,.55,1.45)
    albedo=np.asarray(rgb)[None,None,:]*tint[:,:,None]
    if index==0:albedo*=np.stack((1+.05*mid,1+.015*mid,1-.08*mid),axis=-1).clip(.75,1.25)
    if index in (2,6,7):albedo*=1.-.12*pores[:,:,None]
    if index==7:albedo+=np.clip(fine-1.1,0,1)[:,:,None]*19
    if index==9:albedo*=1.-.09*pores[:,:,None]
    if index==8: albedo=albedo*(1-mortar[:,:,None])+np.array([157,149,137])*mortar[:,:,None]
    roughness=np.clip(rough+.065*mid+.035*pores,.06,1)
    # Periodic central differences; normal map encoded in tangent space.
    gx=(np.roll(h,-1,1)-np.roll(h,1,1))*1.30; gy=(np.roll(h,-1,0)-np.roll(h,1,0))*1.30
    normal=np.stack((-gx,-gy,np.ones_like(h)),axis=-1); normal/=np.linalg.norm(normal,axis=-1,keepdims=True)
    return np.uint8(np.clip(np.dstack((albedo,roughness*255)),0,255)),np.uint8(np.clip((normal*.5+.5)*255,0,255))
def generate():
    ROOT.mkdir(parents=True,exist_ok=True)
    for i,n in enumerate(NAMES):
        a,b=maps(i);Image.fromarray(a).save(ROOT/(n+'_surface.png'));Image.fromarray(b).save(ROOT/(n+'_normal.png'))
def import_pbr(project,name,folder):
    """Import standard albedo/roughness/OpenGL normal maps, with a bounded size."""
    if name not in NAMES or name=='Water':raise ValueError('Choose a solid material from the material library')
    folder=Path(folder).expanduser(); candidates={p.stem.casefold():p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ('.png','.jpg','.jpeg','.webp')}
    def find(keys):
        for key in keys:
            for stem,path in sorted(candidates.items()):
                if stem==key or stem.endswith('_'+key):return path
        raise ValueError('Missing map: '+keys[0]+' (use PNG/JPG; see PBR import guide)')
    def read(path,mode):
        with Image.open(path) as im:
            if max(im.size)>8192:raise ValueError('Maximum input texture size is 8192 pixels')
            return np.asarray(im.convert(mode).resize((1024,1024),Image.Resampling.LANCZOS))
    albedo=read(find(('albedo','diff','color','basecolor','base_color')),'RGB')
    rough=read(find(('roughness','rough')),'L')
    normal=read(find(('normal_gl','nor_gl','normal','normal_opengl')),'RGB')
    dest=Path(project)/'assets'/'pbr';dest.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=dest,suffix='.npz',delete=False) as f:
        tmp=Path(f.name);np.savez_compressed(f,surface=np.dstack((albedo,rough)),normal=normal)
    try:os.replace(tmp,dest/(name+'.npz'))
    finally:tmp.unlink(missing_ok=True)
    return dest/(name+'.npz')

def load(project=None):
    def read(name,suffix,mode):
        with Image.open(ROOT/(name+suffix+'.png')) as im:return np.asarray(im.convert(mode))
    surface=[read(n,'_surface','RGBA') for n in NAMES];normal=[read(n,'_normal','RGB') for n in NAMES]
    overrides={}
    if project is not None:
        for i,name in enumerate(NAMES):
            p=Path(project)/'assets'/'pbr'/(name+'.npz')
            if not p.is_file() or p.stat().st_size>16*1024*1024:continue
            try:
                with np.load(p,allow_pickle=False) as data:
                    a,b=data['surface'],data['normal']
                    if a.shape!=(1024,1024,4) or b.shape!=(1024,1024,3) or a.dtype!=np.uint8 or b.dtype!=np.uint8:raise ValueError('Invalid PBR override')
                    overrides[i]=(a,b)
            except (ValueError,OSError,KeyError) as exc:print('Ignoring invalid PBR override:',name,exc)
    if overrides:
        for i in range(len(NAMES)):
            if i in overrides:surface[i],normal[i]=overrides[i]
            else:surface[i]=np.asarray(Image.fromarray(surface[i]).resize((1024,1024),Image.Resampling.BILINEAR));normal[i]=np.asarray(Image.fromarray(normal[i]).resize((1024,1024),Image.Resampling.BILINEAR))
    return np.stack(surface),np.stack(normal)
if __name__=='__main__':generate()
