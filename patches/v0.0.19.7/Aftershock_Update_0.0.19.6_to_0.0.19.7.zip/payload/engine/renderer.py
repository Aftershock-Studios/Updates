from pathlib import Path
import numpy as np
import moderngl
from .camera import perspective
from .world import FACES
from .visibility import RenderSnapshot, frustum_planes, visible_mask
from .graphics import Graphics, light_matrix
from dataclasses import replace
from . import config
from .assets import load_vertices
from .terrain import Stream, WATER_GRID
from .materials import load as load_materials
from .decorations import Decorations, blade_geometry
from .character import human_geometry, PROFILES
from .vehicle_mesh import GEOMETRY as VEHICLE_GEOMETRY
from .vegetation import Forest, GEOMETRY as TREE_GEOMETRY
from .environment import Atmosphere
import time, os

class Renderer:
    def __init__(self, ctx=None):
        self.ctx = ctx or moderngl.create_context(require=330)
        self.graphics = Graphics();self.atmosphere=Atmosphere();self.character=None;self.city_runtime=None
        shaders = Path(__file__).parent / 'shaders'
        def program(v,f): return self.ctx.program(vertex_shader=(shaders/v).read_text(),fragment_shader=(shaders/f).read_text())
        self.program=program('world.vert','world.frag'); self.terrain_program=program('terrain.vert','world.frag'); self.terrain_stream=Stream(); self.terrain_gpu={}; self.terrain_shadow_gpu={}; self.terrain_source=None; self.shadow_program=program('shadow.vert','shadow.frag');self.terrain_shadow=program('terrain_shadow.vert','shadow.frag')
        surface,normal=load_materials(project=os.environ.get("METROPOLIS_PROJECT")); layers,h,w,_=surface.shape
        self.surface_maps=self.ctx.texture_array((w,h,layers),4,surface.tobytes());self.normal_maps=self.ctx.texture_array((w,h,layers),3,normal.tobytes())
        for tex in (self.surface_maps,self.normal_maps):
            tex.repeat_x=tex.repeat_y=True;tex.build_mipmaps();tex.filter=(moderngl.LINEAR_MIPMAP_LINEAR,moderngl.LINEAR)
            try:tex.anisotropy=min(8.,self.ctx.max_anisotropy)
            except (AttributeError,ValueError,moderngl.Error):pass
        for p in (self.program,self.terrain_program):p['u_surface_maps'].value=2;p['u_normal_maps'].value=3
        self.decorations=Decorations();self.grass=program('grass.vert','grass.frag');self.grass_vertices=blade_geometry();self.grass_geometry=self.ctx.buffer(self.grass_vertices.tobytes());self.grass_instances=self.ctx.buffer(reserve=24,dynamic=True)
        self.grass_vao=self.ctx.vertex_array(self.grass,[(self.grass_geometry,'3f','in_blade'),(self.grass_instances,'3f 3f /i','in_root','in_params')]);self.grass['u_shadow'].value=0;self.grass_count=0;self.clock=time.monotonic()
        self.sky=program('screen.vert','sky.frag'); self.blur=program('screen.vert','bloom.frag'); self.post=program('screen.vert','post.frag'); self.ui=program('screen.vert','overlay.frag')
        vertices=[(*[v-.5 for v in corners[i]],*normal) for normal,corners in FACES for i in (0,1,2,0,2,3)]
        self.vertex=self.ctx.buffer(np.array(vertices,dtype='f4').tobytes())
        self.instances=self.ctx.buffer(reserve=92,dynamic=True); self.shadow_instances=self.ctx.buffer(reserve=92,dynamic=True)
        cols=('i_col0','i_col1','i_col2','i_col3')
        self.vao=self.ctx.vertex_array(self.program,[(self.vertex,'3f 3f','in_pos','in_normal'),(self.instances,'4f 4f 4f 4f 3f 4f /i',*cols,'i_color','i_material')])
        self.shadow_vao=self.ctx.vertex_array(self.shadow_program,[(self.vertex,'3f 12x','in_pos'),(self.shadow_instances,'4f 4f 4f 4f 28x /i',*cols)])
        self.rig_gpu={};self.skin_model=None;self.skin_gpu={};self.forest=Forest()
        for kind in (*PROFILES,*VEHICLE_GEOMETRY,*TREE_GEOMETRY):
            rig=human_geometry(kind) if kind in PROFILES else (VEHICLE_GEOMETRY|TREE_GEOMETRY)[kind]();buf=self.ctx.buffer(rig.tobytes())
            vao=self.ctx.vertex_array(self.program,[(buf,'3f 3f','in_pos','in_normal'),(self.instances,'4f 4f 4f 4f 3f 4f /i',*cols,'i_color','i_material')])
            shadow=self.ctx.vertex_array(self.shadow_program,[(buf,'3f 12x','in_pos'),(self.shadow_instances,'4f 4f 4f 4f 28x /i',*cols)])
            self.rig_gpu[kind]=(buf,vao,shadow,len(rig))
        self.sky_vao,self.blur_vao,self.post_vao,self.ui_vao=[self.ctx.vertex_array(p,[]) for p in (self.sky,self.blur,self.post,self.ui)]
        self.program['u_shadow'].value=0; self.terrain_program['u_shadow'].value=0; self.blur['u_source'].value=0; self.post['u_hdr'].value=0; self.post['u_bloom'].value=1; self.post['u_depth'].value=4; self.ui['u_ui'].value=0
        self.asset_gpu={}; self.groups={}; self.snapshot=None; self.targets=[]; self.shadow_targets=[]; self.size=None; self.shadow_size=0; self.ui_texture=None; self.ui_size=None; self.last_ui_image=None
        self.visible=self.total=self.triangles=self.draw_calls=self.shadow_count=0; self.gpu_ms=None; self.gpu_supported=True
        self.lamps=np.empty((0,3),dtype='f4')
        print('GPU:',self.ctx.info.get('GL_RENDERER','Unknown')); print('OpenGL:',self.ctx.info.get('GL_VERSION','Unknown'))

    def resize(self,w,h):
        if self.size==(w,h): return
        for r in self.targets: r.release()
        self.size=(w,h); self.hdr=self.ctx.texture((w,h),4,dtype='f2'); self.depth=self.ctx.depth_texture((w,h));self.depth.compare_func='';self.depth.repeat_x=self.depth.repeat_y=False;self.depth.filter=(moderngl.NEAREST,moderngl.NEAREST)
        self.hdr_fbo=self.ctx.framebuffer([self.hdr],self.depth)
        bw,bh=max(1,w//2),max(1,h//2); self.bloom_size=(bw,bh)
        self.bloom_a=self.ctx.texture((bw,bh),4,dtype='f2'); self.bloom_b=self.ctx.texture((bw,bh),4,dtype='f2')
        self.bloom_fbo_a=self.ctx.framebuffer([self.bloom_a]); self.bloom_fbo_b=self.ctx.framebuffer([self.bloom_b])
        for tex in (self.hdr,self.bloom_a,self.bloom_b): tex.repeat_x=tex.repeat_y=False; tex.filter=(moderngl.LINEAR,moderngl.LINEAR)
        self.targets=[self.hdr_fbo,self.bloom_fbo_a,self.bloom_fbo_b,self.hdr,self.depth,self.bloom_a,self.bloom_b]

    def resize_shadow(self,res):
        if self.shadow_size==res: return
        for r in self.shadow_targets: r.release()
        self.shadow_size=res; self.shadow_tex=self.ctx.depth_texture((res,res)); self.shadow_tex.compare_func=''; self.shadow_tex.repeat_x=self.shadow_tex.repeat_y=False; self.shadow_tex.filter=(moderngl.NEAREST,moderngl.NEAREST)
        self.shadow_fbo=self.ctx.framebuffer(depth_attachment=self.shadow_tex); self.shadow_targets=[self.shadow_fbo,self.shadow_tex]

    @staticmethod
    def upload(buffer,data):
        if not len(data): return
        buffer.orphan(max(data.nbytes,buffer.size)); buffer.write(data.tobytes())

    def mesh_gpu(self,kind):
        if kind=='cube': return self.vao,self.shadow_vao,36
        if kind not in self.asset_gpu:
            try: v=load_vertices(kind)
            except (OSError,ValueError) as exc:
                print('Asset unavailable, using cube:',kind,exc); self.asset_gpu[kind]=None; return self.vao,self.shadow_vao,36
            buf=self.ctx.buffer(v.tobytes()); cols=('i_col0','i_col1','i_col2','i_col3')
            vao=self.ctx.vertex_array(self.program,[(buf,'3f 3f','in_pos','in_normal'),(self.instances,'4f 4f 4f 4f 3f 4f /i',*cols,'i_color','i_material')])
            shadow=self.ctx.vertex_array(self.shadow_program,[(buf,'3f 12x','in_pos'),(self.shadow_instances,'4f 4f 4f 4f 28x /i',*cols)])
            self.asset_gpu[kind]=(buf,vao,shadow,len(v))
        entry=self.asset_gpu[kind]
        return (entry[1],entry[2],entry[3]) if entry else (self.vao,self.shadow_vao,36)

    def prepare(self,scene,camera,w,h,culling,projection=None):
        if self.snapshot is None or self.snapshot.scene is not scene or self.snapshot.revision!=scene.revision:
            self.snapshot=RenderSnapshot(scene,'cube')
            self.groups={k: (self.snapshot if k=='cube' else RenderSnapshot(scene,k)) for k in {m.kind for m in scene.meshes.values()}}
            self.lamps=np.array([self.snapshot.static_world[e][:3,3] for e in scene.names if scene.names[e]=='Streetlight' and e in self.snapshot.static_world],dtype='f4').reshape(-1,3)
        large=scene.name=='Stress City'; far=2600. if scene.terrain is not None else 2200. if large else config.FAR
        proj=projection if projection is not None else perspective(config.FOV,w/h,config.NEAR,far);vp=proj@camera.view(); planes=frustum_planes(vp)
        self.post['u_inverse_projection'].write(np.linalg.inv(proj).astype('f4').T.copy().tobytes());self.post['u_projection_y'].value=float(abs(proj[1,1]));self.post['u_perspective'].value=int(abs(proj[3,2])>.5)
        g=self.graphics; q=replace(g.quality,shadow=min(g.quality.shadow,g.shadow_limit),lights=min(g.quality.lights,g.light_limit)); sun,color,day=g.sun(); self.shadow_count=0
        at=self.atmosphere; day*=1.-.55*at.cloud; color=tuple(float(x)*(1.-.25*at.cloud)+at.flash*.65 for x in color)
        center=camera.position+camera.forward*q.distance*.25; center[1]=min(center[1],45.)
        light=light_matrix(center,sun,q.distance,q.shadow)
        shadow_on=g.shadows and sun[1]>.045
        shadow_planes=frustum_planes(light) if shadow_on else None
        self.visible=self.total=self.triangles=0; self.main_batches=[]; self.shadow_batches=[]
        for kind,snap in self.groups.items():
            batches=[snap.nearby(camera.position,far+q.distance) if culling else snap.static,snap.dynamic()]; self.total+=len(snap.static[0])+len(batches[1][0])
            def collect(p):
                rows=[data[visible_mask(centers,radii,p)] if p is not None else data for data,centers,radii in batches if len(data)]
                return np.concatenate(rows) if rows else np.empty((0,23),dtype='f4')
            vao,shadow_vao,verts=self.mesh_gpu(kind); data=collect(planes if culling else None)
            self.visible+=len(data); self.triangles+=len(data)*(verts//3)
            if len(data): self.main_batches.append((vao,verts,data))
            if shadow_on:
                sd=collect(shadow_planes); self.shadow_count+=len(sd)
                if len(sd): self.shadow_batches.append((shadow_vao,verts,sd))
        rigs=dict(self.forest.update(scene.terrain,camera.position,q.name))
        wind=at.wind if g.hair_wind else 0.
        if self.character is not None:self.character.wind=wind;self.character.wind_time=at.time
        if self.city_runtime is not None:
            for _,char in self.city_runtime.people:char.wind=wind;char.wind_time=at.time
            cars,city_rigs=self.city_runtime.batches(camera.position)
            for k,v in city_rigs.items():rigs[k]=np.concatenate((rigs[k],v)) if k in rigs else v
            if len(cars):
                self.main_batches.append((self.vao,36,cars));self.visible+=len(cars);self.total+=len(cars);self.triangles+=len(cars)*12
                if shadow_on:self.shadow_batches.append((self.shadow_vao,36,cars))
        if self.character is not None and g.skinning:
            from .skinning import HumanSkin
            if self.skin_model is None:self.skin_model=HumanSkin()
            cols=('i_col0','i_col1','i_col2','i_col3')
            for key,data in self.skin_model.vertices(self.character).items():
                if key not in self.skin_gpu:
                    buf=self.ctx.buffer(data.tobytes(),dynamic=True)
                    vao=self.ctx.vertex_array(self.program,[(buf,'3f 3f','in_pos','in_normal'),(self.instances,'4f 4f 4f 4f 3f 4f /i',*cols,'i_color','i_material')])
                    shadow=self.ctx.vertex_array(self.shadow_program,[(buf,'3f 12x','in_pos'),(self.shadow_instances,'4f 4f 4f 4f 28x /i',*cols)])
                    self.skin_gpu[key]=(buf,vao,shadow)
                else:
                    buf,vao,shadow=self.skin_gpu[key];buf.write(data.tobytes())
                instances=self.skin_model.instance(key);self.main_batches.append((vao,len(data),instances));self.triangles+=len(data)//3
                if shadow_on:self.shadow_batches.append((shadow,len(data),instances))
            self.visible+=1;self.total+=1
        elif self.character is not None:
            for k,v in self.character.batches().items():rigs[k]=np.concatenate((rigs[k],v)) if k in rigs else v
        if rigs:
            for kind,data in rigs.items():
                _,vao,shadow,verts=self.rig_gpu[kind]
                self.main_batches.append((vao,verts,data));self.visible+=len(data);self.total+=len(data);self.triangles+=len(data)*verts//3
                if shadow_on:self.shadow_batches.append((shadow,verts,data))
        programs=(self.program,self.terrain_program) if scene.terrain is not None else (self.program,)
        fog=(700.,1750.) if scene.terrain is not None else (650.,1800.) if large else (95.,360.)
        elapsed=at.time%3600
        fog=tuple(v*(1.-.84*at.fog) for v in fog)
        self.sky["u_cloud_detail"].value=int(g.cloud_detail);self.sky["u_cloud"].value=at.cloud;self.sky["u_time"].value=elapsed;self.sky["u_flash"].value=at.flash
        from .water_physics import water_surface
        water=water_surface(scene.terrain,float(camera.position[0]),float(camera.position[2]),elapsed) if scene.terrain is not None and camera.position[1]<scene.terrain.water+.2 else None
        self.post['u_submerged'].value=float(max(0.,min(1.,(water-camera.position[1])*2.))) if water is not None else 0.
        self.post["u_rain"].value=at.rain if g.weather_effects else 0.;self.post["u_time"].value=elapsed;self.post["u_wind"].value=at.wind
        for program in programs:
            program['u_wet'].value=at.wetness;program['u_puddles'].value=at.puddles;program['u_rainfall'].value=at.rain if g.weather_effects else 0.;program['u_cloud'].value=at.cloud;program['u_time'].value=elapsed;program['u_material_detail'].value=int(q.name!='Low' and g.material_detail);program['u_water_detail'].value=int(g.water_detail);
            program['u_view_projection'].write(vp.T.copy().tobytes());program['u_light_matrix'].write(light.T.copy().tobytes())
            program['u_fog'].value=fog;program['u_shadows'].value=int(shadow_on);program['u_shadow_texel'].value=2*q.distance/q.shadow
        self.shadow_program['u_light_matrix'].write(light.T.copy().tobytes());self.terrain_shadow['u_light_matrix'].write(light.T.copy().tobytes());self.grass['u_light_matrix'].write(light.T.copy().tobytes());self.grass['u_shadows'].value=int(shadow_on)
        self.sky['u_inverse_vp'].write(np.linalg.inv(vp).astype('f4').T.copy().tobytes())
        for p in (*programs,self.sky):
            p['u_camera'].value=tuple(map(float,camera.position)); p['u_sun'].value=tuple(map(float,sun)); p['u_sun_color'].value=color; p['u_day'].value=day
        lights=np.zeros((16,4),dtype='f4'); colors=np.zeros((16,4),dtype='f4'); n=0
        if len(self.lamps) and day<.98:
            order=np.argsort(np.sum((self.lamps-camera.position)**2,axis=1))[:max(0,q.lights-1)]
            n=len(order); lights[:n,:3]=self.lamps[order]; lights[:n,1]-=.12; lights[:n,3]=22.; colors[:n,:3]=np.array([42,25,10],dtype='f4')*(1.-day); colors[:n,3]=1.
        # One omnidirectional demo light alongside the spotlight-style street lamps.
        if not large and n<q.lights and day<.98:
            lights[n]=(0,3,0,18); colors[n]=(*(np.array([12,20,35])*(1-day)),0.); n+=1
        for program in programs:
            program['u_lights'].write(lights.tobytes());program['u_light_colors'].write(colors.tobytes());program['u_light_count'].value=n
        # Synchronize terrain GPU buffers, with a limited upload budget per frame.
        terrain=scene.terrain; stream=self.terrain_stream
        stream.update(terrain,camera.position)
        grass=self.decorations.update(terrain if g.grass else None,camera.position,2 if q.name in ('High','Ultra') else 1,3 if q.name=='Low' else 2 if q.name=='Medium' else 1)
        if self.decorations.changed:self.upload(self.grass_instances,grass)
        self.grass_count=len(grass) if g.grass else 0
        if self.grass_count:
            self.grass['u_wind'].value=at.wind;self.grass['u_view_projection'].write(vp.T.copy().tobytes());self.grass['u_camera'].value=tuple(map(float,camera.position));self.grass['u_time'].value=elapsed;self.grass['u_day'].value=day;self.grass['u_range'].value=60. if q.name in ('High','Ultra') else 32.;self.grass['u_sun'].value=tuple(map(float,sun));self.grass['u_sun_color'].value=color

        if terrain is not self.terrain_source:
            for _,buf,vao in self.terrain_gpu.values(): vao.release();buf.release()
            for vao,_ in self.terrain_shadow_gpu.values():vao.release()
            self.terrain_shadow_gpu.clear();self.terrain_gpu.clear();self.terrain_source=terrain
        for k in list(self.terrain_gpu):
            if k not in stream.desired:
                _,buf,vao=self.terrain_gpu.pop(k);self.terrain_shadow_gpu.pop(k)[0].release();vao.release();buf.release()
        uploads=0
        for k,(lod,vertices) in stream.ready.items():
            old=self.terrain_gpu.get(k)
            if old and old[0]==lod:continue
            if uploads>=2:break
            if old:self.terrain_shadow_gpu.pop(k)[0].release();old[2].release();old[1].release()
            buf=self.ctx.buffer(vertices.tobytes());vao=self.ctx.vertex_array(self.terrain_program,[(buf,'3f 3f 3f 3f 3f','in_pos','in_normal','in_color','in_weights0','in_weights1')]);self.terrain_gpu[k]=(lod,buf,vao);uploads+=1
            water_count=WATER_GRID**2*6
            count=len(vertices)-(water_count if len(vertices)>=water_count and np.all(vertices[-water_count:,14]>.99) and np.allclose(vertices[-water_count:,1],terrain.water) else 0)
            self.terrain_shadow_gpu[k]=(self.ctx.vertex_array(self.terrain_shadow,[(buf,'3f 48x','in_pos')]),count)
        if self.terrain_gpu:
            self.triangles+=sum(buf.size//60//3 for _,buf,_ in self.terrain_gpu.values())
        self.triangles+=self.grass_count*(len(self.grass_vertices)//3)
        return shadow_on

    def draw(self,scene,camera,width,height,culling=True,profile=False,output=None,viewport=None,projection=None):
        g=self.graphics; q=g.quality; w,h=max(1,int(width*g.scale)),max(1,int(height*g.scale)); g.render_size=(w,h); self.resize(w,h); self.resize_shadow(min(q.shadow,g.shadow_limit) if g.shadows else 1)
        shadow_on=self.prepare(scene,camera,width,height,culling,projection); use_bloom=g.bloom and q.bloom; self.draw_calls=0
        output=output if output is not None else self.ctx.screen
        def submit():
            self.ctx.disable(moderngl.BLEND|moderngl.CULL_FACE); self.ctx.enable(moderngl.DEPTH_TEST)
            if shadow_on:
                self.shadow_fbo.use(); self.ctx.viewport=(0,0,self.shadow_size,self.shadow_size); self.shadow_fbo.clear(depth=1.)
                for vao,verts,data in self.shadow_batches:
                    self.upload(self.shadow_instances,data); vao.render(mode=moderngl.TRIANGLES,vertices=verts,instances=len(data)); self.draw_calls+=1
                if q.name in ('High','Ultra') and g.terrain_shadows:
                    for vao,count in self.terrain_shadow_gpu.values():
                        if count:vao.render(mode=moderngl.TRIANGLES,vertices=count);self.draw_calls+=1
            self.hdr_fbo.use(); self.ctx.viewport=(0,0,w,h); self.hdr_fbo.clear(0,0,0,1,depth=1.)
            self.ctx.disable(moderngl.DEPTH_TEST); self.sky_vao.render(mode=moderngl.TRIANGLES,vertices=3); self.draw_calls+=1
            self.ctx.enable(moderngl.DEPTH_TEST); self.shadow_tex.use(0); self.surface_maps.use(2); self.normal_maps.use(3)
            for vao,verts,data in self.main_batches:
                self.upload(self.instances,data); vao.render(mode=moderngl.TRIANGLES,vertices=verts,instances=len(data)); self.draw_calls+=1
            for _,buf,vao in self.terrain_gpu.values():
                vao.render(mode=moderngl.TRIANGLES,vertices=buf.size//60);self.draw_calls+=1
            if self.grass_count:
                self.grass_vao.render(mode=moderngl.TRIANGLES,vertices=len(self.grass_vertices),instances=self.grass_count);self.draw_calls+=1
            self.ctx.disable(moderngl.DEPTH_TEST)
            if use_bloom:
                bw,bh=self.bloom_size; self.bloom_fbo_a.use(); self.ctx.viewport=(0,0,bw,bh); self.hdr.use(0); self.blur['u_direction'].value=(1/w,0); self.blur['u_extract'].value=1; self.blur_vao.render(mode=moderngl.TRIANGLES,vertices=3)
                self.bloom_fbo_b.use(); self.bloom_a.use(0); self.blur['u_direction'].value=(0,1/bh); self.blur['u_extract'].value=0; self.blur_vao.render(mode=moderngl.TRIANGLES,vertices=3); self.draw_calls+=2
            output.use(); self.ctx.viewport=viewport or (0,0,width,height); self.hdr.use(0); self.bloom_b.use(1); self.depth.use(4); self.post['u_ao'].value=int(q.name in ('High','Ultra') and g.ambient_occlusion); self.post['u_exposure'].value=g.exposure; self.post['u_use_bloom'].value=int(use_bloom); self.post['u_fxaa'].value=int(g.fxaa and q.fxaa); self.post_vao.render(mode=moderngl.TRIANGLES,vertices=3); self.draw_calls+=1
        query=None
        if profile and self.gpu_supported:
            try: query=self.ctx.query(time=True)
            except Exception as exc: self.gpu_supported=False; print('GPU timer unavailable:',exc)
        if query is None: submit()
        else:
            try:
                with query: submit()
                elapsed=query.elapsed; self.gpu_ms=elapsed/1e6 if 0<elapsed<4294967295 else None
            except Exception as exc:
                self.gpu_supported=False; self.gpu_ms=None; print('GPU timer failed:',exc); self.draw_calls=0; submit()
            finally:
                release=getattr(query,'release',None)
                if release: release()

    def overlay(self,image,width,height,logical_w,logical_h,logical_size=None):
        if self.ui_size!=image.size:
            if self.ui_texture: self.ui_texture.release()
            self.ui_size=image.size; self.ui_texture=self.ctx.texture(image.size,4); self.ui_texture.filter=(moderngl.LINEAR,moderngl.LINEAR)
        if self.last_ui_image is not image:
            self.ui_texture.write(image.tobytes()); self.last_ui_image=image
        self.ui_texture.use(0); panel_w,panel_h=logical_size or image.size; self.ui['u_fraction'].value=(panel_w/max(1,logical_w),panel_h/max(1,logical_h))
        self.ctx.viewport=(0,0,width,height); self.ctx.disable(moderngl.DEPTH_TEST); self.ctx.enable(moderngl.BLEND); self.ctx.blend_func=moderngl.SRC_ALPHA,moderngl.ONE_MINUS_SRC_ALPHA; self.ui_vao.render(mode=moderngl.TRIANGLES,vertices=3); self.ctx.disable(moderngl.BLEND)

    def close(self):
        self.terrain_stream.close()
        for _,buf,vao in self.terrain_gpu.values():vao.release();buf.release()
        for vao,_ in self.terrain_shadow_gpu.values():vao.release()
        self.terrain_shadow.release();self.terrain_program.release()
        for buf,vao,shadow in self.skin_gpu.values():
            for r in (vao,shadow,buf):r.release()
        for buf,vao,shadow,_ in self.rig_gpu.values():
            for r in (vao,shadow,buf):r.release()
        for r in (self.grass_vao,self.grass_geometry,self.grass_instances,self.grass,self.surface_maps,self.normal_maps):r.release()
        if self.ui_texture: self.ui_texture.release()
        for entry in self.asset_gpu.values():
            if entry:
                for r in (entry[1],entry[2],entry[0]): r.release()
        for r in self.targets+self.shadow_targets+[self.vao,self.shadow_vao,self.sky_vao,self.blur_vao,self.post_vao,self.ui_vao,self.instances,self.shadow_instances,self.vertex,self.program,self.shadow_program,self.sky,self.blur,self.post,self.ui]: r.release()
