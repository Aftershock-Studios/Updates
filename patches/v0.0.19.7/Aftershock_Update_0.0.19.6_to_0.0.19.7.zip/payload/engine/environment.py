"""Scene-persistent weather settings and bounded transition/ambient simulation."""
from dataclasses import dataclass,asdict
import math
PRESETS={'Clear':(0.,0.,.22,0.),'Cloudy':(.70,0.,.42,0.),'Rain':(.86,.70,.65,.16),'Storm':(1.,1.,1.,.25),'Fog':(.65,0.,.14,.78)}
@dataclass(frozen=True)
class Environment:
    weather:str='Clear'
    audio:bool=True
    volume:float=.65
    def __post_init__(self):
        if self.weather not in PRESETS or type(self.audio) is not bool or not math.isfinite(self.volume) or not 0<=self.volume<=1:raise ValueError('Invalid environment settings')
    def data(self):return asdict(self)
class Atmosphere:
    def __init__(self):self.cloud,self.rain,self.wind,self.fog=PRESETS['Clear'];self.time=0.;self.flash=0.;self.thunder=False;self.next_flash=10.;self.wetness=0.;self.puddles=0.
    def step(self,settings,dt,sunlight=1.):
        target=PRESETS[settings.weather];self.time+=dt;self.thunder=False
        for key,val in zip(('cloud','rain','wind','fog'),target):setattr(self,key,getattr(self,key)+(val-getattr(self,key))*min(1.,dt*.65))
        # Rain accumulates; sun and wind slowly evaporate standing water after rain.
        sun=max(0.,min(1.,float(sunlight)))*(1.-self.cloud)
        dry=.0018+.013*sun+.003*self.wind
        self.wetness=max(0.,min(1.,self.wetness+dt*(.11*self.rain*(1.-self.wetness)-dry*(1.-self.rain))))
        self.puddles=max(0.,min(1.,self.puddles+dt*(.055*self.rain*max(0.,self.wetness-.35)-(.0008+.007*sun+.0015*self.wind)*(1.-self.rain))))
        self.flash=max(0.,self.flash-dt*3.5)
        if settings.weather!='Storm':self.next_flash=self.time+5.
        elif self.time>=self.next_flash:self.flash=1.;self.thunder=True;self.next_flash=self.time+9+4*math.sin(self.time)**2
        return self
