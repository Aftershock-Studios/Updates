"""macOS bootstrap. Reuses Conda, builds pinned native Luau once, launches Studio."""
import os, sys, subprocess, json, shutil, pathlib, hashlib, argparse, traceback, tempfile, random
P=pathlib.Path
ROOT=P(__file__).resolve().parent.parent
SUPPORT=P(os.environ.get('METROPOLIS_SUPPORT',P.home()/'Library/Application Support/Metropolis'))
PROJECT=SUPPORT/'Projects'/'Project City'
CONDA=os.environ.get('METROPOLIS_CONDA','conda')
TAG='0.746'
SUPPORT.mkdir(parents=True,exist_ok=True)
LOG=SUPPORT/'launcher.log'

def python_library_candidates(env, info):
    """Conda can advertise a static .a in LDLIBRARY on macOS. Never load it."""
    env=P(env)
    version=info['version']
    names=[f'libpython{version}.dylib', f'libpython{version}m.dylib',
           info.get('INSTSONAME'), info.get('LDLIBRARY')]
    # Prefer the actual target environment, not a different system Python.
    dirs=[env/'lib']
    for key in ('LIBDIR','LIBPL'):
        if info.get(key):
            d=P(info[key])
            if d.is_absolute() and d.resolve().is_relative_to(env.resolve()):
                dirs.append(d)
    seen=set()
    for d in dirs:
        for name in names:
            if not name or P(name).name!=name or not name.endswith('.dylib'):
                continue
            path=d/name
            if path not in seen and path.is_file():
                seen.add(path)
                yield path
        for path in sorted(d.glob(f'libpython{version}.*.dylib')):
            if path not in seen and path.is_file():
                seen.add(path)
                yield path

def find_python_library(py, env, log):
    query=('import json, sys, sysconfig; '
           'print(json.dumps(dict(version=f"{sys.version_info.major}.{sys.version_info.minor}", '
           '**{k: sysconfig.get_config_var(k) for k in ("LDLIBRARY", "INSTSONAME", "LIBDIR", "LIBPL")})))')
    info=json.loads(subprocess.check_output([str(py),'-c',query],text=True))
    print('Python library configuration: '+repr(info),file=log,flush=True)
    for lib in python_library_candidates(env,info):
        print('Checking Python dynamic library: '+str(lib),file=log,flush=True)
        result=subprocess.run([str(py),'-c',
            'import ctypes, sys; lib=ctypes.CDLL(sys.argv[1]); assert lib.Py_BytesMain',str(lib)],
            stdout=log,stderr=subprocess.STDOUT,timeout=15)
        if result.returncode==0:
            print('Selected Python dynamic library: '+str(lib),file=log,flush=True)
            return lib
    raise RuntimeError(f'No loadable Python {info["version"]} .dylib with Py_BytesMain found in {env}/lib. See launcher.log for details. Your existing project has not been changed.')

def setup(status):
    with LOG.open('w',encoding='utf-8') as log:
        def run(args,allow=False):
            print('$ '+repr([str(x) for x in args]),file=log,flush=True)
            r=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
            if r.returncode and not allow: raise RuntimeError(f'{args[0]} exited with code {r.returncode}')
            return r.returncode==0
        status('Checking your existing Python environment…',10)
        raw=subprocess.check_output([CONDA,'env','list','--json'],text=True)
        env=next((P(x) for x in json.loads(raw)['envs'] if P(x).name=='metropolis'),None)
        if env is None:
            status('Creating the reusable Python environment (first launch only)…',20)
            run([CONDA,'create','-y','-n','metropolis','-c','conda-forge','python=3.12','pybullet'])
            raw=subprocess.check_output([CONDA,'env','list','--json'],text=True)
            env=next(P(x) for x in json.loads(raw)['envs'] if P(x).name=='metropolis')
        py=env/'bin/python'
        status('Checking graphics and physics dependencies…',25)
        if not run([py,'-c','import moderngl,glfw,numpy,PIL,trimesh'],True):
            run([py,'-m','pip','install','-r',ROOT/'requirements.txt'])
        if not run([py,'-c','import pybullet'],True):
            run([CONDA,'install','-y','-p',env,'-c','conda-forge','pybullet'])
        status('Checking the native Luau runtime…',45)
        digest=hashlib.sha256((ROOT/'native/host.cpp').read_bytes()+(ROOT/'native/CMakeLists.txt').read_bytes()).hexdigest()[:12]
        build=SUPPORT/'native'/f'{TAG}-{digest}'; host=build/'metropolis-luau'
        def probe():
            try:
                source='local x: number = 2; __emit("probe", tostring(x+3))'
                result=subprocess.run([host],input=source.encode().hex()+'\nQUIT\n',text=True,capture_output=True,timeout=5) if host.is_file() else None
                return bool(result and result.returncode==0 and 'OUT\t70726f6265\t35' in result.stdout)
            except (OSError,subprocess.TimeoutExpired): return False
        if not probe():
            status('Downloading official Luau source (first launch only)…',55)
            if not (env/'bin/cmake').exists() and not shutil.which('cmake'):
                run([CONDA,'install','-y','-p',env,'-c','conda-forge','cmake'])
            cmake=str(env/'bin/cmake') if (env/'bin/cmake').exists() else shutil.which('cmake')
            source=SUPPORT/'native'/f'luau-{TAG}';source.parent.mkdir(parents=True,exist_ok=True)
            if not (source/'CMakeLists.txt').exists():
                temp=source.with_name(source.name+'-download')
                if temp.exists(): shutil.rmtree(temp)
                run(['git','clone','--depth','1','--branch',TAG,'https://github.com/luau-lang/luau.git',temp]);temp.rename(source)
            status('Building the native Luau VM for your Mac…',70)
            if build.exists(): shutil.rmtree(build)
            run([cmake,'-S',ROOT/'native','-B',build,f'-DLUAU_SOURCE={source}','-DCMAKE_BUILD_TYPE=Release'])
            run([cmake,'--build',build,'--target','metropolis-luau','--config','Release','--parallel','4'])
            if not probe(): raise RuntimeError('Native Luau runtime did not pass startup check')
        status('Checking Luau gameplay API…',85)
        sources=[(ROOT/'native/api.luau').read_text(), '__start(function()\n'+(ROOT/'scripts/Main.luau').read_text()+'\nend)', '__tick(0.0166667)', '__module("__probe", function() return 42 end); assert(require("__probe") == 42); assert(terrainType.Tropical == "Tropical"); assert(TerrainSize.Massive == 16384); assert(game:GetService("WorldService").GenerateTerrain ~= nil)']
        result=subprocess.run([host],input=''.join(s.encode().hex()+'\n' for s in sources)+'QUIT\n',text=True,capture_output=True,timeout=8)
        print(result.stdout,result.stderr,file=log,flush=True)
        if result.returncode or 'ERR\t' in result.stdout or result.stdout.count('OUT\t757073657274')!=2 or 'OUT\t6c6f67\t48656c6c6f2c20416674657273686f636b21' not in result.stdout:
            raise RuntimeError('Native Luau gameplay smoke test failed; see launcher.log')
        status('Preparing your persistent Project City workspace…',90)
        for name in ('assets','scripts'):
            for src in (ROOT/name).rglob('*'):
                if src.is_file():
                    dest=PROJECT/src.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True)
                    if not dest.exists(): shutil.copy2(src,dest)
        (PROJECT/'scenes').mkdir(parents=True,exist_ok=True)
        status('Verifying the embedded Python library…',95)
        default_scene=P(os.environ.get('AFTERSHOCK_RESUME_SCENE',PROJECT/'scenes'/'project_city.json'))
        args=[str(ROOT/'studio.py'),'--quality','medium','--fps','60']
        if default_scene.exists(): args.extend(['--scene',str(default_scene)])
        lib=find_python_library(py,env,log)
        return {'python_home':str(env),'python_executable':str(py),'python_library':str(lib),'project':str(PROJECT),'host':str(host),'engine':str(ROOT),'args':args,'support':str(SUPPORT),'update_notice':os.environ.get('AFTERSHOCK_UPDATE_NOTICE','')}

def write_json(path, obj):
    """Atomic receipt; independent temporary file even for concurrent launches."""
    path=P(path)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, prefix=path.name+'.', delete=False) as f:
        tmp=P(f.name)
        try:
            json.dump(obj,f); f.flush(); os.fsync(f.fileno())
        except BaseException:
            tmp.unlink(missing_ok=True); raise
    try: os.replace(tmp,path)
    finally: tmp.unlink(missing_ok=True)

def record(message):
    with LOG.open('a',encoding='utf-8') as f:
        print(message,file=f,flush=True)

def publish_result(path, result):
    # stdout is a separate receipt transport captured by the native host.
    print(json.dumps(result),flush=True)
    try:
        write_json(path,result)
    except Exception:
        record('Result file write failed; stdout receipt available:\n'+traceback.format_exc())
    else:
        record('Startup receipt saved: '+str(path))

LOADING_LINES=("Populating the world…", "Grabbing some coffee…", "Digging a hole in the ground…", "Teaching clouds to float…", "Waking up the pedestrians…", "Polishing the ocean…", "Counting the blades of grass…", "Finding the sun…", "Putting the world together…", "Warming up the engine…", "Untangling the pixels…", "Checking the coffee machine…")

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--result',type=P,required=True);parser.add_argument('--status',type=P,required=True);args=parser.parse_args()
    lines=list(LOADING_LINES);random.shuffle(lines)
    def status(message, progress):
        record(f'Loading {progress}%: {message}')
        if not lines:lines.extend(random.sample(LOADING_LINES,len(LOADING_LINES)))
        try: write_json(args.status,{'message':lines.pop() if progress<100 else 'Your world awaits…','progress':progress})
        except Exception: record('Progress update failed: '+traceback.format_exc())
    try:
        result=setup(status)
        result['ready']=True
        publish_result(args.result,result)
        record('Dependency setup completed successfully.')
        status('Opening Aftershock Studio…',100)
        # The permanent Cocoa host polls every 80 ms. Leave the completed receipt
        # visible long enough for its native progress indicator to repaint.
        import time
        time.sleep(.8)
    except Exception as exc:
        record('Dependency setup exception:\n'+traceback.format_exc())
        publish_result(args.result,{'error':str(exc),'ready':False})
        return 1
    return 0
if __name__=='__main__': sys.exit(main())
