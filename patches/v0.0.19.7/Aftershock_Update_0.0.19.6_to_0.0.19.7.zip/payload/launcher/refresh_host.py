"""Opt-in developer launcher refresh; never invoked automatically by the engine updater."""
from pathlib import Path
import hashlib,os,plistlib,shutil,subprocess,tempfile,sys
from .update_progress import app_bundle,clean_environment
from .update_manager import ROOT,SUPPORT,atomic_json,read_json

def run(args,check=True):
    p=subprocess.run([str(x) for x in args],capture_output=True,text=True,env=clean_environment(),timeout=60)
    if check and p.returncode:raise RuntimeError((p.stderr or p.stdout)[-1800:])
    return p

def refresh(bundle=None,support=SUPPORT,restore=False):
    if sys.platform!='darwin':raise RuntimeError('The native launcher requires macOS')
    bundle=Path(bundle or app_bundle()).resolve()
    if bundle.suffix!='.app':raise ValueError('Select Aftershock Studio.app')
    with (bundle/'Contents/Info.plist').open('rb') as f:info=plistlib.load(f)
    if info.get('CFBundleExecutable')!='AftershockStudio' or info.get('CFBundleIdentifier')!='com.aftershock.studio':raise ValueError('This is not the supported Aftershock developer launcher')
    exe=bundle/'Contents/MacOS/AftershockStudio'
    if not exe.is_file() or exe.is_symlink():raise ValueError('Launcher executable is missing or linked')
    if (bundle/'Contents/_CodeSignature').exists():raise ValueError('The app has a sealed signature; use a separately rebuilt app instead of modifying it')
    signed=run(['/usr/bin/codesign','-dv','--verbose=4',exe],False)
    if signed.returncode==0 and 'Signature=adhoc' not in signed.stderr+signed.stdout:raise ValueError('Refusing to replace a developer-signed launcher')
    key=hashlib.sha256(str(bundle).encode()).hexdigest()[:16];backup=Path(support)/'EngineUpdates'/'launcher-backup'/key;backup.mkdir(parents=True,exist_ok=True)
    original=backup/'AftershockStudio';receipt=backup/'receipt.json'
    if original.exists():
        if not receipt.exists() or read_json(receipt).get('sha256')!=hashlib.sha256(original.read_bytes()).hexdigest():raise ValueError('Launcher backup failed integrity verification')
    elif restore:raise ValueError('No original launcher backup exists')
    with tempfile.TemporaryDirectory(dir=exe.parent,prefix='.aftershock-host-') as tmp:
        target=Path(tmp)/'AftershockStudio'
        if restore:shutil.copy2(original,target)
        else:
            run(['/usr/bin/clang','-fobjc-arc','-O2','-mmacosx-version-min=11.0','-framework','Cocoa',ROOT/'launcher/AftershockHost.m','-o',target])
            run(['/usr/bin/codesign','--force','--sign','-',target]);run(['/usr/bin/codesign','--verify','--strict',target])
            if not original.exists():
                temp=backup/'original.tmp';shutil.copy2(exe,temp);os.replace(temp,original)
                atomic_json(receipt,{'bundle':str(bundle),'sha256':hashlib.sha256(original.read_bytes()).hexdigest()})
        target.chmod(0o755);os.replace(target,exe)
    return original
