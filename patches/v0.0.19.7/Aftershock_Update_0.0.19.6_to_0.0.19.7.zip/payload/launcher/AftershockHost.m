// Native macOS application host. Python is embedded in this process, not launched as Python.app.
#import <Cocoa/Cocoa.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

static NSDictionary *readJSON(NSString *path) {
    NSData *data=[NSData dataWithContentsOfFile:path];
    if (!data) return nil;
    id result=[NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    return [result isKindOfClass:[NSDictionary class]] ? result : nil;
}
static void appendLog(NSString *path, NSString *message) {
    NSFileHandle *f=[NSFileHandle fileHandleForWritingAtPath:path];
    if(f){[f seekToEndOfFile];[f writeData:[[message stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]];[f closeFile];}
    else [[message stringByAppendingString:@"\n"] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}
static NSString *tailFile(NSString *path) {
    NSData *d=[NSData dataWithContentsOfFile:path]; if(!d.length)return @"(empty)";
    if(d.length>2500)d=[d subdataWithRange:NSMakeRange(d.length-2500,2500)];
    return [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] ?: @"(see log file)";
}
static void fail(NSString *message) {
    NSAlert *a=[NSAlert new]; a.alertStyle=NSAlertStyleCritical;
    a.messageText=@"Aftershock Studio could not start"; a.informativeText=message ?: @"Unknown startup error";
    [a addButtonWithTitle:@"OK"]; [a addButtonWithTitle:@"View Logs"];
    if([a runModal]==NSAlertSecondButtonReturn){
        NSString *folder=[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/Metropolis"];
        [[NSWorkspace sharedWorkspace] openURL:[NSURL fileURLWithPath:folder isDirectory:YES]];
    }
}
static NSTextField *label(NSString *s, NSRect frame, CGFloat size, NSColor *color, BOOL bold) {
    NSTextField *v=[NSTextField labelWithString:s]; v.frame=frame;v.alignment=NSTextAlignmentCenter;
    v.font=bold?[NSFont boldSystemFontOfSize:size]:[NSFont systemFontOfSize:size];v.textColor=color;return v;
}
int main(int argc,const char **argv) {
    // Never handle Python helper invocations as a second GUI startup.
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"-c")||!strcmp(argv[i],"-m")||!strcmp(argv[i],"--multiprocessing-fork")){
            fprintf(stderr,"Aftershock is not a Python command-line interpreter. Use the Conda Python executable.\n");return 64;
        }
    }
    @autoreleasepool {
        NSApplication *app=[NSApplication sharedApplication]; [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        NSString *res=NSBundle.mainBundle.resourcePath;
        if (!res) return 1;
        NSImage *icon=[[NSImage alloc] initWithContentsOfFile:[res stringByAppendingPathComponent:@"Aftershock.icns"]];
        if(icon) app.applicationIconImage=icon;
        [app finishLaunching];
        NSWindow *win=[[NSWindow alloc] initWithContentRect:NSMakeRect(0,0,520,315) styleMask:NSWindowStyleMaskTitled backing:NSBackingStoreBuffered defer:NO];
        win.title=@"Aftershock Studio"; win.releasedWhenClosed=NO;win.backgroundColor=[NSColor colorWithSRGBRed:.055 green:.072 blue:.10 alpha:1];win.appearance=[NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
        NSView *view=win.contentView;
        NSImageView *mark=[[NSImageView alloc] initWithFrame:NSMakeRect(205,187,110,110)];mark.image=[[NSImage alloc] initWithContentsOfFile:[res stringByAppendingPathComponent:@"Emblem.png"]];mark.imageScaling=NSImageScaleProportionallyUpOrDown;[view addSubview:mark];
        [view addSubview:label(@"AFTERSHOCK STUDIO",NSMakeRect(25,150,470,28),22,NSColor.whiteColor,YES)];
        [view addSubview:label(@"Your world starts here",NSMakeRect(25,125,470,20),12,NSColor.secondaryLabelColor,NO)];
        NSTextField *status=label(@"Grabbing some coffee…",NSMakeRect(20,81,480,28),13,NSColor.whiteColor,NO);[view addSubview:status];
        NSProgressIndicator *bar=[[NSProgressIndicator alloc] initWithFrame:NSMakeRect(55,60,410,12)];bar.style=NSProgressIndicatorStyleBar;bar.indeterminate=NO;bar.minValue=0;bar.maxValue=100;[view addSubview:bar];
        [view addSubview:label(@"AFTERSHOCK ENGINE",NSMakeRect(20,25,480,20),11,NSColor.secondaryLabelColor,NO)];
        [win center];[win makeKeyAndOrderFront:nil];[app activateIgnoringOtherApps:YES];
        NSString *support=[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/Metropolis"];
        NSString *tmp=[[support stringByAppendingPathComponent:@"startup"] stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
        NSError *err=nil; if(![[NSFileManager defaultManager] createDirectoryAtPath:tmp withIntermediateDirectories:YES attributes:nil error:&err]){fail(err.localizedDescription);return 1;}
        NSString *result=[tmp stringByAppendingPathComponent:@"result.json"], *progress=[tmp stringByAppendingPathComponent:@"status.json"];
        NSTask *task=[NSTask new];task.executableURL=[NSURL fileURLWithPath:@"/bin/bash"];task.arguments=@[[res stringByAppendingPathComponent:@"prepare.sh"],result,progress];
        NSString *out=[tmp stringByAppendingPathComponent:@"stdout.json"], *stderrPath=[tmp stringByAppendingPathComponent:@"stderr.log"];
        NSString *nativeLog=[support stringByAppendingPathComponent:@"startup.log"];
        NSFileManager *fm=NSFileManager.defaultManager;
        if(![fm createFileAtPath:out contents:nil attributes:nil] || ![fm createFileAtPath:stderrPath contents:nil attributes:nil]){fail(@"Could not create startup log files.");return 1;}
        NSFileHandle *outHandle=[NSFileHandle fileHandleForWritingAtPath:out], *errHandle=[NSFileHandle fileHandleForWritingAtPath:stderrPath];
        if(!outHandle || !errHandle){fail(@"Could not open startup log files.");return 1;}
        task.standardOutput=outHandle;task.standardError=errHandle;
        appendLog(nativeLog,[NSString stringWithFormat:@"Starting dependency setup (pid=%d): %@",getpid(),tmp]);
        if(![task launchAndReturnError:&err]){fail(err.localizedDescription);return 1;}
        while(task.running){ @autoreleasepool {
            NSDictionary *state=readJSON(progress);if(state){status.stringValue=state[@"message"] ?: @"Preparing…";bar.doubleValue=[state[@"progress"] doubleValue];}
            NSDate *until=[NSDate dateWithTimeIntervalSinceNow:.08];NSEvent *event=[app nextEventMatchingMask:NSEventMaskAny untilDate:until inMode:NSDefaultRunLoopMode dequeue:YES];if(event)[app sendEvent:event];[app updateWindows];
        }}
        [task waitUntilExit];
        [outHandle closeFile];[errHandle closeFile];
        NSDictionary *info=readJSON(result), *stdoutInfo=readJSON(out);
        if(!info)info=stdoutInfo;
        appendLog(nativeLog,[NSString stringWithFormat:@"Dependency process exit=%d reason=%ld; receipt=%@ stdout=%@",task.terminationStatus,(long)task.terminationReason,readJSON(result)?@"valid":@"missing/invalid",stdoutInfo?@"valid":@"missing/invalid"]);
        if(task.terminationStatus!=0 || ![info[@"ready"] isEqual:@YES] || info[@"error"]){
            NSString *detail=info[@"error"] ?: @"No valid successful setup receipt received.";
            fail([NSString stringWithFormat:@"%@\nExit code: %d\n\nSetup stderr:\n%@\n\nDiagnostics: %@",detail,task.terminationStatus,tailFile(stderrPath),tmp]);return 1;
        }
        appendLog(nativeLog,@"Setup receipt accepted. Initialising embedded Python.");
        status.stringValue=@"Your world awaits…";bar.doubleValue=100;[app updateWindows];
        for(NSString *k in @[@"python_home",@"python_executable",@"python_library",@"project",@"host",@"engine",@"support"]){if(![info[k] isKindOfClass:NSString.class]){fail(@"Invalid setup result.");return 1;}}
        NSString *pythonPath=info[@"python_executable"];
        if(![fm isExecutableFileAtPath:pythonPath]){fail(@"Conda Python executable is missing or not executable.");return 1;}
        setenv("PYTHONHOME",[info[@"python_home"] fileSystemRepresentation],1);
        unsetenv("PYTHONPATH");unsetenv("__PYVENV_LAUNCHER__");
        // CPython on macOS uses this override for its interpreter identity.
        // Child processes needing Python must run Conda Python, not this app host.
        setenv("PYTHONEXECUTABLE",pythonPath.fileSystemRepresentation,1);
        setenv("AFTERSHOCK_PYTHON_EXECUTABLE",pythonPath.fileSystemRepresentation,1);
        setenv("PYTHONFAULTHANDLER","1",1);
        setenv("METROPOLIS_SUPPORT",[info[@"support"] fileSystemRepresentation],1);
        NSString *updateNotice=info[@"update_notice"];if([updateNotice isKindOfClass:NSString.class])setenv("AFTERSHOCK_UPDATE_NOTICE",updateNotice.UTF8String,1);
        setenv("METROPOLIS_PROJECT",[info[@"project"] fileSystemRepresentation],1);setenv("METROPOLIS_LUAU_HOST",[info[@"host"] fileSystemRepresentation],1);setenv("PYTHONUNBUFFERED","1",1);setenv("PYTHONNOUSERSITE","1",1);
        if(chdir([info[@"engine"] fileSystemRepresentation])!=0){fail(@"Cannot access engine folder.");return 1;}
        void *lib=dlopen([info[@"python_library"] fileSystemRepresentation],RTLD_NOW|RTLD_GLOBAL);
        if(!lib){NSString *msg=[NSString stringWithUTF8String:dlerror()];appendLog(nativeLog,msg);fail(msg);return 1;}
        appendLog(nativeLog,@"Python dylib loaded.");
        int (*pythonMain)(int,char **)= (int(*)(int,char **))dlsym(lib,"Py_BytesMain");if(!pythonMain){fail(@"Python entry point not found.");return 1;}
        NSArray *args=info[@"args"];if(![args isKindOfClass:NSArray.class]||args.count<1){fail(@"Missing Studio entry point.");return 1;}
        NSMutableArray *launch=[NSMutableArray arrayWithObjects:pythonPath,@"-u",nil];[launch addObjectsFromArray:args];
        char **pyargv=calloc(launch.count+1,sizeof(char*));if(!pyargv)return 1;for(NSUInteger i=0;i<launch.count;i++)pyargv[i]=strdup([launch[i] UTF8String]);
        // End the splash, not the application. GLFW creates the editor window on this same main thread.
        [win orderOut:nil];[win close];
        NSString *log=[info[@"support"] stringByAppendingPathComponent:@"studio.log"];
        if(freopen(log.fileSystemRepresentation,"w",stdout)) dup2(fileno(stdout),fileno(stderr));
        appendLog(nativeLog,[NSString stringWithFormat:@"Calling Py_BytesMain (pid=%d), interpreter identity: %@",getpid(),pythonPath]);
        int rc=pythonMain((int)launch.count,pyargv);for(NSUInteger i=0;i<launch.count;i++)free(pyargv[i]);free(pyargv);
        appendLog(nativeLog,[NSString stringWithFormat:@"Python returned %d",rc]);
        if(rc)fail([NSString stringWithFormat:@"Studio stopped with exit code %d.\n\nStudio log:\n%@",rc,tailFile(log)]);
        return rc;
    }
}
