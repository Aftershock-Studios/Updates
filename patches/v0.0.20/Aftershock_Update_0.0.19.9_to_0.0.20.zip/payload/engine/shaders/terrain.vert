#version 330 core
in vec3 in_pos,in_normal,in_color,in_weights0,in_weights1;
uniform mat4 u_view_projection;
uniform float u_time;
out vec3 v_pos,v_normal,v_color,v_local;
flat out vec4 v_material;
out vec3 v_weights0,v_weights1;
out vec2 v_asset_uv;
out vec4 v_asset_color;
void main(){v_asset_uv=vec2(0);v_asset_color=vec4(1);v_pos=in_pos;v_local=in_pos;v_normal=in_normal;v_color=in_color;v_material=vec4(.88,0.,0.,-1.);v_weights0=in_weights0;v_weights1=in_weights1;if(in_weights1.z>.99){float fade=smoothstep(0.,.15,in_color.r);v_pos.y+=fade*(.10*sin(in_pos.x*.18+in_pos.z*.11-u_time*.7)+.065*sin(in_pos.z*.25-in_pos.x*.09+u_time*.9));}gl_Position=u_view_projection*vec4(v_pos,1.);}
