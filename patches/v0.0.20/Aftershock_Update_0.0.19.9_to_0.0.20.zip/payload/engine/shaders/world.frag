#version 330 core
in vec3 v_pos,v_normal,v_color,v_local;
flat in vec4 v_material;
in vec3 v_weights0,v_weights1;
in vec2 v_asset_uv;
in vec4 v_asset_color;
uniform int u_imported;
uniform sampler2D u_asset_albedo,u_asset_normal,u_asset_mr;
uniform vec4 u_asset_factor;
uniform vec3 u_asset_props;
uniform int u_asset_has_normal;
uniform sampler2DArray u_surface_maps,u_normal_maps;
uniform float u_time,u_wet,u_cloud,u_puddles,u_rainfall,u_wind;
uniform int u_water_detail;
uniform int u_material_detail;
out vec4 frag;
uniform vec3 u_camera,u_sun,u_sun_color;
uniform float u_day,u_shadow_texel;
uniform vec2 u_fog;
uniform mat4 u_light_matrix;
uniform sampler2D u_shadow;
uniform int u_shadows,u_light_count;
uniform vec4 u_lights[16],u_light_colors[16];
const float PI=3.14159265;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float as_valueNoise2D(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
vec3 skyReflect(vec3 ray){
    float h=max(ray.y,0.);vec3 horizon=mix(vec3(.018,.025,.055),vec3(.40,.57,.75),u_day);
    vec3 sky=mix(horizon,mix(vec3(.006,.012,.04),vec3(.08,.23,.57),u_day),pow(h,.55));
    vec2 p=ray.xz/max(.12,ray.y+.13)*2.5+vec2(u_time*.018,u_time*.008);
    float cloud=as_valueNoise2D(p)*.63+as_valueNoise2D(p*2.1)*.37;
    sky=mix(sky,mix(vec3(.045,.055,.08),vec3(.62,.65,.69),u_day),smoothstep(.76-u_cloud*.48,.91-u_cloud*.42,cloud)*smoothstep(.01,.18,h)*u_cloud);
    return sky+u_sun_color*pow(max(dot(ray,u_sun),0.),180.)*2.2*u_day;
}
float shadow(vec3 n){if(u_shadows==0)return 1.;vec4 p=u_light_matrix*vec4(v_pos+n*u_shadow_texel*.65,1);vec3 q=p.xyz/p.w*.5+.5;if(any(lessThan(q,vec3(0)))||any(greaterThan(q,vec3(1))))return 1.;float bias=max(.00015,.00045*(1.-max(dot(n,u_sun),0.)));vec2 px=1./vec2(textureSize(u_shadow,0));float s=0.;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=q.z-bias<=texture(u_shadow,q.xy+vec2(x,y)*px).r?1.:0.;return mix(1.,s/9.,smoothstep(0.,.12,min(min(q.x,1.-q.x),min(q.y,1.-q.y))));}
vec3 brdf(vec3 n,vec3 v,vec3 l,vec3 base,float r,float m){vec3 h=normalize(v+l);float nl=max(dot(n,l),0.),nv=max(dot(n,v),.001),nh=max(dot(n,h),0.),vh=max(dot(v,h),0.);float a=r*r,a2=a*a;float d=a2/(PI*pow(nh*nh*(a2-1.)+1.,2.)+.00001);float k=pow(r+1.,2.)/8.;float g=nv/(nv*(1.-k)+k)*nl/(nl*(1.-k)+k);vec3 f0=mix(vec3(.04),base,m),f=f0+(1.-f0)*pow(1.-vh,5.);return ((1.-f)*(1.-m)*base/PI+d*g*f/max(4.*nv*nl,.001))*nl;}
// Dominant-axis world projection, independent of imported UVs.
vec2 surfaceUV(vec3 p,vec3 n){vec3 a=abs(n);if(a.y>=a.x&&a.y>=a.z)return p.xz;if(a.x>=a.z)return p.zy;return p.xy;}
vec3 mappedNormal(vec3 n,vec2 uv,vec3 tex){
    vec3 dp1=dFdx(v_pos),dp2=dFdy(v_pos);vec2 du1=dFdx(uv),du2=dFdy(uv);
    vec3 t=cross(dp2,n)*du1.x+cross(n,dp1)*du2.x;
    vec3 b=cross(dp2,n)*du1.y+cross(n,dp1)*du2.y;
    float len2=max(dot(t,t),dot(b,b));if(len2<1e-10)return n;
    return normalize((t*tex.x+b*tex.y)*inversesqrt(len2)*.7+n*max(tex.z,.15));
}
const float tile[11]=float[11](2.4,2.,3.,2.,3.,5.,2.,2.,2.,2.,2.);
void readSurface(int layer,vec2 uv,vec2 dx,vec2 dy,out vec3 c,out float rough,out vec3 bump){
    vec2 pos=uv/tile[layer];if(layer==5)pos+=vec2(.025,.017)*u_time;
    vec4 tex=textureGrad(u_surface_maps,vec3(pos,float(layer)),dx/tile[layer],dy/tile[layer]);
    c=pow(tex.rgb,vec3(2.2));rough=tex.a;
    float dist=length(u_camera-v_pos);float detail=1.-smoothstep(32.,105.,dist);
    bump=vec3(0.,0.,1.);
    if(u_material_detail!=0 && detail>.001)bump=mix(bump,textureGrad(u_normal_maps,vec3(pos,float(layer)),dx/tile[layer],dy/tile[layer]).rgb*2.-1.,detail);
    // Ground materials get a second, differently scaled sample, avoiding obvious grid repeats.
    if(u_material_detail!=0 && (layer==0||layer==1||layer==2||layer==3||layer==6||layer==7) && dist<150.){
        float variation=as_valueNoise2D(uv*.17);float w=smoothstep(.25,.75,variation)*.54*(1.-smoothstep(80.,150.,dist));
        vec2 p2=pos*.617+vec2(17.43,9.71);
        vec4 other=textureGrad(u_surface_maps,vec3(p2,float(layer)),dx/tile[layer]*.617,dy/tile[layer]*.617);
        c=mix(c,pow(other.rgb,vec3(2.2)),w);rough=mix(rough,other.a,w);
        if(detail>.001)bump=mix(bump,textureGrad(u_normal_maps,vec3(p2,float(layer)),dx/tile[layer]*.617,dy/tile[layer]*.617).rgb*2.-1.,w*detail);
    }
}
void main(){vec3 n=normalize(v_normal),v=normalize(u_camera-v_pos),base=pow(max(v_color,vec3(0)),vec3(2.2));float r=v_material.x,m=v_material.y,e=v_material.z;vec3 em=base*e;
vec2 uv=surfaceUV(v_pos,n);vec2 dx=dFdx(uv),dy=dFdy(uv);vec3 originalN=n;
if(u_imported!=0){
    vec4 tex=texture(u_asset_albedo,v_asset_uv);
    if(u_asset_props.z>=0. && tex.a*u_asset_factor.a*v_asset_color.a<u_asset_props.z)discard;
    base=pow(max(tex.rgb,vec3(0)),vec3(2.2))*u_asset_factor.rgb*v_asset_color.rgb*base;
    vec3 mr=texture(u_asset_mr,v_asset_uv).rgb;r=clamp(mr.g*u_asset_props.x,.04,1.);m=clamp(mr.b*u_asset_props.y,0.,1.);em=base*e;
    if(u_material_detail!=0 && u_asset_has_normal!=0)n=mappedNormal(n,v_asset_uv,texture(u_asset_normal,v_asset_uv).rgb*2.-1.);
}else if(v_material.w<0.){
    float weights[6]=float[6](v_weights0.x,v_weights0.y,v_weights0.z,v_weights1.x,v_weights1.y,v_weights1.z);
    int a=0,b=1;if(weights[b]>weights[a]){a=1;b=0;}
    for(int i=2;i<6;i++){if(weights[i]>weights[a]){b=a;a=i;}else if(weights[i]>weights[b])b=i;}
    vec3 ca,cb,na,nb;float ra,rb;
    readSurface(a,uv,dx,dy,ca,ra,na);float blend=weights[b]/max(weights[a]+weights[b],.001);
    if(blend>.005){readSurface(b,uv,dx,dy,cb,rb,nb);ca=mix(ca,cb,blend);ra=mix(ra,rb,blend);na=mix(na,nb,blend);}
    base=ca*clamp(pow(max(v_color,vec3(.001)),vec3(2.2))/max(ca,vec3(.01)),vec3(.65),vec3(1.35))*.15+ca*.85;r=ra;if(u_material_detail!=0)n=mappedNormal(n,uv,na);
    if(a==5){r=.18;}
}else if(v_material.w>=4. && v_material.w<15.){
    int layer=int(v_material.w)-4;vec3 tc,tn;float tr;readSurface(layer,uv,dx,dy,tc,tr,tn);
    base=tc*mix(vec3(1.),base,.18);r=clamp(tr+(r-.8)*.65,.04,1.);if(u_material_detail!=0)n=mappedNormal(n,uv,tn);
}else if(v_material.w==1.||v_material.w==2.){
    int layer=v_material.w==1.?6:7;vec3 tc,tn;float tr;readSurface(layer,uv,dx,dy,tc,tr,tn);
    base*=clamp(tc/(layer==6?.32:.052),vec3(.65),vec3(1.45));if(u_material_detail!=0)n=mappedNormal(n,uv,tn);
}

// Macro variation breaks up repeating outdoor material patterns.
if(v_material.w<0. && v_weights1.z<.8){float macro=as_valueNoise2D(v_pos.xz*.045)*.65+as_valueNoise2D(v_pos.xz*.16)*.35;base*=mix(.74,1.24,macro);}
// Local-space microdetail stays attached to the articulated mesh as it animates.
if(v_material.w==15. || v_material.w==16. || v_material.w==19.){
    vec2 q=surfaceUV(v_local,originalN);float scale=v_material.w==15.?105.:v_material.w==16.?130.:65.;vec2 f=q*scale;
    float fade=1.-smoothstep(.20,1.2,max(length(dFdx(f)),length(dFdy(f))));
    float grain=hash(floor(f));float weave=.5+.5*sin(f.x*6.283)*sin(f.y*6.283);
    float detail=v_material.w==15.?mix(grain,weave,.65):grain;
    if(u_material_detail!=0)base*=1.+(detail-.5)*fade*(v_material.w==15.?.16:.075);
    if(v_material.w==19.)base*=.85+.28*as_valueNoise2D(vec2(q.x*110.,q.y*6.));
}
if(v_material.w==1. && abs(originalN.y)<.5){vec2 uv=vec2(abs(originalN.x)>.5?v_pos.z:v_pos.x,v_pos.y)/vec2(2.5,3.1);vec2 cell=fract(uv);vec2 aa=clamp(fwidth(uv),vec2(.001),vec2(.48));float window=smoothstep(.17-aa.x,.17+aa.x,cell.x)*(1.-smoothstep(.83-aa.x,.83+aa.x,cell.x))*smoothstep(.22-aa.y,.22+aa.y,cell.y)*(1.-smoothstep(.82-aa.y,.82+aa.y,cell.y));float detail=1.-smoothstep(max(0.,.015-aa.x),.015+aa.x,abs(cell.x-.5));window*=1.-detail*.65;window=mix(window,.39,smoothstep(.25,.48,max(aa.x,aa.y)));float on=step(.66,hash(floor(uv)+vec2(floor((abs(originalN.x)>.5?v_pos.x:v_pos.z)*3.))));base=mix(base,vec3(.025,.065,.10),window);m=mix(m,.65,window);r=mix(r,.21,window);em+=vec3(1.,.57,.20)*window*on*(1.-u_day)*2.7;}
if(v_material.w==2.){vec2 texel=v_pos.xz*24.;float grain=hash(floor(texel));float detail=1.-smoothstep(.15,1.,max(fwidth(texel.x),fwidth(texel.y)));base*=1.+(.12*(grain-.5))*detail;}
if(v_material.w==3.)em*=1.-u_day;
float puddle=0.;
if(v_material.w!=3. && v_material.w!=9. && v_material.w!=16. && v_material.w!=18. && v_weights1.z<.8){float wet=u_wet*smoothstep(.1,.85,originalN.y);float basin=as_valueNoise2D(v_pos.xz*.23)*.65+as_valueNoise2D(v_pos.xz*.81)*.25+as_valueNoise2D(v_pos.xz*2.7)*.10;float porous=v_material.w<0.?clamp(v_weights0.x*.85+v_weights0.y*.75+v_weights1.x*.4+v_weights1.y*.65,0.,.9):(v_material.w==4.||v_material.w==5.||v_material.w==7.? .7:0.);float poolable=v_material.w>=15.?0.:1.-porous;puddle=smoothstep(.80-u_puddles*.48,.88-u_puddles*.48,basin)*smoothstep(.90,.99,originalN.y)*smoothstep(.015,.30,u_puddles)*poolable; base*=1.-wet*.22-puddle*.16;r=mix(r,max(.10,r*.42),wet*.8);r=mix(r,.065,puddle*.8);}
vec3 horizon=mix(vec3(.018,.025,.055),vec3(.40,.57,.75),u_day);vec3 reflected=reflect(-v,n);vec3 env=mix(horizon, mix(vec3(.006,.012,.04),vec3(.12,.30,.65),u_day),max(reflected.y,0.));bool water=(v_material.w==9. || (v_material.w<0. && v_weights1.z>.8));
if(u_material_detail!=0 && (v_material.w<0. || (v_material.w>=4. && v_material.w<15.))){float variation=as_valueNoise2D(v_pos.xz*.17+v_pos.y*.11);base*=mix(.86,1.14,variation);r=clamp(r+(variation-.5)*.12,.05,1.);}
if(puddle>.001){vec2 grid=v_pos.xz*3.;vec2 cell=floor(grid);vec2 offset=fract(grid)-vec2(hash(cell),hash(cell+19.));float radius=length(offset);float phase=fract(u_time*1.7+hash(cell+7.));float ring=sin((radius-phase*.8)*46.)*exp(-abs(radius-phase*.8)*15.)*(1.-phase)*u_rainfall;vec3 pn=normalize(vec3(offset.x*ring*.15,1.,offset.y*ring*.15));n=normalize(mix(n,pn,puddle*.75));env=mix(env,skyReflect(reflect(-v,n)),puddle);}
float waveCrest=0.;
if(water){
    vec2 p=v_pos.xz;vec2 slope=vec2(0.);float wave=0.;
    // Multiple directional travelling wave bands, with high frequencies faded in the distance.
    for(int j=0;j<(u_water_detail!=0?6:2);j++){float k=float(j);vec2 dir=normalize(vec2(cos(k*2.13+.3),sin(k*2.13+.3)));float freq=.40*pow(2.35,k);float amp=.17/pow(2.,k);float phase=dot(p,dir)*freq-u_time*sqrt(freq)*(1.35+.65*u_wind);float fade=1.-smoothstep(.12,1.5,max(length(dFdx(p)),length(dFdy(p)))*freq);slope+=dir*cos(phase)*freq*amp*fade*mix(.55,1.28,u_wind);wave+=sin(phase)*amp;}
    vec3 micro=vec3(sin(p.x*9.2+p.y*3.8+u_time*2.2),0.,cos(p.y*8.3-p.x*3.2-u_time*1.8));
    n=normalize(vec3(-slope.x,1.,-slope.y)+micro*.025*(1.-smoothstep(18.,85.,length(u_camera-v_pos))));
    reflected=reflect(-v,n);env=skyReflect(reflected);r=mix(.075,.19,u_rainfall);waveCrest=smoothstep(.22,.32,wave)*(.045+u_rainfall*.14);
}
if(v_material.w==17. || v_material.w==18.)env=skyReflect(reflect(-v,n));
vec3 f0=mix(vec3(.04),base,m);vec3 f=f0+(1.-f0)*pow(1.-max(dot(n,v),0.),5.);vec3 c=base*(.08+.35*u_day)*(.65+.35*n.y)*(1.-m)+env*f*(1.-r*.75)+em;
if(puddle>.001){float pf=.035+.965*pow(1.-max(dot(n,v),0.),5.);c=mix(c,c*.55+skyReflect(reflect(-v,n))*pf*.9,puddle*.8);}
if(water){float fresnel=.025+.975*pow(1.-max(dot(n,v),0.),5.);vec3 deep=mix(vec3(.007,.035,.051),vec3(.014,.10,.13),u_day);float depth=v_material.w<0.?v_color.r:1.;vec3 shallow=vec3(.048,.19,.17)*(.25+.75*u_day);deep=mix(shallow,deep,smoothstep(0.,.50,depth));c=mix(deep,env,fresnel);float shoreBand=1.-smoothstep(.005,.095,depth);float lace=as_valueNoise2D(v_pos.xz*2.1+vec2(u_time*.11,-u_time*.07));float breaker=.5+.5*sin(depth*140.-u_time*2.2+lace*3.);float shore=shoreBand*smoothstep(.42,.77,breaker)*smoothstep(.31,.70,lace);float foam=clamp(waveCrest*as_valueNoise2D(v_pos.xz*3.)+shore*.48,0.,.72);c=mix(c,vec3(.52,.66,.64)*(.25+.75*u_day),foam);float caustic=pow(max(0.,sin(v_pos.x*3.2+sin(v_pos.z*3.4+u_time*.7))*sin(v_pos.z*4.2+sin(v_pos.x*2.7-u_time*.5))),5.);c+=vec3(.025,.09,.065)*caustic*(1.-smoothstep(.02,.23,depth))*(1.-fresnel)*u_day;}
if(v_material.w==17.){float coat=.04+.96*pow(1.-max(dot(n,v),0.),5.);c=c*(1.-coat*.35)+env*coat*.65+brdf(n,v,u_sun,vec3(.92),.12,0.)*u_sun_color*.7*u_day;}
if(v_material.w==18.){float fresnel=.06+.94*pow(1.-max(dot(n,v),0.),5.);c=mix(base*.22,env,clamp(.22+fresnel*.78,0.,1.));}
if(v_material.w==16.){float wrap=clamp((dot(n,u_sun)+.35)/1.35,0.,1.);c+=base*vec3(.24,.10,.055)*(wrap*.35+max(dot(-n,u_sun),0.))*u_day*.65;}
if(v_material.w==20.){float leafLight=abs(dot(n,u_sun));float mottling=as_valueNoise2D(v_pos.xz*1.1+v_pos.y*.71);base*=mix(.76,1.27,mottling);r=mix(.74,.43,u_wet*.65);c+=base*(.35+.7*leafLight)*u_day*shadow(originalN)+vec3(.035,.055,.008)*max(0.,dot(-n,u_sun))*u_day;}
if(v_material.w==19.){vec3 h=normalize(v+u_sun);float sheen=pow(max(0.,1.-abs(dot(h,vec3(0.,1.,0.)))),14.);c+=mix(base,vec3(.35),.25)*sheen*max(0.,dot(n,u_sun))*.26*u_day;}
c+=brdf(n,v,u_sun,base,r,m)*u_sun_color*3.8*u_day*shadow(originalN);
for(int i=0;i<u_light_count;i++){vec3 delta=u_lights[i].xyz-v_pos;float dist=length(delta),range=u_lights[i].w;vec3 l=delta/max(dist,.001);float att=pow(max(1.-dist/range,0.),2.)/(1.+dist*dist*.06);float cone=mix(1.,smoothstep(.35,.82,l.y),u_light_colors[i].a);c+=brdf(n,v,l,base,r,m)*u_light_colors[i].rgb*att*cone;}
float distanceToEye=length(u_camera-v_pos);float fog=smoothstep(u_fog.x,u_fog.y,distanceToEye);vec3 airRay=normalize(v_pos-u_camera);float hazeSun=pow(max(dot(airRay,u_sun),0.),12.);vec3 air=horizon+u_sun_color*hazeSun*.18*u_day;frag=vec4(mix(c,air,fog*.96),1.);}
