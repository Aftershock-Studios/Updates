#version 330 core
in vec2 v_uv;
in float v_alpha;
uniform sampler2D u_asset_albedo;
uniform vec2 u_alpha;
void main(){if(u_alpha.y>=0. && texture(u_asset_albedo,v_uv).a*u_alpha.x*v_alpha<u_alpha.y)discard;}
