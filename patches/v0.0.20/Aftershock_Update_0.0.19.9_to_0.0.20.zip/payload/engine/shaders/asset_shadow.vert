#version 330 core
in vec3 in_pos;
in vec2 in_uv;
in vec4 in_vertex_color;
in vec4 i_col0,i_col1,i_col2,i_col3;
uniform mat4 u_light_matrix;
out vec2 v_uv;
out float v_alpha;
void main(){v_uv=in_uv;v_alpha=in_vertex_color.a;gl_Position=u_light_matrix*mat4(i_col0,i_col1,i_col2,i_col3)*vec4(in_pos,1.);}
