#version 330 core
in vec3 in_pos,in_normal;
in vec4 i_col0,i_col1,i_col2,i_col3,i_material;
in vec3 i_color;
uniform mat4 u_view_projection;
out vec3 v_pos,v_normal,v_color,v_local;
flat out vec4 v_material;
out vec3 v_weights0,v_weights1;
out vec2 v_asset_uv;
out vec4 v_asset_color;
void main(){v_asset_uv=vec2(0);v_asset_color=vec4(1);mat4 m=mat4(i_col0,i_col1,i_col2,i_col3); vec4 p=m*vec4(in_pos,1);v_pos=p.xyz;v_local=in_pos;v_normal=transpose(inverse(mat3(m)))*in_normal;v_color=i_color;v_material=i_material;v_weights0=vec3(0);v_weights1=vec3(0);gl_Position=u_view_projection*p;}
