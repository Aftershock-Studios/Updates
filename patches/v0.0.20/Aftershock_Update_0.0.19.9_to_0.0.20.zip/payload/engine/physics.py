"""Metropolis physics components and Bullet adapter (Y up, metres, seconds).
No Bullet import until a simulation containing physics is started.
"""
from dataclasses import dataclass, replace
import math
import numpy as np
from .ecs import Transform, vec3

@dataclass(frozen=True)
class Body:
    kind: str = 'static'
    shape: str = 'box'
    mass: float = 10.
    friction: float = .6
    restitution: float = .1
    gravity: bool = True
    ccd: bool = False
    velocity: tuple = (0.,0.,0.)
    def __post_init__(self):
        if self.kind not in ('static','dynamic','kinematic') or self.shape not in ('box','sphere','capsule','cylinder','convex','mesh'):
            raise ValueError('Unknown body type or shape')
        if self.kind!='static' and self.shape=='mesh': raise ValueError('Triangle mesh must be static')
        for k in ('mass','friction','restitution'):
            v=float(getattr(self,k)); object.__setattr__(self,k,v)
            if not math.isfinite(v): raise ValueError('Physics values must be finite')
        if self.mass<=0 or not 0<=self.friction<=2 or not 0<=self.restitution<=1: raise ValueError('Invalid mass, friction or restitution')
        object.__setattr__(self,'velocity',vec3(self.velocity))
        if type(self.gravity) is not bool or type(self.ccd) is not bool: raise ValueError('Expected boolean flags')


def world_matrices(scene):
    result={}
    for e in scene.ordered():
        m=scene.transforms[e].matrix(); parent=scene.parents[e]
        result[e]=m if parent is None else result[parent]@m
    return result


def rotation_scale(m):
    scale=np.linalg.norm(m[:3,:3],axis=0); r=m[:3,:3]/scale
    if not np.allclose(r.T@r,np.eye(3),atol=1e-4): raise ValueError('Physics does not support sheared transforms')
    # Matrix -> engine Y-X-Z Euler angles.
    x=math.asin(max(-1,min(1,-float(r[1,2]))))
    if abs(math.cos(x))>1e-6:
        y=math.atan2(r[0,2],r[2,2]); z=math.atan2(r[1,0],r[1,1])
    else:
        y=math.atan2(-r[2,0],r[0,0]); z=0.
    return tuple(map(math.degrees,(x,y,z))),tuple(map(float,scale))


def quat_mul(a,b):
    x,y,z,w=a; X,Y,Z,W=b
    return (w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z)


def quaternion(euler):
    x,y,z=(math.radians(a)/2 for a in euler)
    return quat_mul(quat_mul((0,math.sin(y),0,math.cos(y)),(math.sin(x),0,0,math.cos(x))),(0,0,math.sin(z),math.cos(z)))


def from_quat(q):
    x,y,z,w=q
    r12=2*(y*z-x*w); a=math.asin(max(-1,min(1,-r12)))
    if abs(math.cos(a))>1e-6:
        b=math.atan2(2*(x*z+y*w),1-2*(x*x+y*y)); c=math.atan2(2*(x*y+z*w),1-2*(x*x+z*z))
    else: b=math.atan2(-2*(x*z-y*w),1-2*(y*y+z*z)); c=0.
    return tuple(map(math.degrees,(a,b,c)))


class PhysicsWorld:
    def __init__(self, scene, dt=1/60, backend=None):
        if backend is None:
            try: import pybullet as backend
            except ImportError as exc: raise RuntimeError('Physics needs PyBullet. Install with python -m pip install -r requirements-physics.txt') from exc
        self.p=backend; self.scene=scene; self.dt=dt; self.ids={}; self.reverse={}; self.contacts=set(); self.events=[]; self.player=None; self.closed=False; self.jump_pending=False
        self.terrain_ids={};self.terrain_source=None;self.shape_cache={};self.pose_cache={};self.player_seated=False;self.water_time=0.;self.swimming=False;self.city_proxies={};self.city_shapes={};self.city_probes={}
        self.client=self.p.connect(self.p.DIRECT)
        if self.client<0: raise RuntimeError('Bullet connection failed')
        try:
            self.call('setGravity',0,-9.81,0); self.call('setTimeStep',dt); self.call('setPhysicsEngineParameter',numSolverIterations=20)
            matrices=world_matrices(scene)
            for e,b in scene.bodies.items(): self.add(e,b,matrices[e])
        except Exception:
            self.close(); raise
    def call(self,name,*a,**kw): return getattr(self.p,name)(*a,physicsClientId=self.client,**kw)
    def close(self):
        if not self.closed:
            self.p.disconnect(physicsClientId=self.client); self.closed=True
    def shape(self,b,scale,mesh):
        p=self.p; x,y,z=scale; r=max(x,z)*.5
        if b.shape=='box':
            extents=np.asarray(scale,dtype='f4')*.5
            if mesh is not None and mesh.kind.startswith('asset:'):
                from .assets import load_vertices
                v=load_vertices(mesh.kind)[:,:3];extents=np.maximum(.005,(v.max(axis=0)-v.min(axis=0))*extents)
            return self.call('createCollisionShape',p.GEOM_BOX,halfExtents=extents.tolist())
        if b.shape=='sphere': return self.call('createCollisionShape',p.GEOM_SPHERE,radius=max(scale)/2)
        if b.shape in ('capsule','cylinder'):
            height=max(.001,y-2*r) if b.shape=='capsule' else y
            return self.call('createCollisionShape',p.GEOM_CAPSULE if b.shape=='capsule' else p.GEOM_CYLINDER,radius=r,height=height,collisionFrameOrientation=quaternion((-90,0,0)))
        if mesh is None or mesh.kind=='cube':
            if b.shape=='mesh': raise ValueError('Mesh collider requires imported geometry')
            return self.call('createCollisionShape',p.GEOM_BOX,halfExtents=[x/2,y/2,z/2])
        from .assets import load_vertices
        vertices=(load_vertices(mesh.kind)[:,:3]*scale).tolist()
        if b.shape=='mesh': return self.call('createCollisionShape',p.GEOM_MESH,vertices=vertices,indices=list(range(len(vertices))),flags=p.GEOM_FORCE_CONCAVE_TRIMESH)
        return self.call('createCollisionShape',p.GEOM_MESH,vertices=vertices)
    def add(self,e,b,m=None):
        if e in self.ids: raise ValueError('Body already registered')
        if b.kind!='static' and self.scene.parents[e] is not None: raise ValueError('Dynamic and kinematic bodies must be root entities')
        parent=self.scene.parents[e]
        while parent is not None:
            if parent in self.scene.spins or (parent in self.scene.bodies and self.scene.bodies[parent].kind!='static'):
                raise ValueError('Colliders cannot be children of moving entities; use one collider on the moving root')
            parent=self.scene.parents[parent]
        if e in self.scene.spins and b.kind!='kinematic': raise ValueError('Spinning colliders must be kinematic')
        m=self.scene.transforms[e].matrix() if m is None else m
        rot,scale=rotation_scale(m); mesh=self.scene.meshes.get(e)
        cache_key=(b.shape,scale,mesh.kind if mesh else None)
        shape=self.shape_cache.get(cache_key)
        if shape is None:
            shape=self.shape(b,scale,mesh)
            if shape>=0:self.shape_cache[cache_key]=shape
        if shape<0: raise RuntimeError('Bullet collision shape creation failed')
        i=self.call('createMultiBody',baseMass=b.mass if b.kind=='dynamic' else 0,baseCollisionShapeIndex=shape,basePosition=m[:3,3].tolist(),baseOrientation=quaternion(rot))
        if i<0: raise RuntimeError('Bullet body creation failed')
        self.ids[e]=i; self.reverse[i]=e
        opts=dict(lateralFriction=b.friction,restitution=b.restitution,linearDamping=.04,angularDamping=.04)
        if b.ccd and b.kind=='dynamic': opts.update(ccdSweptSphereRadius=min(scale)*.2,contactProcessingThreshold=0.)
        self.call('changeDynamics',i,-1,**opts)
        if b.kind=='dynamic': self.call('resetBaseVelocity',i,linearVelocity=b.velocity)
        return i
    def remove(self,e):
        i=self.ids.pop(e); self.reverse.pop(i,None); self.pose_cache.pop(e,None); self.call("removeBody",i)
        self.contacts={p for p in self.contacts if e not in p}; self.events=[p for p in self.events if e not in p[1:]]
    def force(self,e,force,point=None):
        i=self.ids[e]; point=self.call('getBasePositionAndOrientation',i)[0] if point is None else vec3(point)
        self.call('applyExternalForce',i,-1,vec3(force),point,self.p.WORLD_FRAME)
    def torque(self,e,torque): self.call('applyExternalTorque',self.ids[e],-1,vec3(torque),self.p.WORLD_FRAME)
    def raycast(self,origin,end):
        hit=self.call('rayTest',vec3(origin),vec3(end))[0]
        if hit[0]<0: return None
        return dict(entity=self.reverse.get(hit[0]),fraction=hit[2],position=tuple(hit[3]),normal=tuple(hit[4]))
    def overlap(self,minimum,maximum):
        return {self.reverse[i] for i,_ in (self.call('getOverlappingObjects',vec3(minimum),vec3(maximum)) or []) if i in self.reverse}
    def fixed_joint(self,a,b,anchor):
        # Anchor in world space, local frame orientation chosen to preserve relative rotation.
        p=self.p; ia,ib=self.ids[a],self.ids[b]; pa,qa=self.call('getBasePositionAndOrientation',ia); pb,qb=self.call('getBasePositionAndOrientation',ib)
        inva=p.invertTransform(pa,qa); invb=p.invertTransform(pb,qb)
        la,ra=p.multiplyTransforms(*inva,vec3(anchor),(0,0,0,1)); lb,rb=p.multiplyTransforms(*invb,vec3(anchor),(0,0,0,1))
        return self.call('createConstraint',ia,-1,ib,-1,p.JOINT_FIXED,[0,0,0],la,lb,parentFrameOrientation=ra,childFrameOrientation=rb)
    def remove_joint(self,joint): self.call('removeConstraint',joint)
    def spawn_player(self,eye):
        if self.player is not None: return
        e=self.scene.create('Player capsule',Transform((eye[0],eye[1]-.65,eye[2]),scale=(.68,1.8,.68)))
        b=Body('dynamic','capsule',75,.0,0.,True,True); self.scene.set_body(e,b); self.add(e,b); self.player=e
    def player_motion(self):
        i=self.ids[self.player]; pos,_=self.call("getBasePositionAndOrientation",i); vel,_=self.call("getBaseVelocity",i)
        grounded=any(c[2]!=i and c[7][1]>.55 and c[8]<.08 for c in self.call("getContactPoints",bodyA=i))
        return pos,vel,grounded
    def move_player(self,direction,jump=False,ascend=False,dive=False):
        if self.player is None: return
        i=self.ids[self.player]; pos,_=self.call('getBasePositionAndOrientation',i); vel,_=self.call('getBaseVelocity',i)
        grounded=False
        for c in self.call('getContactPoints',bodyA=i):
            if c[2]!=i and c[7][1]>.55 and c[8]<.08: grounded=True; break
        self.call('resetBasePositionAndOrientation',i,pos,(0,0,0,1))
        from .water_physics import water_surface,immersion,swim_velocity
        terrain=self.scene.terrain
        surface=water_surface(terrain,pos[0],pos[2],self.water_time) if terrain is not None and pos[1]<terrain.water+1.1 else None
        self.swimming=immersion(surface,pos[1],1.8)>.53
        vy=5.0 if jump and grounded else vel[1]
        movement=swim_velocity(direction,vy,pos[1],surface,ascend,dive) if self.swimming else (float(direction[0]),vy,float(direction[2]))
        self.call('resetBaseVelocity',i,linearVelocity=movement,angularVelocity=(0,0,0))
    def seat_player(self,position,seated):
        if self.player is None:return
        i=self.ids[self.player]
        if seated:self.swimming=False
        if self.player_seated!=seated:
            self.call("setCollisionFilterGroupMask",i,-1,0 if seated else 1,0 if seated else -1);self.player_seated=seated
        self.call("resetBasePositionAndOrientation",i,vec3(position),(0,0,0,1));self.call("resetBaseVelocity",i,linearVelocity=(0,0,0),angularVelocity=(0,0,0))
    def eye(self):
        pos=self.call('getBasePositionAndOrientation',self.ids[self.player])[0]; return np.asarray(pos,dtype='f4')+np.array([0,.65,0],dtype='f4')
    def launch(self,origin,direction):
        d=np.asarray(direction,dtype=float); d=d/max(np.linalg.norm(d),1e-9); pos=np.asarray(origin)+d*1.6
        from .ecs import Mesh
        e=self.scene.create('Thrown crate',Transform(tuple(pos),scale=(.7,)*3),Mesh((.7,.32,.15)))
        b=Body('dynamic','box',4,.5,.25,True,True,tuple(d*18)); self.scene.set_body(e,b); self.add(e,b); return e
    def sync_terrain(self,position):
        from .terrain import wanted,mesh
        terrain=self.scene.terrain
        desired=wanted(terrain,position,1) if terrain else {}
        if terrain is not self.terrain_source:
            for body,shape in self.terrain_ids.values():self.call('removeBody',body)
            self.terrain_ids.clear();self.terrain_source=terrain
        for k in list(self.terrain_ids):
            if k not in desired:
                body,shape=self.terrain_ids.pop(k);self.call('removeBody',body)
                # Bullet may retain collision shape allocation until disconnect.
        for k in desired:
            if k in self.terrain_ids:continue
            vertices=mesh(terrain,k,32,water=False,skirts=False)[:,:3]
            # Compact vertices before passing to the native triangle-mesh collider.
            verts,indices=np.unique(vertices,axis=0,return_inverse=True)
            shape=self.call('createCollisionShape',self.p.GEOM_MESH,vertices=verts.tolist(),indices=indices.reshape(-1).tolist(),flags=self.p.GEOM_FORCE_CONCAVE_TRIMESH)
            if shape<0:raise RuntimeError('Terrain collision shape creation failed')
            body=self.call('createMultiBody',baseMass=0,baseCollisionShapeIndex=shape)
            if body<0:raise RuntimeError('Terrain collision body creation failed')
            self.terrain_ids[k]=(body,shape)

    def city_shape(self,kind):
        if kind not in self.city_shapes:
            if kind=='car':shape=self.call('createCollisionShape',self.p.GEOM_BOX,halfExtents=(.975,.65,2.225))
            else:shape=self.call('createCollisionShape',self.p.GEOM_CAPSULE,radius=.32,height=1.16,collisionFrameOrientation=quaternion((-90,0,0)))
            self.city_shapes[kind]=shape
        return self.city_shapes[kind]
    def sync_city(self,city):
        desired={key:(kind,tuple(pos),heading) for key,kind,pos,heading in city.proxies()} if city else {}
        for key in set(self.city_proxies)-set(desired):self.call('removeBody',self.city_proxies.pop(key)[0])
        for key,pose in desired.items():
            kind,pos,heading=pose;q=quaternion((0,math.degrees(heading),0))
            if key not in self.city_proxies:
                body=self.call('createMultiBody',baseMass=0,baseCollisionShapeIndex=self.city_shape(kind),basePosition=pos,baseOrientation=q)
                # Group 2 hits regular bodies, but city-city collision is handled by SAT.
                self.call('setCollisionFilterGroupMask',body,-1,2,1);self.city_proxies[key]=(body,pose)
            elif self.city_proxies[key][1]!=pose:
                body=self.city_proxies[key][0];self.call('resetBasePositionAndOrientation',body,pos,q);self.city_proxies[key]=(body,pose)
    def city_obstacle(self,kind,position,heading):
        # Reusable non-solving probe against authored and dynamic scenery. Slightly
        # lift the bottom to ignore road surfaces, footpaths and ground contact.
        x,z=position;y=float(self.scene.terrain.height(x,z)) if self.scene.terrain is not None else 0.
        if kind not in self.city_probes:
            half=(.955,.58,2.19) if kind=='car' else (.30,.72,.30)
            shape=self.call('createCollisionShape',self.p.GEOM_BOX,halfExtents=half)
            probe=self.call('createMultiBody',baseMass=0,baseCollisionShapeIndex=shape)
            self.call('setCollisionFilterGroupMask',probe,-1,0,0);self.city_probes[kind]=probe
        probe=self.city_probes[kind];center=(x,y+(.91 if kind=='car' else .99),z)
        self.call('resetBasePositionAndOrientation',probe,center,quaternion((0,math.degrees(heading),0)))
        lo,hi=self.call('getAABB',probe);hits=self.call('getOverlappingObjects',lo,hi) or []
        for body,_ in hits:
            entity=self.reverse.get(body)
            if entity is None or entity==self.player:continue
            if any(c[8]<-.025 for c in self.call('getClosestPoints',probe,body,0.)):return True
        return False

    def step(self):
        from .water_physics import water_surface,immersion,buoyancy,collider_volume
        for e,i in self.ids.items():
            b=self.scene.bodies[e]
            if b.kind=='kinematic':
                t=self.scene.transforms[e]; self.call('resetBasePositionAndOrientation',i,t.position,quaternion(t.rotation))
            elif b.kind=='dynamic' and not b.gravity: self.force(e,(0,b.mass*9.81,0))
            if b.kind=='dynamic' and b.gravity and self.scene.terrain is not None:
                pos,_=self.call('getBasePositionAndOrientation',i)
                if pos[1]-self.scene.transforms[e].scale[1]/2<self.scene.terrain.water+.2:
                    surface=water_surface(self.scene.terrain,pos[0],pos[2],self.water_time)
                    f=immersion(surface,pos[1],self.scene.transforms[e].scale[1])
                    if e==self.player:
                        if self.swimming and not self.player_seated:self.force(e,(0,b.mass*9.81,0))
                    elif f>0:
                        vel,_=self.call('getBaseVelocity',i);self.force(e,buoyancy(b.mass,vel,f,collider_volume(self.scene.transforms[e].scale,b.shape)))
        self.call('stepSimulation')
        self.water_time=(self.water_time+self.dt)%3600
        for e,i in self.ids.items():
            if self.scene.bodies[e].kind=='dynamic':
                pos,q=self.call('getBasePositionAndOrientation',i)
                pose=(tuple(pos),tuple(q))
                if self.pose_cache.get(e)!=pose:
                    t=self.scene.transforms[e]; self.scene.transforms[e]=replace(t,position=tuple(pos),rotation=from_quat(q));self.pose_cache[e]=pose
        current={tuple(sorted((self.reverse[c[1]],self.reverse[c[2]]))) for c in self.call('getContactPoints') if c[1] in self.reverse and c[2] in self.reverse}
        self.events=[('enter',*pair) for pair in sorted(current-self.contacts)]+[('exit',*pair) for pair in sorted(self.contacts-current)]; self.contacts=current
