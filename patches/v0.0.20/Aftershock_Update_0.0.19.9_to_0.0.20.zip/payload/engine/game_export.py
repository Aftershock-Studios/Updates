"""Local macOS game application packaging; copies content, never alters Studio."""
from pathlib import Path
import json, os, plistlib, re, shutil, stat, tempfile, uuid
from . import config, assets, luau

ROOT=Path(__file__).resolve().parents[1]
LAUNCHER=r'''#!/bin/bash
set -u
RES="$(cd "$(dirname "$0")/../Resources" && pwd)" || exit 1
fail() {
  /usr/bin/osascript -e 'on run argv' -e 'display dialog (item 1 of argv) buttons {"OK"} with icon stop with title "Aftershock Game"' -e 'end run' "$1" >/dev/null 2>&1 || true
  exit 1
}
PY=""
PREFERRED="$(cat "$RES/runtime-python.txt")"
for CANDIDATE in "${AFTERSHOCK_GAME_PYTHON:-}" "$HOME/miniforge3/envs/metropolis/bin/python" "$HOME/miniconda3/envs/metropolis/bin/python" "$PREFERRED"; do
  if [[ -n "$CANDIDATE" && -x "$CANDIDATE" ]]; then
    if env -u PYTHONHOME -u PYTHONPATH -u PYTHONEXECUTABLE -u AFTERSHOCK_PYTHON_EXECUTABLE "$CANDIDATE" -c 'import moderngl, glfw, numpy, PIL, trimesh, pybullet' >/dev/null 2>&1; then PY="$CANDIDATE"; break; fi
  fi
done
[[ -n "$PY" ]] || fail 'Aftershock runtime not found. Install the matching Python/Conda environment with the required graphics and physics packages, or set AFTERSHOCK_GAME_PYTHON to its Python executable.'
unset PYTHONHOME PYTHONPATH PYTHONEXECUTABLE AFTERSHOCK_PYTHON_EXECUTABLE AFTERSHOCK_UPDATE_NOTICE AFTERSHOCK_RESUME_SCENE
export PYTHONDONTWRITEBYTECODE=1
export METROPOLIS_PROJECT="$RES/Project"
export METROPOLIS_LUAU_HOST="$RES/Runtime/native/metropolis-luau"
export METROPOLIS_SUPPORT="$HOME/Library/Application Support/AftershockGames/$(cat "$RES/game-id.txt")"
mkdir -p "$METROPOLIS_SUPPORT" || fail 'Could not create the game log directory.'
cd "$RES/Runtime" || exit 1
"$PY" "$RES/Runtime/main.py" --game-config "$RES/game.json" >"$METROPOLIS_SUPPORT/game.log" 2>&1
RESULT=$?
if [[ $RESULT -ne 0 ]]; then fail "Game exited with code $RESULT. See $METROPOLIS_SUPPORT/game.log"; fi
'''

def safe_name(name):
    name=str(name).strip()
    if not name or len(name)>70 or name in ('.','..') or any(c in name for c in '/\\:\x00') or any(ord(c)<32 for c in name):raise ValueError('Use a game name of 1–70 characters without path separators')
    if name.startswith('.') or name.lower().endswith('.app'):raise ValueError('Enter a visible game name without .app')
    return name

def _copy_tree(src,dst):
    if not src.is_dir():return
    for p in src.rglob('*'):
        if p.is_symlink():raise ValueError('Cannot export symbolic link: '+str(p))
        rel=p.relative_to(src)
        if any(x.startswith('.') or x=='__pycache__' for x in rel.parts):continue
        if p.is_file() and p.suffix not in ('.pyc','.pyo'):
            out=dst/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)

def export_game(scene,destination,name,quality='medium',run_scripts=True,host=None,python_executable=None,project=None):
    """Export an isolated game app. Runtime interpreter remains an external prerequisite."""
    name=safe_name(name);destination=Path(destination).expanduser().resolve()
    if not destination.is_dir():raise ValueError('Choose an existing export folder')
    if quality not in ('low','medium','high','ultra'):raise ValueError('Unknown quality preset')
    target=destination/(name+'.app')
    if target.exists() or target.is_symlink():raise FileExistsError('A game with that name already exists. Choose another name or folder.')
    project=Path(project or luau.PROJECT).resolve(); host=Path(host or luau.HOST); gameid=uuid.uuid4().hex
    if run_scripts and (not host.is_file() or not os.access(host,os.X_OK)):
        raise ValueError('Native Luau worker not found. Launch Studio normally before exporting with scripts.')
    snapshot=scene.to_data(); from .ecs import Scene
    exported=Scene.from_data(snapshot)
    # Blank worlds must still have a physical floor for the player.
    if not exported.bodies and exported.terrain is None:
        from .world import solid_city
        solid_city(exported)
        if not exported.bodies:raise ValueError('Add a physical ground or terrain before exporting a playable game.')
    tmp=Path(tempfile.mkdtemp(prefix='.aftershock-export-',dir=destination)); app=tmp/'Game.app'
    try:
        contents=app/'Contents';res=contents/'Resources';runtime=res/'Runtime';data=res/'Project';mac=contents/'MacOS';mac.mkdir(parents=True)
        for folder in ('engine','branding','native','assets/materials','assets/audio','scripts'):_copy_tree(ROOT/folder,runtime/folder)
        for fn in ('main.py','VERSION','requirements.txt','requirements-physics.txt'):shutil.copy2(ROOT/fn,runtime/fn)
        if host.is_file():
            native=runtime/'native'/'metropolis-luau';shutil.copy2(host,native);native.chmod(0o755)
        # Project files only. Runtime never opens the original project folder.
        (data/'scripts').mkdir(parents=True)
        if run_scripts:
            for p in sorted((project/'scripts').glob('*.luau')):
                if p.is_symlink() or not p.is_file():raise ValueError('Invalid script: '+p.name)
                shutil.copy2(p,data/'scripts'/p.name)
        main=data/'scripts'/'Main.luau'
        if not main.exists():main.write_text('-- Game entry point\n',encoding='utf-8')
        modeldir=project/'assets'/'models';_copy_tree(modeldir,data/'assets'/'models');_copy_tree(project/'assets'/'pbr',data/'assets'/'pbr')
        (data/'ASSET_CREDITS.json').write_text(json.dumps(assets.asset_credits(modeldir),ensure_ascii=False,indent=2),encoding='utf-8')
        for mesh in exported.meshes.values():
            if mesh.kind.startswith('asset:'):
                filename=mesh.kind[6:]
                if not (data/'assets'/'models'/filename).is_file():raise ValueError('Missing imported model: '+filename)
        exported.save(data/'scenes'/'game.json')
        settings={'format':'aftershock-game-v1','name':name,'engine':config.VERSION,'quality':quality,'scripts':bool(run_scripts)}
        (res/'game.json').write_text(json.dumps(settings,indent=2),encoding='utf-8');(res/'game-id.txt').write_text(gameid,encoding='utf-8')
        (res/'runtime-python.txt').write_text(str(python_executable or os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE','')),encoding='utf-8')
        shutil.copy2(ROOT/'branding'/'Aftershock.icns',res/'Game.icns')
        executable=mac/'AftershockGame';executable.write_text(LAUNCHER,encoding='utf-8');executable.chmod(0o755)
        plist={'CFBundleName':name,'CFBundleDisplayName':name,'CFBundleIdentifier':'com.aftershock.game.'+gameid,'CFBundleExecutable':'AftershockGame','CFBundleIconFile':'Game.icns','CFBundlePackageType':'APPL','CFBundleShortVersionString':config.VERSION,'CFBundleVersion':'1','NSHighResolutionCapable':True,'LSMinimumSystemVersion':'12.0'}
        with (contents/'Info.plist').open('wb') as f:plistlib.dump(plist,f)
        (res/'README.txt').write_text('Aftershock local game build\nRequires macOS and a compatible Python environment (the Aftershock metropolis environment works).\nNot signed or notarized. Includes scene, scripts, textures, meshes, audio, engine and native Luau worker.\nWASD move, Shift sprint, Control crouch, Space jump, E interact/drive, B camera, Tab mouse, Esc exit.\n',encoding='utf-8')
        if target.exists() or target.is_symlink():raise FileExistsError('Export already exists')
        app.rename(target);return target
    finally:shutil.rmtree(tmp,ignore_errors=True)

def read_game_config(path):
    path=Path(path).resolve(); data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('format')!='aftershock-game-v1' or data.get('quality') not in ('low','medium','high','ultra') or type(data.get('scripts')) is not bool:raise ValueError('Invalid game configuration')
    if data.get('engine')!=config.VERSION:raise ValueError('Game and engine version mismatch')
    return safe_name(data['name']),data['quality'],data['scripts'],path.parent/'Project'/'scenes'/'game.json'
