"""Portable, content-addressed project models. No source-file dependency after import."""
from pathlib import Path
import hashlib
import os
import json
import tempfile
import numpy as np
from PIL import Image

ROOT = Path(os.environ.get('METROPOLIS_PROJECT',Path(__file__).resolve().parent.parent)) / 'assets' / 'models'
MAX_TRIANGLES=500_000
MAX_SOURCE=128*1024*1024
MAX_TEXTURE=1024
MAX_PARTS=64
MAX_TEXTURE_BYTES=96*1024*1024
SOURCES=(('Poly Haven','https://polyhaven.com/models','CC0 scans & models'),('ambientCG','https://ambientcg.com/','CC0 PBR materials'),('Sketchfab','https://sketchfab.com/3d-models','Check the individual licence'),('Quaternius','https://quaternius.com/','Check the pack licence'))


def asset_path(kind):
    name = kind.removeprefix('asset:')
    if not kind.startswith('asset:') or len(name)!=36 or not name.endswith('.npz') or any(c not in '0123456789abcdef' for c in name[:-4]):
        raise ValueError('Invalid asset identifier')
    return ROOT / name


def _vertices(v):
    v=np.ascontiguousarray(v,dtype='f4')
    if v.ndim!=2 or v.shape[1]!=6 or len(v)%3 or not len(v) or len(v)>3*MAX_TRIANGLES or not np.isfinite(v).all() or np.abs(v[:,:3]).max()>.501:
        raise ValueError('Invalid cached mesh')
    return v


def load_vertices(kind):
    if kind.startswith('builtin:'):
        from .vegetation import GEOMETRY
        return GEOMETRY[kind.split(':',1)[1]]()
    with np.load(asset_path(kind),allow_pickle=False) as data:return _vertices(data['vertices'])


def _texture(image,default,channels):
    if image is None:return np.array(default,dtype='u1').reshape(1,1,channels)
    if not isinstance(image,Image.Image):raise ValueError('Unsupported model texture')
    if image.width*image.height>32_000_000:raise ValueError('Texture exceeds 32 megapixels')
    image=image.copy();image.thumbnail((MAX_TEXTURE,MAX_TEXTURE),Image.Resampling.LANCZOS)
    # trimesh uses bottom-origin UVs, PIL has a top-origin row order.
    return np.ascontiguousarray(np.asarray(image.convert('RGBA' if channels==4 else 'RGB'))[::-1],dtype='u1')


def _material(mat):
    from trimesh.visual.material import PBRMaterial
    if isinstance(mat,PBRMaterial):
        factor=getattr(mat,'baseColorFactor',None);factor=np.ones(4,dtype='f4') if factor is None else np.asarray(factor,dtype='f4')/255
        rough=mat.roughnessFactor if mat.roughnessFactor is not None else 1.
        metal=mat.metallicFactor if mat.metallicFactor is not None else 1.
        cut=mat.alphaCutoff if mat.alphaCutoff is not None else .5
        alpha=-1. if mat.alphaMode in (None,'OPAQUE') else float(cut) if mat.alphaMode=='MASK' else .5
        albedo=_texture(mat.baseColorTexture,(255,255,255,255),4)
        normal=_texture(mat.normalTexture,(128,128,255),3)
        mr=_texture(mat.metallicRoughnessTexture,(255,255,255),3)
        flags=(float(mat.normalTexture is not None),float(mat.alphaMode=='BLEND'))
    else:
        factor=np.ones(4,dtype='f4') if mat is None else np.asarray(getattr(mat,'diffuse',[255]*4),dtype='f4')/255
        if factor.shape!=(4,):factor=np.r_[factor[:3],1.]
        # OBJ diffuse factors are typically sRGB. Texture + default grey from a
        # missing MTL would otherwise darken every textured object.
        image=getattr(mat,'image',None)
        if image is not None and np.allclose(factor[:3],.4,atol=.02):factor[:3]=1.
        factor[:3]=factor[:3]**2.2
        albedo=_texture(image,(255,255,255,255),4);normal=_texture(None,(128,128,255),3);mr=_texture(None,(255,255,255),3)
        rough=.8;metal=0.;alpha=.5 if factor[3]<.999 or (albedo[:,:,3]<255).any() else -1.;flags=(0.,0.)
    factors=np.asarray([*factor,np.clip(rough,.04,1),np.clip(metal,0,1),np.clip(alpha,-1,1),*flags],dtype='f4')
    if not np.isfinite(factors).all():raise ValueError('Invalid material factors')
    return factors,albedo,normal,mr


def _safe_scene(p):
    import trimesh
    # Never allow a downloaded model to resolve private files outside its own
    # folder, symlink escapes, or remote URLs. Keep companion buffers/textures together.
    root=p.parent.resolve()
    class Resolver(trimesh.resolvers.FilePathResolver):
        def __init__(self,source):super().__init__(str(source));self.origin=root
        def _path(self,name):
            name=str(name).strip().replace('\\','/')
            if ':' in name or name.startswith('/') or '\x00' in name:raise ValueError('Only local relative asset references are allowed')
            path=(Path(self.parent)/name).resolve()
            if not path.is_relative_to(self.origin):raise ValueError('Asset reference escapes model folder')
            return path
        def get(self,name):
            path=self._path(name)
            if not path.is_file() or path.stat().st_size>MAX_SOURCE:raise ValueError('Missing or oversized model companion: '+Path(str(name)).name)
            return path.read_bytes()
        def namespaced(self,namespace):return Resolver(self._path(namespace))
        def write(self,name,data):raise ValueError('Import resolver is read only')
    with p.open('rb') as f:return trimesh.load(f,file_type=p.suffix[1:].lower(),resolver=Resolver(p),force='scene',process=False)


def import_model(path,source='',licence='',author=''):
    import trimesh
    p=Path(path).expanduser().resolve()
    if p.suffix.lower() not in ('.obj','.gltf','.glb'):raise ValueError('Extract the archive and use OBJ, glTF or GLB (FBX/Blend must be converted)')
    if not p.is_file() or p.stat().st_size>MAX_SOURCE:raise ValueError('Missing model or source exceeds 128 MB')
    model=_safe_scene(p); parts=[]; count=0;total_bytes=0
    for node in model.graph.nodes_geometry:
        matrix,name=model.graph[node];mesh=model.geometry[name].copy();mesh.apply_transform(matrix)
        if not isinstance(mesh,trimesh.Trimesh) or not len(mesh.faces):continue
        count+=len(mesh.faces)
        if count>MAX_TRIANGLES:raise ValueError('Model exceeds 500,000 triangles; decimate it first')
        faces=np.asarray(mesh.faces); tris=np.asarray(mesh.triangles,dtype='f4')
        if not np.isfinite(tris).all():raise ValueError('Invalid model vertices')
        cross=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);good=np.linalg.norm(cross,axis=1)>1e-10
        visual=mesh.visual;uv=getattr(visual,'uv',None);has_uv=uv is not None and np.shape(uv)==(len(mesh.vertices),2) and np.isfinite(uv).all()
        uv=np.asarray(uv,dtype='f4') if has_uv else np.zeros((len(mesh.vertices),2),dtype='f4')
        normal=np.asarray(mesh.vertex_normals,dtype='f4');normal=np.nan_to_num(normal)
        colors=np.ones((len(mesh.vertices),4),dtype='f4');vertex_color=getattr(visual,'vertex_colors',None) if visual.kind=='vertex' else getattr(visual,'vertex_attributes',{}).get('color')
        if vertex_color is not None:
            value=np.asarray(vertex_color,dtype='f4');value=value/255 if value.max()>1. else value
            if value.shape in ((len(colors),3),(len(colors),4)):colors[:,:value.shape[1]]=np.clip(value,0,1)
        mat=getattr(visual,'material',None);materials=getattr(mat,'materials',None);indices=getattr(visual,'face_materials',None)
        selections=[(mat,good)] if materials is None or indices is None else [(m,good & (np.asarray(indices)==i)) for i,m in enumerate(materials)]
        for mat,mask in selections:
            if not mask.any():continue
            if len(parts)>=MAX_PARTS:raise ValueError('Model exceeds 64 material groups')
            factors,albedo,norm,mr=_material(mat)
            if not has_uv:
                albedo=np.array([255]*4,dtype='u1').reshape(1,1,4);norm=np.array([128,128,255],dtype='u1').reshape(1,1,3);mr=np.array([255]*3,dtype='u1').reshape(1,1,3);factors[7]=0.
            total_bytes+=albedo.nbytes+norm.nbytes+mr.nbytes
            if total_bytes>MAX_TEXTURE_BYTES:raise ValueError('Model exceeds 96 MB decoded texture budget; reduce materials or resolution')
            ids=faces[mask];vertex=np.concatenate((tris[mask],normal[ids],uv[ids],colors[ids]),axis=2).reshape(-1,12)
            if not np.isfinite(vertex).all():raise ValueError('Invalid UVs or colours')
            parts.append((vertex,factors,albedo,norm,mr))
    if not parts:raise ValueError('No nondegenerate triangle geometry found')
    lo=np.min([v[:,0:3].min(axis=0) for v,*_ in parts],axis=0);hi=np.max([v[:,0:3].max(axis=0) for v,*_ in parts],axis=0);size=float(max(hi-lo))
    if not 1e-6<size<1e7:raise ValueError('Model extent is invalid')
    payload={};starts=[0];geometry=[]
    for i,(v,f,a,n,m) in enumerate(parts):
        v[:,0:3]=(v[:,0:3]-(lo+hi)*.5)/size;v=np.ascontiguousarray(v,dtype='f4');geometry.append(v[:,:6]);starts.append(starts[-1]+len(v))
        payload.update({f'part_{i}':v,f'factor_{i}':f,f'albedo_{i}':a,f'normal_{i}':n,f'mr_{i}':m})
    payload.update(vertices=np.ascontiguousarray(np.concatenate(geometry),dtype='f4'),offsets=np.asarray(starts,dtype='i8'))
    # Include texture content, UVs, and source name in identity, not just triangles.
    h=hashlib.sha256(p.stem.encode('utf-8'))
    for k,v in payload.items():h.update(k.encode());h.update(str(v.shape).encode());h.update(v.tobytes())
    key=h.hexdigest()[:32];ROOT.mkdir(parents=True,exist_ok=True);target=ROOT/(key+'.npz')
    metadata={'name':p.stem,'size':size,'extents':(hi-lo).tolist(),'triangles':starts[-1]//3,'parts':len(parts),'format':p.suffix[1:].upper(),'source':str(source)[:2048],'licence':str(licence)[:256],'author':str(author)[:256], 'alpha_blend_approximate':any(f[8]>0 for _,f,*_ in parts)}
    if not target.exists():
        with tempfile.NamedTemporaryFile(dir=ROOT,suffix='.npz',delete=False) as f:tmp=Path(f.name)
        try:np.savez_compressed(tmp,**payload);os.replace(tmp,target)
        finally:tmp.unlink(missing_ok=True)
    if not target.with_suffix('.json').exists() or any((source,licence,author)):write_metadata(target,metadata)
    return 'asset:'+target.name,size,p.stem


def load_parts(kind):
    if not kind.startswith('asset:'):return []
    with np.load(asset_path(kind),allow_pickle=False) as data:
        if 'offsets' not in data:return [] # Legacy untextured model caches.
        offsets=data['offsets'];vertices=_vertices(data['vertices'])
        if offsets.ndim!=1 or not 2<=len(offsets)<=MAX_PARTS+1 or offsets[0]!=0 or offsets[-1]!=len(vertices) or np.any(np.diff(offsets)<=0):raise ValueError('Invalid model groups')
        parts=[];total=0
        for i,length in enumerate(np.diff(offsets)):
            v=np.ascontiguousarray(data[f'part_{i}'],dtype='f4');f=np.asarray(data[f'factor_{i}'],dtype='f4');tex=[np.ascontiguousarray(data[f'{k}_{i}'],dtype='u1') for k in ('albedo','normal','mr')]
            if v.shape!=(length,12) or length%3 or not np.isfinite(v).all() or np.abs(v[:,:3]).max()>.501 or f.shape!=(9,) or not np.isfinite(f).all():raise ValueError('Invalid textured model data')
            for a,c in zip(tex,(4,3,3)):
                if a.ndim!=3 or a.shape[2]!=c or not 1<=a.shape[0]<=MAX_TEXTURE or not 1<=a.shape[1]<=MAX_TEXTURE:raise ValueError('Invalid model texture')
                total+=a.nbytes
            if total>MAX_TEXTURE_BYTES:raise ValueError('Cached model texture budget exceeded')
            parts.append((v,f,*tex))
        return parts


def asset_metadata(path):
    try:
        data=json.loads(path.with_suffix('.json').read_text(encoding='utf-8'));name=str(data['name']);size=float(data['size'])
        if not np.isfinite(size) or size<=0:raise ValueError('Invalid size')
        return {**data,'name':name,'size':size}
    except (OSError,ValueError,KeyError,TypeError):return {'name':path.stem[:12],'size':2.}


def write_metadata(path,data):
    path=path.with_suffix('.json');tmp=path.with_suffix('.json.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)


def asset_info(path):
    data=asset_metadata(path);return data['name'],data['size']


def list_assets(query=''):
    query=query.casefold().strip();rows=[]
    for path in ROOT.glob('*.npz'):
        data=asset_metadata(path)
        if query in ' '.join(str(data.get(k,'')) for k in ('name','format','source','licence','author')).casefold():rows.append((path,data))
    return sorted(rows,key=lambda item:(item[1]['name'].casefold(),item[0].name))


def asset_credits(root):
    rows=[]
    for p in sorted(Path(root).glob('*.npz')):
        d=asset_metadata(p);rows.append({k:d.get(k,'') for k in ('name','author','source','licence')})
    return rows
