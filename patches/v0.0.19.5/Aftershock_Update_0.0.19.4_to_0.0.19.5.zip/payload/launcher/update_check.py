"""Native, non-blocking update check UI. Network requests never run on the UI thread."""
import ctypes
import hashlib
import os
from pathlib import Path
from queue import Empty, Queue
import subprocess
import tempfile
import threading

from . import online_updates
from .update_manager import ROOT, SUPPORT, UpdateManager
from .update_progress import clean_environment


def compile_native(root=ROOT):
    source=Path(root)/'launcher/UpdateCheck.m'
    digest=hashlib.sha256(source.read_bytes()).hexdigest()[:16]
    folder=SUPPORT/'EngineUpdates'/'helpers'; folder.mkdir(parents=True,exist_ok=True)
    binary=folder/('check-'+digest+'.dylib')
    if binary.is_file():return binary
    with tempfile.TemporaryDirectory(dir=folder) as tmp:
        output=Path(tmp)/'check.dylib'
        p=subprocess.run(['/usr/bin/clang','-dynamiclib','-fobjc-arc','-O2','-mmacosx-version-min=11.0','-framework','Cocoa',str(source),'-o',str(output)],capture_output=True,text=True,env=clean_environment(),timeout=60)
        if p.returncode:raise RuntimeError('Could not build native update checker: '+p.stderr[-2500:])
        os.replace(output,binary)
    return binary


class NativePanel:
    def __init__(self):
        self.lib=ctypes.CDLL(str(compile_native()))
        signatures={'install_menu':([],ctypes.c_int),'menu_action':([],ctypes.c_int),'panel_action':([],ctypes.c_int),'check_begin':([ctypes.c_char_p,ctypes.c_char_p],None),'check_result':([ctypes.c_int,ctypes.c_char_p,ctypes.c_char_p],None),'check_raise':([],None),'check_close':([],None)}
        for name,(args,result) in signatures.items():
            f=getattr(self.lib,'aftershock_'+name); f.argtypes=args; f.restype=result
            setattr(self,name,f)
    def begin(self,version,repo):self.check_begin(version.encode(),repo.encode())
    def result(self,found,title,message):self.check_result(int(found),title.encode(),message.encode())
    def close(self):self.check_close()
    def raise_panel(self):self.check_raise()


class UpdateCheck:
    """Own the check lifecycle. All panel methods execute on the Studio thread."""
    def __init__(self,panel,editor,version,check=None,repo=None):
        self.panel=panel; self.editor=editor; self.version=version
        self.check=check or online_updates.check
        self.repo=repo or (lambda:online_updates.get_repo(UpdateManager()))
        self.results=Queue(); self.running=False; self.visible=False; self.asset=None; self.menu_installed=False
    def install_menu(self):
        self.menu_installed=bool(self.panel.install_menu()); return self.menu_installed
    def start(self):
        if self.visible:
            self.panel.raise_panel(); return
        if self.editor.update_close:return
        if self.editor.playing:raise ValueError('Stop Play before checking for updates')
        if self.running:
            self.editor.log('A previous update check is still finishing. Please try again shortly.'); return
        repo=self.repo();self.asset=None;self.visible=True;self.running=True
        try:self.panel.begin(self.version,repo)
        except Exception:
            self.visible=False;self.running=False;raise
        def worker():
            try:self.results.put((self.check(repo,self.version),None))
            except Exception as exc:self.results.put((None,str(exc)))
        try:threading.Thread(target=worker,name='AftershockUpdateCheck',daemon=True).start()
        except Exception:
            self.running=False;self.visible=False;self.panel.close();raise
    def poll(self):
        if not self.menu_installed:self.install_menu()
        action=self.panel.menu_action()
        if action==1:self.editor.update_menu()
        elif action==2 and not self.visible and not self.editor.update_close:self.editor.update_options()
        action=self.panel.panel_action()
        if action==2:
            self.visible=False;self.asset=None;self.panel.close()
        elif action==1 and self.visible and self.asset is not None:
            asset=self.asset;self.asset=None;self.visible=False;self.panel.close()
            try:self.editor.request_online_update(asset,confirmed=True)
            except Exception as exc:self.editor.update_error(exc)
        try:asset,error=self.results.get_nowait()
        except Empty:return
        self.running=False
        if not self.visible:return  # Canceled checks cannot trigger a download.
        self.asset=asset
        if error:
            self.panel.result(False,'Could not check for updates',error[:300])
        elif asset is None:
            self.panel.result(False,'No compatible update available',f'Aftershock {self.version}. No newer direct patch was found for this version.')
        else:
            size=asset['size']; amount=f'{size/1048576:.1f} MB' if size>=1048576 else f'{size/1024:.1f} KB'
            self.panel.result(True,f'Aftershock {asset["target"]} is available',f'Current version: {self.version}  •  {amount}\nSource: {asset["repository"]}\nUpdate Now saves your work, downloads the trusted patch and restarts Studio.')
    def close(self):
        self.visible=False;self.asset=None;self.panel.close()
