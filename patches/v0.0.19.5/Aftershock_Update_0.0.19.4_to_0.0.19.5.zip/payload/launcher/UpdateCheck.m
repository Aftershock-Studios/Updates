// Native menu and update-check panel, loaded into the existing Studio host.
#import <Cocoa/Cocoa.h>
#include <stdint.h>

static NSPanel *panel;
static NSProgressIndicator *bar;
static NSTextField *heading, *detail;
static NSButton *now, *later;
static NSInteger menuAction, panelAction;
static NSMenuItem *menuRoot;
static __weak NSWindow *returnWindow;
static void hidePanel(void) { [bar stopAnimation:nil]; [panel orderOut:nil]; if(returnWindow.visible) [returnWindow makeKeyAndOrderFront:nil]; }

@interface AftershockUpdateTarget : NSObject <NSWindowDelegate>
- (void)check:(id)sender;
- (void)options:(id)sender;
- (void)install:(id)sender;
- (void)dismiss:(id)sender;
@end
@implementation AftershockUpdateTarget
- (void)check:(id)sender { menuAction=1; }
- (void)options:(id)sender { menuAction=2; }
- (void)install:(id)sender { if(now.enabled && !now.hidden) { panelAction=1; hidePanel(); } }
- (void)dismiss:(id)sender { panelAction=2; hidePanel(); }
- (BOOL)windowShouldClose:(NSWindow *)sender { [self dismiss:sender]; return NO; }
@end
static AftershockUpdateTarget *target;
static NSString *str(const char *s) { return s ? ([NSString stringWithUTF8String:s] ?: @"") : @""; }
static NSTextField *text(NSString *s, NSRect frame, CGFloat size, BOOL bold) {
    NSTextField *v=[NSTextField wrappingLabelWithString:s]; v.frame=frame;
    v.alignment=NSTextAlignmentCenter; v.font=bold?[NSFont boldSystemFontOfSize:size]:[NSFont systemFontOfSize:size];
    return v;
}
static void buildPanel(void) {
    if(panel) return;
    panel=[[NSPanel alloc] initWithContentRect:NSMakeRect(0,0,500,230) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable backing:NSBackingStoreBuffered defer:NO];
    panel.title=@"Aftershock Software Update"; panel.releasedWhenClosed=NO; panel.delegate=target;
    panel.floatingPanel=YES; panel.hidesOnDeactivate=NO;
    NSView *view=panel.contentView;
    NSImageView *image=[[NSImageView alloc] initWithFrame:NSMakeRect(220,157,60,60)];
    image.image=NSApp.applicationIconImage; image.imageScaling=NSImageScaleProportionallyUpOrDown; [view addSubview:image];
    heading=text(@"Checking for updates…",NSMakeRect(18,123,464,26),19,YES); [view addSubview:heading];
    detail=text(@"",NSMakeRect(24,61,452,57),12,NO); detail.textColor=NSColor.secondaryLabelColor; [view addSubview:detail];
    bar=[[NSProgressIndicator alloc] initWithFrame:NSMakeRect(45,70,410,14)]; bar.style=NSProgressIndicatorStyleBar;
    bar.indeterminate=YES; bar.usesThreadedAnimation=YES; [view addSubview:bar];
    now=[NSButton buttonWithTitle:@"Update Now" target:target action:@selector(install:)]; now.frame=NSMakeRect(346,13,136,32); now.bezelStyle=NSBezelStyleRounded; [view addSubview:now];
    later=[NSButton buttonWithTitle:@"Update Later" target:target action:@selector(dismiss:)]; later.frame=NSMakeRect(196,13,144,32); later.bezelStyle=NSBezelStyleRounded; [view addSubview:later];
}
// Must be called on the main thread, after GLFW has created its menu.
int aftershock_install_menu(void) {
    @autoreleasepool {
        if(!target) target=[AftershockUpdateTarget new];
        NSMenu *main=NSApp.mainMenu; if(!main) return 0;
        if(menuRoot && [main.itemArray containsObject:menuRoot]) return 1;
        menuRoot=[[NSMenuItem alloc] initWithTitle:@"Updates" action:NULL keyEquivalent:@""];
        NSMenu *submenu=[[NSMenu alloc] initWithTitle:@"Updates"]; submenu.autoenablesItems=NO;
        NSMenuItem *check=[[NSMenuItem alloc] initWithTitle:@"Check for Updates…" action:@selector(check:) keyEquivalent:@""]; check.target=target; [submenu addItem:check];
        [submenu addItem:NSMenuItem.separatorItem];
        NSMenuItem *settings=[[NSMenuItem alloc] initWithTitle:@"Update Options…" action:@selector(options:) keyEquivalent:@""]; settings.target=target; [submenu addItem:settings];
        menuRoot.submenu=submenu; [main addItem:menuRoot]; return 1;
    }
}
int aftershock_menu_action(void) { NSInteger a=menuAction; menuAction=0; return (int)a; }
int aftershock_panel_action(void) { NSInteger a=panelAction; panelAction=0; return (int)a; }
void aftershock_check_begin(const char *version, const char *repo) {
    @autoreleasepool {
        if(!target) target=[AftershockUpdateTarget new]; buildPanel(); panelAction=0;
        heading.stringValue=@"Checking for updates…";
        detail.stringValue=[NSString stringWithFormat:@"Aftershock %@  •  %@",str(version),str(repo)]; detail.frame=NSMakeRect(24,90,452,29);
        now.hidden=YES; now.enabled=NO; now.keyEquivalent=@""; later.title=@"Cancel"; later.keyEquivalent=@"\e"; later.frame=NSMakeRect(346,13,136,32);
        bar.hidden=NO; bar.indeterminate=YES; [bar startAnimation:nil];
        returnWindow=NSApp.keyWindow; [panel center]; [panel makeKeyAndOrderFront:nil]; [NSApp activateIgnoringOtherApps:YES];
    }
}
void aftershock_check_result(int found, const char *title, const char *message) {
    @autoreleasepool {
        if(!panel || !panel.visible) return;
        [bar stopAnimation:nil]; bar.hidden=YES;
        heading.stringValue=str(title); detail.stringValue=str(message); detail.frame=NSMakeRect(24,55,452,64);
        now.hidden=!found; now.enabled=found; now.keyEquivalent=found?@"\r":@"";
        later.title=found?@"Update Later":@"OK"; later.frame=found?NSMakeRect(196,13,144,32):NSMakeRect(346,13,136,32); later.keyEquivalent=found?@"\e":@"\r";
        [panel makeKeyAndOrderFront:nil];
    }
}
void aftershock_check_raise(void) { if(panel && panel.visible) [panel makeKeyAndOrderFront:nil]; }
void aftershock_check_close(void) { if(panel && panel.visible) hidePanel(); panelAction=0; }
