#version 330 core
in float v_height,v_tint,v_dist;
in vec3 v_world;
uniform vec3 u_sun,u_sun_color;
uniform float u_day,u_range,u_wet;
uniform mat4 u_light_matrix;
uniform sampler2D u_shadow;
uniform int u_shadows;
out vec4 frag;
void main(){
    if(v_dist>u_range)discard;
    vec3 n=normalize(cross(dFdx(v_world),dFdy(v_world)));if(!gl_FrontFacing)n=-n;
    float diffuse=abs(dot(n,u_sun));float trans=pow(max(0.,dot(-n,u_sun)),1.5);
    float shade=1.;if(u_shadows!=0){vec4 p=u_light_matrix*vec4(v_world+vec3(0,.06,0),1.);vec3 q=p.xyz/p.w*.5+.5;if(all(greaterThan(q,vec3(0)))&&all(lessThan(q,vec3(1))))shade=q.z-.0007<=texture(u_shadow,q.xy).r?1.:.34;}
    float clump=.5+.5*sin(v_world.x*1.4+sin(v_world.z*.83));vec3 base=mix(vec3(.028,.050,.012),mix(vec3(.12,.21,.037),vec3(.22,.27,.065),clump),pow(v_height,.75))*v_tint;
    base*=1.-u_wet*.20;float glint=pow(max(0.,dot(n,normalize(u_sun+vec3(0.,1.,0.)))),18.)*u_wet*.10;
    vec3 light=vec3(.23)+u_sun_color*(.24+.76*diffuse+.42*trans)*u_day*shade;
    frag=vec4((base*light+glint*u_sun_color*u_day)*(.55+.45*smoothstep(0.,.48,v_height)),1.);
}
