import argparse
import math
import os
from pathlib import Path
import sys
import time
import glfw
from . import config
from .camera import Camera
from .world import district, stress, cinematic, playground, solid_city
from .physics import PhysicsWorld
import numpy as np
from .ecs import Scene
from .renderer import Renderer
from .studio import Studio
from .editor import Editor
from .graphics import PRESETS
from .luau import ScriptSession, script_path
from .terrain import PRESETS as TERRAIN_PRESETS
from .character import Character
from .audio import Audio
from .environment import Atmosphere
from .terrain import surface_ids
from .play_lifecycle import shutdown_runtime
from .city import CityRuntime,height as city_height
from .interactions import DoorRuntime

SAVE = Path(os.environ.get('METROPOLIS_PROJECT',Path(__file__).resolve().parent.parent)) / 'scenes' / 'quicksave.json'


def run():
    parser = argparse.ArgumentParser(description=config.TITLE)
    parser.add_argument('--game-config',type=Path,help='Launch an exported game without editor tools')
    parser.add_argument('--terrain',choices=list(TERRAIN_PRESETS),help='Generate a terrain test world')
    parser.add_argument('--scripts',action='store_true',help='Run local Luau scripts in standalone runtime')
    parser.add_argument('--physics',action='store_true',help='Open the physics playground')
    parser.add_argument('--third-person',action='store_true',help='Start third-person character mode')
    parser.add_argument('--walk',action='store_true',help='Start in first-person physics mode (runtime only)')
    parser.add_argument('--bodies',type=int,default=60,help='Number of playground crates (0-1000)')
    parser.add_argument('--editor',action='store_true',help='Launch full Aftershock Studio')
    parser.add_argument('--scene',type=Path,help='Load saved scene at startup')
    parser.add_argument('--quality',choices=[q.name.lower() for q in PRESETS],default='medium')
    parser.add_argument('--district',action='store_true',help='Start in the original district')
    parser.add_argument('--studio',action='store_true',help='Open the developer panel on launch')
    parser.add_argument('--stress',action='store_true',help='Start in the 10,000-building scene')
    parser.add_argument('--fps',type=int,default=config.FPS_LIMIT,help='Frame cap; 0 means uncapped')
    parser.add_argument('--no-vsync',action='store_true')
    args = parser.parse_args()
    game_name=None
    if args.game_config:
        from .game_export import read_game_config
        game_name,args.quality,args.scripts,args.scene=read_game_config(args.game_config)
        args.editor=args.studio=args.walk=False;args.third_person=True;args.fps=60;args.no_vsync=False
    packaged=game_name is not None
    if not 0<=args.bodies<=1000: parser.error('--bodies must be 0-1000')
    if args.editor and (args.walk or args.third_person): parser.error('--walk is for runtime; use G in editor Play mode')
    if args.fps < 0: parser.error('--fps cannot be negative')
    print('[Startup] Initialising GLFW…', flush=True)
    if not glfw.init(): raise RuntimeError('GLFW could not initialise. Run in a local desktop session.')
    print('[Startup] GLFW initialised.', flush=True)
    window = renderer = physics = scripts = None
    audio=Audio(); atmosphere=Atmosphere(); character=None;city=None;doors=None
    script_key=None
    try:
        glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR,3)
        glfw.window_hint(glfw.CONTEXT_VERSION_MINOR,3)
        glfw.window_hint(glfw.OPENGL_PROFILE,glfw.OPENGL_CORE_PROFILE)
        glfw.window_hint(glfw.OPENGL_FORWARD_COMPAT,glfw.TRUE)
        if sys.platform == 'darwin' and hasattr(glfw,'COCOA_RETINA_FRAMEBUFFER'):
            glfw.window_hint(glfw.COCOA_RETINA_FRAMEBUFFER,glfw.TRUE)
        window = glfw.create_window(config.WIDTH,config.HEIGHT,config.TITLE,None,None)
        if not window: raise RuntimeError('Could not create OpenGL 3.3 core context.')
        glfw.make_context_current(window)
        print('[Startup] OpenGL window created.', flush=True)
        if packaged:glfw.set_window_title(window,game_name)
        elif args.editor: glfw.set_window_title(window,"Aftershock Studio "+config.VERSION)
        vsync = config.VSYNC and not args.no_vsync
        glfw.swap_interval(int(vsync))
        cap = args.fps
        camera = Camera()
        scene = Scene.load(args.scene) if args.scene else playground(args.bodies) if args.physics else stress() if args.stress else district() if args.district else cinematic()
        if args.terrain and not args.scene:
            from .terrain import Terrain
            scene=Scene('Terrain World');scene.terrain=Terrain(args.terrain)
        if (args.walk or args.third_person) and not scene.bodies and scene.terrain is None: solid_city(scene)
        walk_requested=args.walk or args.third_person; third_requested=not args.walk or args.third_person; walking=False; physics_key=None; physics_error=None; jump_pending=False; phys_sum=0.; phys_steps=0
        def reset_camera():
            nonlocal camera
            camera = Camera()
            if scene.name == 'Cinematic District':
                camera.position[:] = (3,9,33); camera.yaw,camera.pitch=-90,-8
            if scene.name == 'Physics Playground':
                camera.position[:] = (0,5,22); camera.yaw,camera.pitch=-90,-8
            if scene.terrain is not None:
                camera.position[:]=(0,float(scene.terrain.height(0,0))+160,180);camera.yaw,camera.pitch=-90,-35
            if scene.name in ('Baseplate','Material Showcase','Living District','Tropical Island','Forest Valley'):
                from .templates import template_view
                x,y,z,yaw,pitch=template_view(scene,scene.name) if scene.name not in ('Tropical Island','Forest Valley') or scene.terrain is not None else (12,13,24,-115,-25)
                camera.position[:]=(x,y,z);camera.yaw,camera.pitch=yaw,pitch
            if scene.name == 'Stress City':
                camera.position[:] = (0,850,700)
                camera.yaw,camera.pitch = -90,-50
        reset_camera()
        print(f"[Display] Window {glfw.get_window_size(window)} | framebuffer {glfw.get_framebuffer_size(window)}",flush=True)
        renderer = Renderer()
        g=renderer.graphics; g.index=[q.name.lower() for q in PRESETS].index(args.quality); g.scale=g.quality.scale
        if args.editor and os.environ.get('METROPOLIS_SUPPORT'):
            g.preferences_path=Path(os.environ['METROPOLIS_SUPPORT'])/'graphics.json';g.load_preferences(g.preferences_path)
        studio=Editor() if args.editor else Studio(); studio.visible=args.studio or args.editor; studio.sync(scene)
        if args.editor and args.scene: studio.path=args.scene
        if args.editor and not scene.names and scene.terrain is None:studio.open_template_picker()
        if args.editor and os.environ.get("AFTERSHOCK_UPDATE_NOTICE"):studio.log(os.environ["AFTERSHOCK_UPDATE_NOTICE"])
        update_checker=None
        if args.editor and sys.platform=='darwin' and os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):
            try:
                from launcher.update_check import NativePanel, UpdateCheck
                update_checker=UpdateCheck(NativePanel(),studio,config.VERSION)
                update_checker.install_menu();studio.update_checker=update_checker
            except Exception as exc:
                update_checker=None;studio.log('Native update checker unavailable; using update options: '+str(exc))
        update_checked=False
        ui_image=None; ui_key=None; last_ui=0.; mouse_was=False; stats='Starting'
        def in_code(): return args.editor and studio.script_tab
        def char_input(win,code):
            if in_code():
                if 32<=code<=0x10ffff:
                    studio.code.insert(chr(code)); studio.dirty=True
                return
            if studio.visible and studio.typing and 32<=code<=0x10ffff and len(studio.command)<1024: studio.command+=chr(code); studio.dirty=True
        glfw.set_char_callback(window,char_input)
        if args.editor:
            key_names={getattr(glfw,'KEY_'+k):k for k in ('UP','DOWN','LEFT','RIGHT','HOME','END','PAGE_UP','PAGE_DOWN','BACKSPACE','DELETE','ENTER','TAB','ESCAPE','SPACE','S','A','Z','Y','C','X','V')}
            if hasattr(glfw,'KEY_KP_ENTER'): key_names[glfw.KEY_KP_ENTER]='ENTER'
            def code_key(win,key,scancode,action,mods):
                if not in_code() or action not in (glfw.PRESS,glfw.REPEAT) or key not in key_names: return
                ctrl=bool(mods & (glfw.MOD_SUPER|glfw.MOD_CONTROL)); shift=bool(mods & glfw.MOD_SHIFT)
                clip=None
                if ctrl and key==glfw.KEY_V:
                    clip=glfw.get_clipboard_string(win)
                    if isinstance(clip,bytes):clip=clip.decode('utf-8','replace')
                try: studio.code.key(key_names[key],ctrl,shift,clip,lambda t:glfw.set_clipboard_string(win,t));studio.dirty=True
                except Exception as exc:studio.log(exc)
            def closing(win):
                try:studio.save_scripts()
                except Exception as exc:studio.log('Cannot save scripts: '+str(exc));glfw.set_window_should_close(win,False)
            glfw.set_key_callback(window,code_key)
            glfw.set_window_close_callback(window,closing)
        glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_DISABLED)
        captured, culling, gpu_profile = not (args.studio or args.editor), True, False
        if not captured: glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_NORMAL)
        if args.editor or packaged:
            glfw.set_window_size_limits(window,1000,640,glfw.DONT_CARE,glfw.DONT_CARE)
            def scroll(win,x,y):
                if captured and walking and character is not None: character.distance=max(2.,min(8.,character.distance-y*.45))
                elif args.editor and studio.visible and not captured: studio.scroll(y,*glfw.get_cursor_pos(win))
            glfw.set_scroll_callback(window,scroll)
        mouse_events=[]
        def mouse_button(win,button,action,mods):
            if button==glfw.MOUSE_BUTTON_LEFT and action==glfw.PRESS and studio.visible and not captured:
                mouse_events.append(glfw.get_cursor_pos(win))
        glfw.set_mouse_button_callback(window,mouse_button)
        last_mouse = None
        pressed = set()
        def down(key): return glfw.get_key(window,key) == glfw.PRESS
        def edge(key):
            active = down(key)
            fresh = active and key not in pressed and not in_code()
            if active: pressed.add(key)
            else: pressed.discard(key)
            return fresh
        last = report = time.perf_counter()
        next_gpu = last
        frames = steps = dropped = 0
        cpu_sum = 0.
        accumulator = 0.
        fixed = 1/config.FIXED_HZ
        edit_camera=None
        def begin_play():
            nonlocal edit_camera, accumulator, walk_requested, third_requested
            from .templates import spawn_eye
            if spawn_eye(scene) is not None:walk_requested=True;third_requested=True
            edit_camera=(camera.position.copy(),camera.yaw,camera.pitch,studio.view_mode)
            accumulator=0.
            print('[Play] Starting simulation',flush=True)
        def end_play():
            nonlocal scripts,physics,script_key,physics_key,physics_error,walking,walk_requested,jump_pending,character,captured,last_mouse,accumulator,atmosphere,city,doors
            print('[Stop] Shutting down runtime before scene restoration',flush=True)
            shutdown_runtime((('Luau',scripts),('Audio',audio),('Physics',physics)),studio.log)
            scripts=physics=None;script_key=physics_key=None;physics_error=None
            walking=walk_requested=jump_pending=False;character=None;renderer.character=None;city=None;renderer.city_runtime=None;doors=None
            accumulator=0.;atmosphere=Atmosphere();renderer.atmosphere=atmosphere
            captured=False;last_mouse=None;mouse_events.clear()
            glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_NORMAL)
            if edit_camera is not None:
                camera.position[:],camera.yaw,camera.pitch,studio.view_mode=edit_camera
            studio.character_status='';studio.dirty=True
            print('[Stop] Runtime closed; restoring editor scene',flush=True)
        if args.editor:
            studio.on_play_start=begin_play;studio.on_play_stop=end_play
        print('G walk/fly | H throw crate | J raycast | F1 district | F2 stress | F3 save | F4 load | F5 VSync | F6 culling | F7 FPS cap | F8 GPU timing | F9 reset camera | F10 Studio | F11 day cycle | F12 quality | C cinematic | [ / ] time')
        while not glfw.window_should_close(window):
            start = time.perf_counter()
            glfw.poll_events()
            studio.poll_material_pack()
            if update_checker is not None:
                update_checker.poll()
                if studio.update_close:glfw.set_window_should_close(window,True);break
            raw_dt = start-last
            dt = min(raw_dt,.1)
            last = start
            if edge(glfw.KEY_ESCAPE):
                if args.editor and studio.picker:studio.dismiss_picker();continue
                if studio.typing: studio.typing=False; studio.command=""; studio.dirty=True
                else:
                    if args.editor:
                        try:studio.save_scripts()
                        except Exception as exc:studio.log(exc);continue
                    break
            typing_before=studio.visible and studio.typing
            ctrl=down(glfw.KEY_LEFT_SUPER) or down(glfw.KEY_RIGHT_SUPER) or down(glfw.KEY_LEFT_CONTROL) or down(glfw.KEY_RIGHT_CONTROL)
            enter=edge(glfw.KEY_ENTER); backspace=edge(glfw.KEY_BACKSPACE); paste=edge(glfw.KEY_V); clear=edge(glfw.KEY_A); undo_key=edge(glfw.KEY_Z); save_key=edge(glfw.KEY_S)
            if typing_before:
                if ctrl and paste:
                    clip=glfw.get_clipboard_string(window) or b''
                    if isinstance(clip,bytes): clip=clip.decode('utf-8','replace')
                    studio.command=(studio.command+clip.replace('\n',' ').replace('\r',' '))[:1024]; studio.dirty=True
                if ctrl and clear: studio.command=''; studio.dirty=True
                if enter: studio.execute(g)
                # Keep scene shortcuts from consuming the final command keystroke.
                if backspace: studio.command=studio.command[:-1]; studio.dirty=True
            if edge(glfw.KEY_TAB):
                captured = not captured
                glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_DISABLED if captured else glfw.CURSOR_NORMAL)
                last_mouse = None
                studio.typing=False
            if edge(glfw.KEY_F10) and not args.editor and not packaged:
                studio.visible=not studio.visible; studio.typing=False; studio.dirty=True
                captured=not studio.visible; glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_DISABLED if captured else glfw.CURSOR_NORMAL); last_mouse=None
            if edge(glfw.KEY_F11) and not packaged: g.running=not g.running
            if edge(glfw.KEY_F12) and not packaged: g.cycle()
            if not typing_before and not studio.typing:
                if edge(glfw.KEY_C) and not args.editor and not packaged: scene=cinematic(); reset_camera(); accumulator=0.
                if edge(glfw.KEY_LEFT_BRACKET) and not packaged: g.adjust(-1)
                if edge(glfw.KEY_RIGHT_BRACKET) and not packaged: g.adjust(1)
            if edge(glfw.KEY_F1) and not args.editor and not packaged:
                scene = district(); reset_camera(); accumulator = 0.; print('Loaded test district')
            if edge(glfw.KEY_F2) and not args.editor and not packaged:
                scene = stress(); reset_camera(); accumulator = 0.; print('Loaded 10,000-building stress city')
            if edge(glfw.KEY_F3) and not args.editor and not packaged:
                try:
                    if physics is not None and physics.player is not None: raise ValueError("Use Studio to save the edit scene; runtime player is temporary")
                    scene.save(SAVE); print('Saved:',SAVE)
                except Exception as exc: print('Save failed:',exc)
            if edge(glfw.KEY_F4) and not args.editor and not packaged:
                try:
                    scene = Scene.load(SAVE); reset_camera(); accumulator = 0.; print('Loaded:',SAVE)
                except Exception as exc: print('Load failed; current scene retained:',exc)
            if edge(glfw.KEY_F5) and not packaged:
                vsync = not vsync; glfw.swap_interval(int(vsync)); print('VSync:',vsync)
            if edge(glfw.KEY_F6) and not packaged:
                culling = not culling; print('Frustum culling:',culling)
            if edge(glfw.KEY_F7) and not packaged:
                caps = (0,30,60,120)
                cap = caps[(caps.index(cap)+1)%len(caps)] if cap in caps else 0
                print('FPS cap:',cap or 'Unlimited')
            if edge(glfw.KEY_F8) and not packaged:
                gpu_profile = not gpu_profile; renderer.gpu_ms = None; print('GPU timing:',gpu_profile,'(sampled, can stall)')
            if edge(glfw.KEY_F9) and not packaged: reset_camera()
            studio.sync(scene)
            if args.editor:
                studio.camera=camera; studio.rect=studio.viewport(*glfw.get_window_size(window))
                if not typing_before and not studio.typing:
                    if ctrl and undo_key:
                        if down(glfw.KEY_LEFT_SHIFT) or down(glfw.KEY_RIGHT_SHIFT): studio.redo()
                        else: studio.undo()
                    if ctrl and save_key:
                        try: studio.save()
                        except Exception as exc: studio.log(exc)
            mouse = glfw.get_cursor_pos(window)
            mouse_down=glfw.get_mouse_button(window,glfw.MOUSE_BUTTON_LEFT)==glfw.PRESS
            for click_pos in tuple(mouse_events):
                if studio.visible and not captured:
                    # Rebuild hit targets between queued clicks (e.g. dropdown then Generate).
                    if args.editor and studio.dirty:
                        lw,lh=glfw.get_window_size(window); fw,fh=glfw.get_framebuffer_size(window)
                        ui_image=studio.image(g,stats,lw,lh,camera,pixel_size=(fw,fh))
                    studio.click(*click_pos)
            mouse_events.clear()
            if args.editor and studio.update_close:
                glfw.set_window_should_close(window,True);break
            if args.editor:
                if in_code() and captured:
                    captured=False;glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_NORMAL);last_mouse=None
                studio.motion(*mouse,mouse_down and not captured)
                if in_code() and studio.code.needs_redraw: studio.dirty=True;studio.code.needs_redraw=False
            mouse_was=mouse_down
            active=not args.editor or studio.playing
            wanted_scripts=(scene,active) if active and (args.editor or args.scripts) else None
            if wanted_scripts!=script_key:
                if scripts is not None: shutdown_runtime((('Luau',scripts),),studio.log); scripts=None
                script_key=wanted_scripts
                if wanted_scripts is not None:
                    def script_log(message):
                        print(message,flush=True); studio.log(message)
                    try:
                        script_path(); scripts=ScriptSession(scene,script_log)
                    except Exception as exc:
                        script_log("Luau unavailable: "+str(exc))
                        if packaged:raise
            # A new scene or new play session creates an isolated native world.
            key=(scene,active) if active else None
            if physics_key!=key:
                if physics is not None: shutdown_runtime((('Physics',physics),),studio.log); physics=None
                physics_key=key; physics_error=None; walking=False; jump_pending=False; character=None
                city=CityRuntime(scene) if active and scene.city is not None else None;renderer.city_runtime=city;doors=DoorRuntime(scene) if active and scene.doors else None
                if not active: walk_requested=False
            view_toggle=edge(glfw.KEY_B)
            if not typing_before and not studio.typing and view_toggle and active and walking and not ctrl:
                character.third=not character.third; third_requested=character.third; studio.dirty=True
            if not typing_before and not studio.typing and edge(glfw.KEY_G) and not packaged and active and not (city and city.driver):
                walk_requested=not walking
                if walk_requested and not scene.bodies and scene.terrain is None:
                    if args.editor and scene.name not in ('Cinematic District','Test District'): walk_requested=False; studio.log('Add colliders with solid/body before Play')
                    else: solid_city(scene); physics_error=None
            if active and walk_requested and not scene.bodies and scene.terrain is None and not args.editor: solid_city(scene)
            if active and (scene.bodies or scene.terrain is not None) and physics is None and physics_error is None:
                try: physics=PhysicsWorld(scene); physics.sync_terrain(camera.position); print('Physics started:',len(physics.ids),'bodies')
                except Exception as exc:
                    physics_error=str(exc); print(physics_error); studio.log(physics_error)
                    if packaged:raise
                    if args.editor and studio.playing: studio.play()
                    active=not args.editor or studio.playing
            if physics is not None and walk_requested and not walking:
                try:
                    if physics.player is None:
                        eye=tuple(camera.position)
                        if scene.name=='Physics Playground': eye=(0,1.65,18)
                        elif scene.name=='Cinematic District': eye=(0,1.65,25)
                        elif scene.name=='Test District': eye=(0,1.65,12)
                        if city and city.parked:
                            car=city.parked[0];eye=(car.x+3,city_height(scene,car.x+3,car.z)+1.65,car.z)
                        if scene.terrain is not None:
                            eye=(eye[0],max(float(scene.terrain.height(eye[0],eye[2])),scene.terrain.water)+1.7,eye[2])
                            physics.sync_terrain(eye)
                        from .templates import spawn_eye
                        marker=spawn_eye(scene)
                        if marker is not None:
                            eye=marker;physics.sync_terrain(eye)
                        elif packaged and scene.terrain is None and not (city and city.parked) and scene.name not in ('Physics Playground','Cinematic District','Test District'):
                            eye=(0,1.7,0)
                        physics.spawn_player(eye)
                    walking=True; character=Character();character.animator.clips.update(scene.clips);character.third=third_requested;character.position=np.asarray(physics.player_motion()[0]); camera.position[:]=physics.eye()
                    if args.editor:
                        studio.view_mode='Perspective'; studio.scene_tab(); studio.dirty=True
                        captured=True; glfw.set_input_mode(window,glfw.CURSOR,glfw.CURSOR_DISABLED); last_mouse=None
                except Exception as exc:
                    print('Player spawn failed:',exc); walk_requested=False
                    if packaged:raise
            if walking and physics and captured and edge(glfw.KEY_E):
                if city and city.driver:
                    position=city.exit_position(physics.city_obstacle)
                    if position is not None:
                        city.exit();physics.seat_player(position,False);character.velocity[:]=0
                    else:studio.log("Exit blocked: move the vehicle to a clear area")
                elif city and city.enter(physics.eye()):
                    jump_pending=False;car=city.driver;physics.seat_player((car.x,city_height(scene,car.x,car.z)+1,car.z),True);camera.yaw=90-math.degrees(car.heading);camera.pitch=-12
                elif doors and doors.toggle_near(physics.eye()):studio.log('Door toggled')
                else:studio.log('Move near a door or the parked blue car')
            if walking and not walk_requested:
                walking=False
                # Retain the capsule at its last position for toggling back.
            if active: g.step(dt)
            atmosphere.step(scene.environment,dt,g.sun()[2]); renderer.atmosphere=atmosphere
            footstep=None
            if edge(glfw.KEY_SPACE) and walking and captured: jump_pending=True
            if physics is not None and captured and not studio.typing and edge(glfw.KEY_H) and not packaged:
                if len(physics.ids)<2500:
                    try: physics.launch(camera.position,camera.forward)
                    except Exception as exc: print("Launch failed:",exc)
            if physics is not None and captured and not studio.typing and edge(glfw.KEY_J) and not packaged:
                hit=physics.raycast(camera.position+camera.forward*.8,camera.position+camera.forward*100)
                print('Raycast:',hit)
            if not glfw.get_window_attrib(window,glfw.FOCUSED): last_mouse = None
            elif captured:
                if last_mouse is not None: camera.look(mouse[0]-last_mouse[0],mouse[1]-last_mouse[1])
                last_mouse = mouse
                if not walking: camera.move(int(down(glfw.KEY_W))-int(down(glfw.KEY_S)),int(down(glfw.KEY_D))-int(down(glfw.KEY_A)),int(down(glfw.KEY_SPACE))-int(down(glfw.KEY_LEFT_CONTROL)),dt*(5 if scene.terrain is not None and down(glfw.KEY_LEFT_SHIFT) else 1),down(glfw.KEY_LEFT_SHIFT))
            accumulator += dt
            n = 0
            while accumulator >= fixed and n < config.MAX_STEPS:
                if not args.editor or studio.playing:
                    if scripts is not None:
                        try: scripts.step(fixed,physics)
                        except Exception as exc:
                            shutdown_runtime((('Luau',scripts),),studio.log);scripts=None;script_log("Luau stopped: "+str(exc))
                    scene.step(fixed)
                    if doors:doors.step(fixed)
                    if physics is not None:
                        physics.water_time=atmosphere.time%3600
                        pt=time.perf_counter()
                        if scene.terrain is not None or physics.terrain_ids: physics.sync_terrain(physics.eye() if walking else camera.position)
                        if city and city.driver:
                            car=city.driver;physics.seat_player((car.x,city_height(scene,car.x,car.z)+1,car.z),True)
                            jump_pending=False
                        elif walking:
                            direction=np.zeros(3)
                            if captured and glfw.get_window_attrib(window,glfw.FOCUSED):
                                f=camera.forward.copy(); f[1]=0; f/=max(float(np.linalg.norm(f)),1e-8)
                                direction=f*(int(down(glfw.KEY_W))-int(down(glfw.KEY_S)))+camera.right*(int(down(glfw.KEY_D))-int(down(glfw.KEY_A)))
                                direction=direction/max(float(np.linalg.norm(direction)),1.)
                            direction=character.movement(direction,captured and down(glfw.KEY_LEFT_SHIFT),captured and down(glfw.KEY_LEFT_CONTROL),fixed)
                            physics.move_player(direction,jump_pending,captured and down(glfw.KEY_SPACE),captured and down(glfw.KEY_LEFT_CONTROL)); jump_pending=False
                        elif physics.player is not None: physics.move_player((0,0,0))
                        physics.sync_city(city);physics.step(); phys_sum+=time.perf_counter()-pt; phys_steps+=1
                        if walking and not (city and city.driver):
                            pos,vel,grounded=physics.player_motion(); character.preview=studio.animation_preview if args.editor else None;character.animate(pos,vel,grounded,fixed);
                            if physics.swimming:character.state="Swimming";character.footstep=False
                            if character.footstep:
                                footstep="hard"
                                if scene.terrain is not None:
                                    x,z=pos[0],pos[2]; y=scene.terrain.height(x,z); mat=int(surface_ids(scene.terrain,np.array([x]),np.array([z]),np.array([y]),np.array([1.]))[0]);footstep={0:"grass",1:"sand",3:"sand"}.get(mat,"hard")
                    if scene.city is not None and (city is None or (not city.driver and city.settings!=scene.city)):
                        city=CityRuntime(scene);renderer.city_runtime=city
                    if city:
                        focused=captured and glfw.get_window_attrib(window,glfw.FOCUSED)
                        player=physics.player_motion()[0] if physics and physics.player is not None and not physics.player_seated else None
                        if player is not None and player[1]>city_height(scene,player[0],player[2])+2.2:player=None
                        city.step(fixed,camera.position,(int(down(glfw.KEY_W))-int(down(glfw.KEY_S))) if focused else 0,(int(down(glfw.KEY_D))-int(down(glfw.KEY_A))) if focused else 0,not focused or down(glfw.KEY_SPACE),atmosphere.rain,player=player,solid=physics.city_obstacle if physics else None)
                        if physics:physics.sync_city(city)

                accumulator -= fixed; n += 1
            if walking and character is not None and physics is not None:
                if city and city.driver:
                    car=city.driver;anchor=np.array([car.x,city_height(scene,car.x,car.z)+2,car.z]);offset=-camera.forward*7+np.array([0,1.2,0]);hit=physics.raycast(anchor,anchor+offset)
                    if hit:offset*=max(.05,hit['fraction']-.08)
                    camera.position[:]=anchor+offset
                else:camera.position[:]=character.camera_position(physics.eye(),camera.forward,physics.raycast,physics.player)
            renderer.character=character if walking and character and character.third and not (city and city.driver) else None
            if args.editor:
                # Fixed-step scripts can create/destroy entities after the early sync.
                studio.sync(scene)
                status=(f"Driving | {abs(city.driver.speed)*3.6:.0f} km/h | Gear {city.driver.gear} | E exit" if city and city.driver else character.state if walking and character else "")
                if status!=studio.character_status:studio.character_status=status;studio.dirty=True
            audio.update(scene.environment,atmosphere,active,dt,footstep)
            audio.vehicle(city.driver if city else None,scene.environment.volume if active and scene.environment.audio else 0,dt)
            if active and scene.environment.audio:
                for name,volume in scene.audio_events:audio.effect(name,volume*scene.environment.volume)
            scene.audio_events.clear()
            if active and scene.environment.audio:
                audio.emitters(scene.emitters,camera.position,scene.environment.volume,dt)
                for e in scene.spatial_events:audio.positional(e['sound'],e['volume']*scene.environment.volume,e['position'],camera.position,e['radius'])
            scene.spatial_events.clear()
            if city and city.driver and captured and edge(glfw.KEY_K) and scene.environment.audio:audio.effect('horn',scene.environment.volume*.6)
            steps += n
            if accumulator >= fixed:
                skipped = int(accumulator/fixed); dropped += skipped; accumulator -= skipped*fixed
            if raw_dt > dt: dropped += int((raw_dt-dt)/fixed)
            w,h = glfw.get_framebuffer_size(window)
            if w <= 0 or h <= 0:
                glfw.wait_events_timeout(.05)
                last = report = time.perf_counter(); frames = steps = dropped = 0; cpu_sum = 0.; accumulator = 0.
                continue
            sample = gpu_profile and start >= next_gpu
            if sample: next_gpu = start+1.
            if args.editor:
                lw,lh=glfw.get_window_size(window); l,t,vw,vh=studio.rect
                sx,sy=w/max(1,lw),h/max(1,lh); vx,vy=round(l*sx),round((lh-t-vh)*sy); pw,ph=max(1,round((l+vw)*sx)-vx),max(1,round((lh-t)*sy)-vy)
                renderer.ctx.screen.use(); renderer.ctx.viewport=(0,0,w,h); renderer.ctx.screen.clear(.08,.1,.13,1)
                if not in_code(): renderer.draw(scene,camera,pw,ph,culling,sample,viewport=(vx,vy,pw,ph),projection=studio.projection(vw,vh))
            else: renderer.draw(scene,camera,w,h,culling,sample)
            if studio.visible:
                lw,lh=glfw.get_window_size(window)
                key_ui=(lw,lh,w,h)
                if ui_image is None or studio.dirty or start-last_ui>.25 or ui_key!=key_ui:
                    if args.editor: ui_image=studio.image(g,stats,lw,lh,camera,pixel_size=(w,h))
                    else: ui_image=studio.image(g,stats,pixel_size=(max(1,round(350*w/max(1,lw))),max(1,round(610*h/max(1,lh)))))
                    last_ui=start; ui_key=key_ui
                renderer.overlay(ui_image,w,h,lw,lh,logical_size=(lw,lh) if args.editor else (350,610))
            cpu_sum += time.perf_counter()-start
            glfw.swap_buffers(window)
            if args.editor and not update_checked:
                update_checked=True
                if os.environ.get("AFTERSHOCK_PYTHON_EXECUTABLE"):
                    from launcher.update_manager import UpdateManager, ROOT as engine_root
                    manager=UpdateManager()
                    if manager.confirm(engine_root,os.getpid()):studio.log("Engine update confirmed: "+config.VERSION)
                    try:
                        count=manager.prune(engine_root)
                        if count:studio.log(f"Removed {count} obsolete engine releases.")
                    except OSError as exc:studio.log("Update cleanup deferred: "+str(exc))
            frames += 1
            if cap:
                remaining = 1/cap-(time.perf_counter()-start)
                if remaining > 0: time.sleep(remaining)
            end = time.perf_counter()
            elapsed = end-report
            if elapsed >= .5:
                fps = frames/elapsed
                if cap==0 or cap>=g.target_fps: g.feedback(fps)
                stats=f'{fps:.0f} FPS | {cpu_sum*1000/frames:.1f}ms CPU | {renderer.visible:,} meshes'
                if city:stats+=f" | {len(city.cars)} cars / {len(city.people)} NPCs"
                if physics:stats+=f" | Physics {phys_sum*1000/max(1,phys_steps):.1f}ms"
                if args.editor:
                    if sys.platform != "win32":
                        import resource
                        peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024)
                        stats+=f' | {w}×{h} display'
                    if scene.terrain is not None: stats+=f" | {len(renderer.terrain_gpu)} chunks | {renderer.grass_count:,} grass"
                    if gpu_profile and renderer.gpu_ms is not None: stats+=f' | GPU {renderer.gpu_ms:.2f}ms'
                gpu = ('off' if not gpu_profile else ('n/a' if renderer.gpu_ms is None else f'{renderer.gpu_ms:.2f}ms'))
                title = f'{"Aftershock Studio v"+config.VERSION if args.editor else config.TITLE} | {fps:.0f} FPS | CPU {cpu_sum*1000/frames:.2f}ms | GPU {gpu} | {renderer.visible:,}/{renderer.total:,} meshes | {renderer.triangles:,} tris | {renderer.draw_calls} draws | {steps/elapsed:.0f}Hz | {w}x{h} | {g.quality.name} {g.scale:.0%} | VSync {vsync} | cap {cap or "off"}'
                if physics is not None: title+=f' | Physics {len(physics.ids)} bodies {phys_sum*1000/max(1,phys_steps):.2f}ms/tick'
                phys_sum=0.; phys_steps=0
                glfw.set_window_title(window, game_name if packaged else "Aftershock Studio | "+scene.name if args.editor else title)
                if scene.name == 'Stress City' or gpu_profile:
                    print(title+f' | skipped ticks {dropped} | cull {culling} | vsync {vsync} | cap {cap or "off"}',flush=True)
                report,frames,steps,dropped,cpu_sum = end,0,0,0,0.
    finally:
        if 'update_checker' in locals() and update_checker is not None:update_checker.close()
        shutdown_runtime((('Luau',scripts),('Audio',audio),('Physics',physics),('Renderer',renderer)),lambda msg:None)
        if window is not None: glfw.destroy_window(window)
        glfw.terminate()
