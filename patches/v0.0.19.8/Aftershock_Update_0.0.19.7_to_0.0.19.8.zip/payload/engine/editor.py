"""Aftershock Studio: scene editing, viewport tools and non-destructive play preview."""
from dataclasses import replace
from pathlib import Path
import math, shlex, sys, subprocess, os, uuid, threading, queue
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from .ecs import Scene, Transform, Mesh
from .camera import perspective
from .assets import ROOT, import_model, asset_info
from . import config
from .code_editor import CodeEditor
from . import theme
from .hidpi import canvas
from .terrain import Terrain, PRESETS as TERRAIN_PRESETS, MATERIALS
from .materials import PATTERNS, SPECS

SCENES=ROOT.parent.parent/'scenes'

def world_matrices(scene):
    out={}
    for eid in scene.ordered():
        t=scene.transforms[eid].matrix(); p=scene.parents[eid]
        out[eid]=t if p is None else out[p]@t
    return out

def pick(scene, origin, direction):
    """Ray against transformed unit bounds; nearest positive hit, not triangle exact."""
    best=None; distance=float('inf')
    for eid,m in world_matrices(scene).items():
        if eid not in scene.meshes: continue
        inv=np.linalg.inv(m); o=(inv@np.r_[origin,1])[:3]; d=(inv@np.r_[direction,0])[:3]
        lo,hi=-float('inf'),float('inf')
        for axis in range(3):
            if abs(d[axis])<1e-8:
                if abs(o[axis])>.5: lo,hi=1,0; break
            else:
                a,b=sorted(((-.5-o[axis])/d[axis],(.5-o[axis])/d[axis])); lo=max(lo,a); hi=min(hi,b)
        if hi>=max(lo,0):
            hit=lo if lo>=0 else hi
            if hit<distance: best,distance=eid,hit
    return best

class Editor:
    def __init__(self):
        self.visible=True; self.dirty=True; self.typing=False; self.command=''; self.scene=None; self.selected=None
        self.history=[]; self.future=[]; self.playing=False; self.saved_edit=None; self.index=0; self.offset=0; self.asset_offset=0
        self.debug_colliders=False; self.output=[]; self.search=''; self.code=None; self.script_tab=False; self.buttons=[]; self.message='Ready | Character & environment update'; self.mode='move'; self.view_mode='Perspective'; self.ortho_size=70.; self.drag=None; self.gizmo=[]; self.path=SCENES/'project_city.json'; self.ids=[]; self.depth={}; self.revision=-1
        self.terrain_tab=False; self.surface_dropdown=False; self.terrain_dropdown=False; self.terrain_preset="Tropical"; self.terrain_seed=42; self.terrain_size=4096; self.terrain_water=0.; self.terrain_decorations=False; self.brush_mode="Raise"; self.brush_radius=48; self.brush_strength=12; self.brush_material="Grass"; self.brush_hit=None
        self.font=theme.font(13); self.small=theme.font(12); self.large=theme.font(17,True); self.pointer=(-1,-1); self.output_expanded=False; self.update_close=False; self.update_checker=None; self.character_status=""; self.on_play_start=None; self.on_play_stop=None;self.animation_preview=None;self.world_tools=False;self.asset_search="";self.road_points=None;self.picker=None;self.camera=None;self.pack_thread=None;self.pack_messages=queue.Queue()
    def log(self,s):
        self.message=str(s); self.output.append(self.message); self.output=self.output[-80:]; self.dirty=True
    def script_editor(self):
        from .luau import script_path
        if self.code is None:
            path=script_path(); self.code=CodeEditor(path.parent); self.code.open(path)
        self.script_tab=True; self.terrain_tab=False; self.typing=False; self.drag=None; self.dirty=True
    def scene_tab(self):
        self.script_tab=False; self.terrain_tab=False; self.typing=False; self.dirty=True
    def open_terrain(self):
        self.script_tab=False;self.terrain_tab=True;self.terrain_dropdown=False;self.typing=False;self.drag=None;self.dirty=True
        if self.scene.terrain:
            t=self.scene.terrain;self.terrain_preset=t.preset;self.terrain_seed=t.seed;self.terrain_size=t.size;self.terrain_water=t.water;self.terrain_decorations=t.decorations
    def set_preset(self,preset):
        self.terrain_preset=preset;self.terrain_dropdown=False;self.dirty=True
    def generate_terrain(self):
        self.terrain_dropdown=False
        t=Terrain(self.terrain_preset,self.terrain_seed,self.terrain_size,self.terrain_water,decorations=self.terrain_decorations)
        def op():self.scene.terrain=t;self.scene.revision+=1
        self.change(op)
        if self.camera is not None:
            self.camera.position[:]=(0,float(t.height(0,0))+150,180);self.camera.yaw,self.camera.pitch=-90,-35;self.view_mode='Perspective'
        self.log('Generated '+t.preset+' terrain; existing entities retained')
    def toggle_decorations(self):
        if self.playing:raise ValueError('Stop play mode before editing')
        t=self.scene.terrain
        self.terrain_decorations=not (t.decorations if t else self.terrain_decorations)
        if t:
            def op():self.scene.terrain=replace(t,decorations=self.terrain_decorations);self.scene.revision+=1
            self.change(op)
        self.log('Decorations '+('enabled' if self.terrain_decorations else 'disabled'))
    def terrain_stamp(self,x,y):
        if self.playing or self.scene.terrain is None:return
        hit=self.scene.terrain.ray(*self.ray(x,y))
        if hit is None:return
        new=self.scene.terrain.brush(float(hit[0]),float(hit[2]),self.brush_radius,self.brush_strength,self.brush_mode,self.brush_material)
        def op():self.scene.terrain=new;self.scene.revision+=1
        self.change(op);self.log(self.brush_mode+' terrain (click to stamp; Undo supported)')
    def terrain_remove(self):
        def op():self.scene.terrain=None;self.scene.revision+=1
        self.change(op);self.log('Terrain removed; Undo available')
    def terrain_map(self,path,export=False):
        if self.scene.terrain is None:raise ValueError('Generate terrain first')
        t=self.scene.terrain.heightmap(path,export)
        if not export:
            def op():self.scene.terrain=t;self.scene.revision+=1
            self.change(op)
        self.log(('Exported ' if export else 'Imported ')+str(path))
    def save_scripts(self):
        if self.code is not None: self.code.save(all=True)
    def show_output(self):
        self.output_expanded=not self.output_expanded; self.dirty=True
    def choose(self,action):
        if sys.platform!="darwin": self.command_prefix(action+" "); return
        if self.playing: raise ValueError("Stop Play before editing")
        prompt={"open":"Open an Aftershock scene","save":"Save scene as","import":"Import an OBJ, GLB or glTF model"}[action]
        expression=(f'POSIX path of (choose file name with prompt "{prompt}" default name "project_city.json")' if action=="save" else f'POSIX path of (choose file with prompt "{prompt}")')
        result=subprocess.run(["osascript","-e",expression],capture_output=True,text=True)
        if result.returncode==0:
            self.command=action+" "+shlex.quote(result.stdout.strip()); self.execute(self.graphics)
    def import_pbr_dialog(self):
        if self.playing:raise ValueError('Stop Play before importing materials')
        if sys.platform!='darwin':self.dismiss_picker();self.command_prefix('importpbr ');return
        from .materials import NAMES
        choices=', '.join('"'+n+'"' for n in NAMES if n!='Water')
        selection=subprocess.run(['/usr/bin/osascript','-e','choose from list {'+choices+'} with prompt "Choose the material to replace"'],capture_output=True,text=True)
        if selection.returncode or selection.stdout.strip()=='false':return
        folder=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose folder with prompt "Select folder with albedo, roughness and OpenGL normal maps")'],capture_output=True,text=True)
        if folder.returncode:return
        self.dismiss_picker();self.command='importpbr '+shlex.quote(selection.stdout.strip())+' '+shlex.quote(folder.stdout.strip());self.execute(self.graphics)
    def install_scanned_pack(self):
        if self.playing:raise ValueError('Stop Play before importing materials')
        if self.pack_thread and self.pack_thread.is_alive():self.log('Poly Haven material download already running');return
        if sys.platform=='darwin':
            result=subprocess.run(['/usr/bin/osascript','-e','display dialog "Download eight 1K CC0 materials from Poly Haven into this project? Existing overrides are preserved. Allow disk space for up to about 64 MB of imported maps. Restart Studio afterwards." buttons {"Cancel", "Download"} default button "Download" with title "Poly Haven Material Pack"'],capture_output=True,text=True)
            if result.returncode:return
        from .scanned_pack import install_real_world
        def work():
            try:
                results=install_real_world(ROOT.parent.parent,self.pack_messages.put)
                n=sum(v=='Installed' for v in results.values());self.pack_messages.put(f'Poly Haven pack: {n} installed; '+str(sum(v.startswith("Failed") for v in results.values()))+' failed. Restart Studio to load imported maps.')
            except Exception as exc:self.pack_messages.put('Poly Haven pack failed: '+str(exc))
        self.pack_thread=threading.Thread(target=work,daemon=True);self.pack_thread.start();self.log('Downloading Poly Haven scanned material pack…')
    def poll_material_pack(self):
        while True:
            try:self.log(self.pack_messages.get_nowait())
            except queue.Empty:break
    def update_error(self,exc):
        self.log('Update failed: '+str(exc));self.output_expanded=True
        if sys.platform=='darwin':
            dialog='on run argv\n display dialog (item 1 of argv) buttons {"OK"} with title "Aftershock Update Failed" with icon stop\nend run'
            subprocess.run(['/usr/bin/osascript','-e',dialog,str(exc)],capture_output=True,text=True)
    def update_menu(self):
        try:
            if self.update_checker is not None:self.update_checker.start()
            else:self._update_menu()
        except Exception as exc:self.update_error(exc)
    def update_options(self):
        try:self._update_menu()
        except Exception as exc:self.update_error(exc)
    def _update_menu(self):
        if self.playing: raise ValueError('Stop Play before updating')
        if sys.platform!='darwin': self.command_prefix('update ');return
        from launcher.update_manager import UpdateManager
        manager=UpdateManager();state=manager.state()
        from launcher.online_updates import get_repo, set_repo, check
        choices=['Check GitHub for updates','Configure GitHub repository','Install ZIP…','Refresh startup screen…','Restore original startup screen…']
        if state['previous'] is not None:choices.append('Restore previous version…')
        # choose from list supports more than three native dialog buttons.
        source='on run argv\n set resultList to choose from list argv with title "Aftershock Updates" with prompt "Engine '+config.VERSION+' | Choose an update action" default items {item 1 of argv}\n if resultList is false then return ""\n return item 1 of resultList\nend run'
        result=subprocess.run(['/usr/bin/osascript','-e',source,*choices],capture_output=True,text=True)
        if result.returncode:return
        action=result.stdout.strip()
        if action in ('Refresh startup screen…','Restore original startup screen…'):
            restore=action.startswith('Restore')
            source='display dialog "This will change only the native developer launcher. Your engine and projects stay intact. The original launcher is backed up. Changes appear next time you open Studio." buttons {"Cancel", "Continue"} default button "Cancel" with title "Aftershock Startup Screen"'
            answer=subprocess.run(['/usr/bin/osascript','-e',source],capture_output=True,text=True)
            if answer.returncode or 'Continue' not in answer.stdout:return
            from launcher.refresh_host import refresh
            backup=refresh(restore=restore);self.log('Startup screen refreshed; changes apply on next launch. Original launcher backup: '+str(backup));self.output_expanded=True
            return
        if action=='Restore previous version…':self.request_rollback();return
        if action=='Configure GitHub repository':
            source='on run argv\n display dialog "Only use a public repository you trust. Releases contain executable engine code." default answer (item 1 of argv) buttons {"Cancel", "Save"} default button "Cancel" with title "GitHub Update Source"\n return text returned of result\nend run'
            result=subprocess.run(['/usr/bin/osascript','-e',source,get_repo(manager)],capture_output=True,text=True)
            if result.returncode==0:self.log('Update repository: '+set_repo(manager,result.stdout.strip()))
            return
        if action=='Check GitHub for updates':
            if self.update_checker is not None:self.update_checker.start();return
            repo=get_repo(manager);asset=check(repo,config.VERSION)
            if asset is None:
                source='on run argv\n display dialog (item 1 of argv) buttons {"OK"} with title "Aftershock Updates"\nend run'
                subprocess.run(['/usr/bin/osascript','-e',source,'No compatible published update found for '+config.VERSION+' in '+repo+'.'],capture_output=True,text=True);return
            self.request_online_update(asset);return
        if action!='Install ZIP…':return
        choice=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose file with prompt "Select an Aftershock update ZIP")'],capture_output=True,text=True)
        if choice.returncode==0:self.request_update(choice.stdout.strip())
    def request_online_update(self,asset,confirmed=False):
        if self.playing:raise ValueError('Stop Play before updating')
        if not os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):raise ValueError('Open Aftershock Studio.app to use updates')
        target=asset['target'];size=asset['size']/1048576
        if not confirmed and not self.confirm_update(f"Download Aftershock {target} ({size:.2f} MB) from {asset['repository']}?\n\nOnly install executable updates from a repository you trust. Studio will save, close, download and install the patch, then reopen automatically."):return
        self.save_scripts();self.save()
        from launcher.update_manager import ROOT as engine_root
        from launcher.update_progress import start_update
        start_update(engine_root,None,target,self.path,online=asset)
        self.log('Downloading update '+target+' and restarting…');self.update_close=True
    def confirm_update(self,message):
        if sys.platform!='darwin':raise ValueError('Offline update confirmation is supported in the macOS app')
        source='on run argv\n display dialog (item 1 of argv) buttons {"Cancel", "Install & Restart"} default button "Cancel" cancel button "Cancel" with title "Aftershock Updates"\nend run'
        result=subprocess.run(['/usr/bin/osascript','-e',source,message],capture_output=True,text=True)
        return result.returncode==0 and 'Install & Restart' in result.stdout
    def request_update(self,path):
        if self.playing:raise ValueError('Stop Play before updating')
        if not os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):raise ValueError('Open Aftershock Studio.app to use updates')
        from launcher.update_manager import UpdateManager, ROOT as engine_root
        manager=UpdateManager();manifest=manager.inspect(Path(path).expanduser(),engine_root)
        target=manifest['target']
        if not self.confirm_update('Install Aftershock Engine '+target+'?\n\nOnly install ZIPs you trust. Checksums detect corruption but do not authenticate the publisher. Studio will save your scene and scripts, close, show installation progress, and reopen automatically.'):return
        self.save_scripts();self.save()
        from launcher.update_progress import start_update
        start_update(engine_root,Path(path).expanduser(),target,self.path)
        self.log('Installing update '+target+' and restarting…');self.update_close=True
    def request_rollback(self):
        if self.playing:raise ValueError('Stop Play before restoring')
        if not os.environ.get('AFTERSHOCK_PYTHON_EXECUTABLE'):raise ValueError('Open Aftershock Studio.app to use updates')
        from launcher.update_manager import UpdateManager
        manager=UpdateManager()
        if not self.confirm_update('Restore the previous engine version?\n\nYour current scene and scripts will be saved, then Studio will close. Newer project formats may not be readable by older engines. Studio will reopen automatically.'):return
        self.save_scripts();self.save()
        from launcher.update_progress import start_update
        from launcher.update_manager import ROOT as engine_root
        start_update(engine_root,None,None,self.path);self.update_close=True
    def open_template_picker(self):
        if self.playing:raise ValueError('Stop Play before opening a template')
        self.scene_tab();self.picker='templates';self.dirty=True
    def dismiss_picker(self):
        self.picker=None;self.dirty=True
    def open_template(self,name):
        from .templates import make_template,template_view
        if self.playing:raise ValueError('Stop Play before opening a template')
        template=make_template(name)
        self.change(lambda:self.restore((template.to_data(),None)))
        # New filename avoids overwriting the current scene or another template instance.
        self.path=SCENES/(name.lower().replace(' ','_')+'_'+uuid.uuid4().hex[:8]+'.json')
        self.scene_tab();self.close_world_tools();self.dismiss_picker();self.search='';self.offset=0;self.view_mode='Perspective'
        if self.camera is not None:
            x,y,z,yaw,pitch=template_view(template,name);self.camera.position[:]=(x,y,z);self.camera.yaw,self.camera.pitch=yaw,pitch
        self.log(name+' opened | Play to spawn automatically. Save to keep this new scene. Undo restores the previous scene.')
    def add_menu(self):
        if self.playing:raise ValueError('Stop Play before adding objects')
        self.picker='objects';self.dirty=True
    def placement(self,size=2.):
        # Place on the ground under the middle of the viewport when possible.
        if self.camera is None:return (0.,0. if size==0 else max(2.,size/2),0.)
        origin=self.camera.position;direction=self.camera.forward
        if self.scene.terrain is not None:
            hit=self.scene.terrain.ray(origin,direction)
            if hit is not None and np.linalg.norm(hit-origin)<120:return (float(hit[0]),float(hit[1])+size/2,float(hit[2]))
        elif direction[1]<-.01:
            k=-origin[1]/direction[1]
            if 2<k<80:
                hit=origin+direction*k;return (float(hit[0]),size/2,float(hit[2]))
        return tuple(origin+direction*8)
    def add_object(self,kind):
        from .physics import Body
        from .templates import add_spawn
        if kind=='Player Spawn':
            pos=self.placement(0.);self.change(lambda:setattr(self,'selected',add_spawn(self.scene,pos)))
        elif kind=='Ground':
            def op():
                self.selected=self.scene.create('Ground',Transform((0,-.5,0),scale=(160,1,160)),Mesh((.48,.52,.50),material=(.88,0,0,PATTERNS.index('Concrete'))));self.scene.set_body(self.selected,Body())
            self.change(op)
        elif kind=='Dynamic Crate':
            def op():
                pos=self.placement(1.);self.selected=self.scene.create('Crate',Transform((pos[0],pos[1]+1,pos[2])),Mesh((.8,.65,.45),material=(.8,0,0,PATTERNS.index('Wood'))));self.scene.set_body(self.selected,Body('dynamic'))
            self.change(op)
        elif kind=='Tree':
            from .city import box
            def op():
                x,y,z=self.placement(0.);self.selected=box(self.scene,'Tree trunk',(x,y+1.6,z),(.42,3.2,.42),(.38,.23,.14),solid=True,kind='builtin:tree_trunk');box(self.scene,'Tree canopy',(x,y+4,z),(3.5,3,3.5),(.20,.43,.15),kind='builtin:tree_crown')
            self.change(op)
        elif kind=='Empty':self.create('empty',1.,'Empty')
        elif kind=='Cube':
            def op():
                self.selected=self.scene.create('Cube',Transform(self.placement(2.),scale=(2,2,2)),Mesh());self.scene.set_body(self.selected,Body())
            self.change(op)
        else:raise ValueError('Unknown object')
        self.dismiss_picker();self.clear_search();self.reveal();self.log(kind+' added')
    def export_dialog(self):
        if self.playing:raise ValueError('Stop Play before exporting')
        if sys.platform!='darwin':self.command_prefix('export ');return
        ask='on run argv\n text returned of (display dialog "Game name" default answer (item 1 of argv) with title "Export Aftershock Game")\nend run'
        result=subprocess.run(['/usr/bin/osascript','-e',ask,self.scene.name],capture_output=True,text=True)
        if result.returncode:return
        name=result.stdout.strip()
        folder=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose folder with prompt "Choose a folder for the exported game app")'],capture_output=True,text=True)
        if folder.returncode:return
        mode=subprocess.run(['/usr/bin/osascript','-e','display dialog "Include your current project Luau scripts? Scene Only is useful for testing templates." buttons {"Cancel", "Scene Only", "Include Scripts"} default button "Include Scripts" cancel button "Cancel" with title "Export Aftershock Game"'],capture_output=True,text=True)
        if mode.returncode:return
        self.export_game(folder.stdout.strip(),name,run_scripts='Include Scripts' in mode.stdout)
    def export_game(self,folder,name,run_scripts=True):
        if self.playing:raise ValueError('Stop Play before exporting')
        from .game_export import export_game
        self.save_scripts()
        quality=getattr(getattr(self,'graphics',None),'quality',None)
        path=export_game(self.scene,folder,name,quality=quality.name.lower() if quality else 'medium',run_scripts=run_scripts)
        self.log('Game exported: '+str(path));self.output_expanded=True
        if sys.platform=='darwin':subprocess.run(['/usr/bin/open','-R',str(path)],capture_output=True)
        return path
    def city_demo(self):
        from .city import demo
        self.change(lambda:self.restore((demo().to_data(),None)))
        self.path=SCENES/"living_district.json";self.scene_tab();self.world_tools=True
        if getattr(self,"camera",None) is not None:
            self.camera.position[:]=(10,22,40);self.camera.yaw,self.camera.pitch=-105,-24
        self.log("Living District created. Play > G > E near blue car; WASD, Space brake, E exit.")
    def close_world_tools(self):
        self.road_points=None;self.world_tools=False;self.dirty=True
    def road_tool(self):
        if self.playing:raise ValueError('Stop Play before road editing')
        self.road_points=[];self.world_tools=True;self.log('Click ground to add road points, then Finish road.')
    def road_finish(self):
        from .city import add_road
        if self.road_points is None or len(self.road_points)<2:raise ValueError('Place at least two road points')
        points=list(self.road_points);self.change(lambda:add_road(self.scene,points,10));self.road_points=None;self.log('Road built; Undo supported')
    def city_setting(self,**changes):
        from .city import validate
        data=validate({**(self.scene.city or {}),**changes})
        def op():self.scene.city=data;self.scene.revision+=1
        self.change(op)
    def weather(self):
        from .environment import PRESETS
        names=list(PRESETS); old=self.scene.environment
        self.set_environment(weather=names[(names.index(old.weather)+1)%len(names)])
    def set_environment(self,**values):
        def op():self.scene.environment=replace(self.scene.environment,**values)
        if self.playing:op();self.dirty=True
        else:self.change(op)
    def clear_search(self): self.search=""; self.offset=0; self.dirty=True
    def sync(self,scene):
        if self.scene is not scene:
            self.history.clear(); self.future.clear(); self.selected=None; self.offset=0; self.revision=-1
        self.scene=scene
        if self.revision!=scene.revision:
            self.ids=[]; self.depth={}; pending=[(e,0) for e in sorted(scene.children[None],key=lambda e:(scene.names[e],e),reverse=True)]
            while pending:
                e,d=pending.pop(); self.ids.append(e); self.depth[e]=d
                pending.extend((c,d+1) for c in sorted(scene.children[e],key=lambda c:(scene.names[c],c),reverse=True))
            if self.selected not in scene.names: self.selected=None
            self.offset=min(self.offset,max(0,len(self.ids)-1)); self.revision=scene.revision; self.dirty=True
    def remember(self):
        self.history.append((self.scene.to_data(),self.selected)); self.history=self.history[-12:]; self.future.clear()
    def restore(self,snapshot,restored=None):
        data,selection=snapshot; restored=Scene.from_data(data) if restored is None else restored
        # preserve identity shared with application, but invalidate renderer caches
        revision=self.scene.revision+1; self.scene.__dict__.update(restored.__dict__); self.scene.revision=revision; self.selected=selection; self.sync(self.scene)
    def undo(self):
        if self.history and not self.playing:
            self.future.append((self.scene.to_data(),self.selected)); self.restore(self.history.pop()); self.log('Undo')
    def redo(self):
        if self.future and not self.playing:
            self.history.append((self.scene.to_data(),self.selected)); self.restore(self.future.pop()); self.log('Redo')
    def select(self,eid):
        self.sync(self.scene)
        self.surface_dropdown=False;self.selected=eid if eid in self.scene.names else None; self.dirty=True
        if eid in self.ids:
            i=self.ids.index(eid); self.offset=min(self.offset,i) if i<self.offset else self.offset
    def change(self,fn):
        if self.playing: raise ValueError('Stop play mode before editing')
        before=(self.scene.to_data(),self.selected)
        result=fn(); self.history.append(before); self.history=self.history[-12:]; self.future.clear(); self.sync(self.scene); self.dirty=True; return result
    def require(self):
        if self.selected not in self.scene.names: raise ValueError('Select an entity first')
        return self.selected
    def create(self,kind='cube',size=2.,name='Cube'):
        def op():
            pos=(0,2,0)
            if self.camera is not None: pos=self.placement(size)
            self.selected=self.scene.create(name,Transform(pos,scale=(size,)*3),None if kind=='empty' else Mesh(kind=kind)); return self.selected
        self.change(op); self.reveal()
    def reveal(self):
        if self.selected in self.ids: self.offset=max(0,self.ids.index(self.selected)-2)
    def duplicate(self):
        source=self.require()
        def op():
            mapping={}; pending=[source]
            while pending:
                e=pending.pop(); p=self.scene.parents[e]; t=self.scene.transforms[e]
                if e==source: t=replace(t,position=(t.position[0]+2,t.position[1],t.position[2]))
                mapping[e]=self.scene.create(self.scene.names[e]+(' Copy' if e==source else ''),t,self.scene.meshes.get(e),mapping.get(p,p),self.scene.spins.get(e)); pending.extend(list(self.scene.children[e]))
            for old,new in mapping.items():
                if old in self.scene.bodies: self.scene.set_body(new,self.scene.bodies[old])
            self.selected=mapping[source]
        self.change(op); self.reveal()
    def delete(self):
        e=self.require(); self.change(lambda:self.scene.destroy(e)); self.selected=None
    def edit_vector(self,field,values):
        e=self.require(); self.change(lambda:self.scene.set_transform(e,replace(self.scene.transforms[e],**{field:tuple(values)})))
    def material(self,color=None,values=None):
        e=self.require(); m=self.scene.meshes.get(e)
        if m is None: raise ValueError('Entity has no mesh')
        new=replace(m,**({'color':tuple(color)} if color is not None else {'material':tuple(values)}))
        def op(): self.scene.meshes[e]=new; self.scene.revision+=1
        self.change(op)
    def surface_material(self,name):
        self.surface_dropdown=False
        if name not in PATTERNS:raise ValueError('Unknown material preset')
        e=self.require();m=self.scene.meshes[e];i=PATTERNS.index(name)
        if i>=4:
            _,_,rough,metal=SPECS[i-4];self.material(values=(rough,metal,0,i))
        else:self.material(values=(m.material[0],m.material[1],m.material[2],i))
    def play(self):
        if not self.playing:
            self.save_scripts()
            self.scene_tab()
            self.road_points=None;self.saved_edit=(self.scene.to_data(),self.selected)
            if self.on_play_start: self.on_play_start()
            self.drag=None; self.playing=True; self.log('PLAY PREVIEW | fixed-step systems running')
        else:
            # Validate the saved snapshot before stopping the live world.
            restored=Scene.from_data(self.saved_edit[0])
            if self.on_play_stop: self.on_play_stop()
            self.restore(self.saved_edit,restored); self.saved_edit=None; self.playing=False; self.drag=None; self.log('Stopped | edit scene restored')
    def save(self,path=None):
        if self.playing: raise ValueError('Stop play mode before saving')
        target=Path(path).expanduser() if path else self.path
        self.scene.save(target); self.path=target; self.log('Saved '+target.name)
    def open(self,path):
        target=Path(path).expanduser(); data=Scene.load(target).to_data(); self.change(lambda:self.restore((data,None))); self.path=target; self.log('Opened '+target.name)
    def command_prefix(self,s): self.command=s; self.typing=True; self.dirty=True
    def execute(self,g):
        raw=self.command; self.command=''; self.typing=False
        try:
            args=shlex.split(raw); cmd=args.pop(0).lower() if args else ''
            if not cmd: return
            if cmd=='importpbr':
                if self.playing or len(args)!=2:raise ValueError('Stop Play and use importpbr MATERIAL FOLDER')
                from .materials import import_pbr
                import_pbr(ROOT.parent.parent,args[0].title(),args[1]);self.log('PBR material imported. Restart Studio to load it.');self.output_expanded=True;return
            if cmd=='find': self.search=' '.join(args).casefold(); self.offset=0; self.log('Explorer filter: '+(self.search or 'All')); return
            if cmd=='help': self.log('new/save/open/import/pos/rot/scale/mat/body/velocity/solid/playground/time'); return
            if cmd=='citydemo':self.city_demo();return
            elif cmd=='road':
                from .city import add_road
                if len(args)<5 or len(args)%2!=1:raise ValueError('road WIDTH X1 Z1 X2 Z2 [X3 Z3 ...]')
                width=float(args[0]);points=list(zip(map(float,args[1::2]),map(float,args[2::2])));self.change(lambda:add_road(self.scene,points,width))
            elif cmd=='population':self.city_setting(traffic=int(args[0]),pedestrians=int(args[1]))
            elif cmd=='vehicle':self.city_setting(vehicle=args[0].title())
            elif cmd=='clip':
                from .animation import load_clips,clip_data
                if len(args)!=2:raise ValueError('clip NAME DURATION')
                name=args[0];duration=float(args[1]);data=clip_data(self.scene.clips);data[name]=dict(duration=duration,keys=[(0,0,0,0),(duration,0,0,0)])
                clips=load_clips(data);self.change(lambda:setattr(self.scene,'clips',clips));self.log('Clip '+name+' created; key NAME TIME STRIDE CROUCH AIR');return
            elif cmd=='key':
                from .animation import load_clips,clip_data
                if len(args)!=5:raise ValueError('key NAME TIME STRIDE CROUCH AIR')
                data=clip_data(self.scene.clips);item=data[args[0]];key=tuple(map(float,args[1:]));item['keys']=sorted([k for k in item['keys'] if k[0]!=key[0]]+[key]);clips=load_clips(data);self.change(lambda:setattr(self.scene,'clips',clips))
            elif cmd=='animation':
                from .animation import CLIPS
                value=args[0];names={n.casefold():n for n in (*CLIPS,*self.scene.clips)}
                if value.casefold()=='auto':self.animation_preview=None
                elif value.casefold() in names:self.animation_preview=names[value.casefold()]
                else:raise ValueError('Unknown animation clip; choose Auto or a built-in/custom clip')
            elif cmd=='assetfind':self.asset_search=' '.join(args).casefold();self.asset_offset=0
            elif cmd=='door':
                from .interactions import register
                eid=self.require();self.change(lambda:register(self.scene,eid))
            elif cmd=='emitter':
                from .audio import validate_emitter
                if len(self.scene.emitters)>=32:raise ValueError('Maximum 32 sound emitters')
                if len(args)!=7:raise ValueError('emitter SOUND X Y Z VOLUME RADIUS INTERVAL')
                e=validate_emitter(dict(sound=args[0],position=list(map(float,args[1:4])),volume=float(args[4]),radius=float(args[5]),interval=float(args[6])))
                self.change(lambda:self.scene.emitters.append(e))
            elif cmd=='clearemitters':self.change(lambda:self.scene.emitters.clear())
            elif cmd=='skinning':g.skinning=not g.skinning
            elif cmd=='adaptive':g.adaptive=not g.adaptive
            elif cmd=='terrainseed':
                seed=int(args[0]);Terrain(self.terrain_preset,seed,self.terrain_size,self.terrain_water);self.terrain_seed=seed
            elif cmd=='terrainwater':
                level=float(args[0]);Terrain(self.terrain_preset,self.terrain_seed,self.terrain_size,level);self.terrain_water=level
            elif cmd=='heightimport':self.terrain_map(args[0])
            elif cmd=='heightexport':self.terrain_map(args[0],True)
            elif cmd=='new': self.open_template('Baseplate');return
            elif cmd=='template': self.open_template(' '.join(args));return
            elif cmd=='export':
                if len(args)!=2:raise ValueError('export FOLDER NAME (quote spaces)')
                self.export_game(args[0],args[1]);return
            elif cmd=='save': self.save(args[0] if args else None); return
            elif cmd=='update': self.request_update(args[0]); return
            elif cmd=='rollback': self.request_rollback(); return
            elif cmd=='open': self.open(args[0]); return
            elif cmd=='import':
                if self.playing: raise ValueError('Stop play mode first')
                k,size,name=import_model(args[0]); self.create(k,size,name)
            elif cmd=='colliders': self.debug_colliders=not self.debug_colliders
            elif cmd=='playground':
                from .world import playground
                count=int(args[0]) if args else 60
                if not 0<=count<=1000: raise ValueError('Choose 0-1000 crates')
                self.change(lambda:self.restore((playground(count).to_data(),None)))
            elif cmd=='solid':
                from .world import solid_city
                self.change(lambda:solid_city(self.scene))
            elif cmd=='body':
                from .physics import Body
                e=self.require()
                if args==['remove']: self.change(lambda:self.scene.set_body(e,None))
                else:
                    if len(args)<2 or len(args)>7: raise ValueError('body static/dynamic/kinematic box/sphere/capsule/cylinder/convex/mesh [mass friction bounce gravity(0/1) ccd(0/1)]')
                    v=args[2:]; flags=[bool(int(x)) for x in v[3:]]
                    if any(x not in ('0','1') for x in v[3:]): raise ValueError('Gravity and CCD use 0 or 1')
                    b=Body(args[0],args[1],*map(float,v[:3]),*flags)
                    self.change(lambda:self.scene.set_body(e,b))
            elif cmd=='velocity':
                e=self.require(); b=replace(self.scene.bodies[e],velocity=tuple(map(float,args)))
                self.change(lambda:self.scene.set_body(e,b))
            elif cmd=='rename':
                e=self.require(); name=' '.join(args).strip()
                if not name: raise ValueError('Enter a name')
                def op(): self.scene.names[e]=name; self.scene.revision+=1
                self.change(op)
            elif cmd=='parent':
                e=self.require(); i=int(args[0])-1 if args[0]!='root' else None
                if i is not None and not 0<=i<len(self.ids): raise ValueError('Invalid hierarchy row')
                self.change(lambda:self.scene.reparent(e,None if i is None else self.ids[i]))
            elif cmd in ('pos','rot','scale'): self.edit_vector({'pos':'position','rot':'rotation','scale':'scale'}[cmd],map(float,args))
            elif cmd=='color': self.material(color=list(map(float,args)))
            elif cmd=='mat': self.material(values=list(map(float,args)))
            elif cmd=='material': self.surface_material(next((n for n in PATTERNS if n.casefold()==' '.join(args).casefold()),''))
            elif cmd=='weather':
                from .environment import PRESETS
                self.set_environment(weather=next(n for n in PRESETS if n.casefold()==args[0].casefold()))
            elif cmd=='audio':self.set_environment(audio=args[0].lower()=='on')
            elif cmd=='volume':self.set_environment(volume=float(args[0]))
            elif cmd=='time':
                v=float(args[0]);
                if not math.isfinite(v): raise ValueError('Time must be finite')
                g.hour=v%24
            elif cmd=='exposure':
                v=float(args[0]);
                if not math.isfinite(v): raise ValueError('Exposure must be finite')
                g.exposure=max(.1,min(4,v))
            elif cmd=='select':
                i=int(args[0])-1
                if not 0<=i<len(self.ids): raise ValueError('Invalid hierarchy row')
                self.select(self.ids[i]); self.reveal()
            elif cmd=='undo': self.undo(); return
            elif cmd=='redo': self.redo(); return
            else: raise ValueError('Unknown command; type help')
            self.log('Applied '+cmd)
        except Exception as exc: self.log(exc)
    def viewport(self,w,h):
        left=min(220,max(130,w//5)); right=min(275,max(150,w//4)); top=108; bottom=max(top+1,h-(238 if self.output_expanded else 144))
        return left,top,max(1,w-left-right),max(1,bottom-top)
    def projection(self,w,h):
        if self.view_mode=='Perspective': return perspective(config.FOV,w/max(1,h),config.NEAR,2600. if self.scene.terrain is not None else 2200. if self.scene.name=='Stress City' else config.FAR)
        size=self.ortho_size; aspect=w/max(1,h); n,f=.1,2200.; p=np.diag([1/(size*aspect),1/size,-2/(f-n),1]).astype('f4'); p[2,3]=-(f+n)/(f-n); return p
    def ray(self,x,y):
        l,t,w,h=self.rect; u=2*(x-l)/w-1; v=1-2*(y-t)/h
        inv=np.linalg.inv(self.projection(w,h)@self.camera.view()); a=inv@np.array([u,v,-1,1]); b=inv@np.array([u,v,1,1]); a=a[:3]/a[3]; b=b[:3]/b[3]; d=b-a; return a,d/np.linalg.norm(d)
    def project(self,p):
        l,t,w,h=self.rect; v=self.projection(w,h)@self.camera.view()@np.r_[p,1]
        if v[3]<=0: return None
        q=v[:3]/v[3]; return np.array([l+(q[0]+1)*w/2,t+(1-q[1])*h/2])
    def set_view(self,mode):
        self.view_mode=mode; target=np.zeros(3)
        if self.selected: target=world_matrices(self.scene)[self.selected][:3,3]
        c=self.camera
        if mode=='Top': c.yaw,c.pitch=-90,-89.9
        elif mode=='Front': c.yaw,c.pitch=-90,0
        elif mode=='Side': c.yaw,c.pitch=180,0
        else: c.yaw,c.pitch=-122,-23
        c.position[:]=target-c.forward*85; self.dirty=True
    def click(self,x,y):
        self.typing=False
        try:
            for x1,y1,x2,y2,fn in reversed(self.buttons):
                if x1<=x<x2 and y1<=y<y2: fn(); self.dirty=True; return
            if self.picker:return
            if self.script_tab:
                self.code.click(x,y); self.dirty=True; return
            l,t,w,h=self.rect
            if not self.playing and l<=x<l+w and t<=y<t+h:
                if self.terrain_tab:self.terrain_stamp(x,y);return
                if self.road_points is not None:
                    origin,direction=self.ray(x,y)
                    if self.scene.terrain is not None:hit=self.scene.terrain.ray(origin,direction)
                    else:
                        k=-origin[1]/direction[1] if abs(direction[1])>1e-7 else -1;hit=origin+direction*k if k>=0 else None
                    if hit is not None and len(self.road_points)<64:
                        point=(round(float(hit[0])/2)*2,round(float(hit[2])/2)*2)
                        if not self.road_points or math.dist(point,self.road_points[-1])>=1:self.road_points.append(point);self.log(f'Road point {len(self.road_points)}: {point}')
                    return
                for axis,a,b in self.gizmo:
                    delta=b-a; q=np.array([x,y]); f=np.clip(np.dot(q-a,delta)/max(1,np.dot(delta,delta)),0,1)
                    if f>.2 and np.linalg.norm(q-a-f*delta)<9:
                        e=self.require(); self.remember(); self.drag=(e,axis,q,delta,self.scene.transforms[e],self.mode,self.gizmo_length); return
                self.select(pick(self.scene,*self.ray(x,y))); self.reveal()
        except Exception as exc: self.log(exc)
        self.dirty=True
    def motion(self,x,y,down):
        old=self.pointer; self.pointer=(x,y)
        # Redraw only when entering or leaving a control, not for every mouse movement.
        def hover(p): return next((i for i,(a,b,c,d,_) in enumerate(self.buttons) if a<=p[0]<c and b<=p[1]<d),None)
        if hover(old)!=hover(self.pointer): self.dirty=True
        if self.script_tab:
            if self.code: self.code.motion(x,y,down)
            return
        if self.terrain_tab:return
        if not self.drag: return
        if not down: self.drag=None; return
        e,axis,start,delta,original,mode,length=self.drag
        if e not in self.scene.names: self.drag=None; return
        f=float(np.dot(np.array([x,y])-start,delta)/max(1,np.dot(delta,delta)))
        if mode=='move':
            world=np.zeros(3); world[axis]=f*length; p=self.scene.parents[e]
            if p is not None: world=np.linalg.solve(world_matrices(self.scene)[p][:3,:3],world)
            new=replace(original,position=tuple(np.array(original.position)+world))
        elif mode=='rotate':
            v=list(original.rotation); v[axis]+=f*45; new=replace(original,rotation=tuple(v))
        else:
            v=list(original.scale); v[axis]=max(.01,v[axis]*max(.01,1+f)); new=replace(original,scale=tuple(v))
        if self.scene.transforms[e]!=new: self.scene.set_transform(e,new); self.dirty=True
    def visible_entities(self):
        # Luau and physics can mutate the scene after the frame's initial sync.
        self.sync(self.scene)
        return [e for e in self.ids if e in self.scene.names and self.search in self.scene.names[e].casefold()]
    def scroll(self,delta,x,y):
        if self.script_tab:
            self.code.scroll(delta,x); self.dirty=True; return
        l,t,w,h=self.rect
        if x<l: self.offset=max(0,min(max(0,len(self.visible_entities())-1),self.offset-int(delta*3)))
        elif y>=t+h: self.asset_offset=max(0,min(max(0,len(list(ROOT.glob('*.npz')))-1),self.asset_offset-int(delta)))
        elif l<=x<l+w and t<=y<t+h:
            if self.view_mode!='Perspective': self.ortho_size=max(2,min(1000,self.ortho_size*math.exp(-delta*.1)))
            else: self.camera.position+=self.camera.forward*float(delta)*3
        self.dirty=True
    camera=None
    rect=(0,0,1,1)
    def image(self,g,stats,w,h,camera,pixel_size=None):
        self.sync(self.scene)
        self.graphics=g; self.camera=camera; self.rect=self.viewport(w,h); l,t,vw,vh=self.rect; r=l+vw; b=t+vh
        im,d=canvas(w,h,pixel_size); self.buttons=[]; self.gizmo=[]
        bg=theme.BG; panel=theme.PANEL; border=theme.BORDER; accent=theme.ACCENT; fg=theme.TEXT; muted=theme.MUTED
        def text(x,y,s,fill=fg,font=None): d.text((x,y),str(s),fill=fill,font=font or self.font)
        def button(x,y,bw,label,fn,active=False):
            hover=x<=self.pointer[0]<x+bw and y<=self.pointer[1]<y+24
            color=('#a43f48' if label=='Stop' else theme.GREEN if label=='Play' else theme.SELECT) if active else theme.HOVER if hover else theme.SURFACE
            d.rounded_rectangle((x,y,x+bw,y+23),radius=5,fill=color,outline=theme.BORDER); text(x+7,y+4,label,font=self.small); self.buttons.append((x,y,x+bw,y+24,fn))
        d.rectangle((0,0,w,t),fill=bg); d.rectangle((0,t,l,b),fill=panel); d.rectangle((r,t,w,b),fill=panel); d.rectangle((0,b,w,h),fill=bg)
        d.rectangle((l,t,r-1,b-1),outline=border); im.alpha_composite(theme.emblem(round(38*d.scale)),d.point((9,3))); text(53,5,'Aftershock Studio',fg,self.large); text(54,26,self.scene.name+'  ·  '+stats,muted,self.small); text(w-265,12,'PLAYING' if self.playing else 'EDIT  /  '+config.VERSION,'#63df9d' if self.playing else muted,self.small)
        d.line((0,42,w,42),fill=border); d.line((0,74,w,74),fill=border)
        buttons=[('New',lambda:self.open_template('Baseplate')),('Open',lambda:self.choose('open')),('Open Template',self.open_template_picker),('Save',self.save),('Save as',lambda:self.choose('save')),('Undo',self.undo),('Redo',self.redo),('Stop' if self.playing else 'Play',self.play),('Import',lambda:self.choose('import')),('Output',self.show_output),('Check for Updates',self.update_menu),('Export Game',self.export_dialog)]
        if self.script_tab:
            buttons=[('Save all',self.save_scripts),('Stop' if self.playing else 'Play',self.play),('Output',self.show_output),('Check for Updates',self.update_menu)]
        x=10
        for label,fn in buttons:
            bw={'Open Template':112,'Export Game':96,'Check for Updates':128}.get(label,60);button(x,47,bw,label,fn,label in ('Play','Stop')); x+=bw+5
        if not self.script_tab and x+200<w:
            button(x,47,116,'Weather: '+self.scene.environment.weather,self.weather);x+=121
            button(x,47,76,'Audio: '+('On' if self.scene.environment.audio else 'Off'),lambda:self.set_environment(audio=not self.scene.environment.audio),self.scene.environment.audio)
        if self.picker=='graphics':
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg)
            text(24,90,'Graphics settings',accent,self.large);text(24,120,'Fine-tune performance and visual quality for this session.',muted,self.small)
            button(w-108,90,84,'Done',self.dismiss_picker)
            items=[('Preset: '+g.quality.name,g.cycle),('Render scale: '+f'{g.scale:.0%}',g.cycle_scale),('Shadow cap: '+str(g.shadow_limit),g.cycle_shadows),('Light cap: '+str(g.light_limit),g.cycle_lights)]
            for attr,label in [('shadows','Shadows'),('bloom','Bloom'),('fxaa','Anti-aliasing'),('adaptive','Adaptive resolution'),('material_detail','Material microdetail'),('ambient_occlusion','Ambient occlusion'),('grass','Grass'),('terrain_shadows','Terrain shadows'),('weather_effects','Rain effects'),('water_detail','Water detail'),('hair_wind','Hair wind'),('cloud_detail','Cloud detail'),('skinning','Weighted player skinning')]:
                items.append((label+': '+('On' if getattr(g,attr) else 'Off'),lambda attr=attr:setattr(g,attr,not getattr(g,attr))))
            bw=(w-80)//3
            for i,(label,fn) in enumerate(items):button(24+(i%3)*(bw+16),160+(i//3)*36,bw,label,fn)
            button(24,395,200,'Import scanned PBR maps…',self.import_pbr_dialog);
            if hasattr(g,'preferences_path'):button(237,395,190,'Save graphics preferences',lambda:(g.save_preferences(g.preferences_path),self.log('Graphics preferences saved')))
            button(24,433,300,'Download Poly Haven CC0 material pack…',self.install_scanned_pack)
            text(24,470,'Quality presets control vegetation LOD. Imported textures load on restart.',muted,self.small)
            text(24,489,'Scanned materials supplied by Poly Haven (polyhaven.com).',muted,self.small)
            if self.message.startswith('Poly Haven') or self.message.startswith('Downloading Poly Haven'):text(24,513,self.message[:100],accent,self.small)
            self.dirty=False;return im
        if self.picker:
            from .templates import TEMPLATES
            self.buttons=[];d.rectangle((0,76,w,h),fill=bg)
            if self.picker=='templates':
                entries=[(n,v[0],lambda n=n:self.open_template(n)) for n,v in TEMPLATES.items()]
                title='Open a world template';subtitle='Creates a new editable scene. Save your current work first; Undo restores the previous scene.'
            else:
                entries=[(n,desc,lambda n=n:self.add_object(n)) for n,desc in [('Cube','Solid building block'),('Ground','160 metre concrete baseplate'),('Dynamic Crate','Physical wooden crate'),('Player Spawn','Starting position for Play and exported games'),('Tree','Trunk and foliage'),('Empty','Non-rendered grouping object')]]
                title='Add object';subtitle='Choose an object to place in your scene.'
            text(24,91,title,accent,self.large);text(24,119,subtitle,muted,self.small);button(w-104,90,82,'Cancel',self.dismiss_picker)
            cw=(w-64)//2;ch=91
            for i,(label,desc,fn) in enumerate(entries):
                xx=24+(i%2)*(cw+16);yy=152+(i//2)*(ch+10)
                d.rounded_rectangle((xx,yy,xx+cw,yy+ch),8,fill=panel,outline=border)
                text(xx+12,yy+10,label,fg,self.large);text(xx+12,yy+34,desc,muted,self.small)
                button(xx+12,yy+60,102,'Open template' if self.picker=='templates' else 'Add object',fn,True)
            self.dirty=False;return im
        if self.script_tab:
            d.rectangle((0,76,w,h),fill=bg)
            button(10,78,96,'3D Scene',self.scene_tab); button(111,78,120,'Luau Scripts',self.script_editor,True); d.line((115,103,227,103),fill=accent,width=2)
            button(236,78,90,'Terrain',self.open_terrain); text(340,83,'Enter: accept  ·  Tab: indent  ·  Ctrl+Space: suggestions',muted,self.small)
            output_top=h-(176 if self.output_expanded else 82)
            self.code.draw(d,w,h,108,output_top,self.log)
            text(12,output_top+6,'OUTPUT  /  '+self.code.status,accent,self.small)
            for i,message in enumerate(self.output[-(9 if self.output_expanded else 3):]): text(12,output_top+25+i*16,message[:max(10,(w-20)//7)],muted,self.small)
            self.dirty=False;return im
        button(10,78,96,'3D Scene',self.scene_tab,not self.terrain_tab); button(111,78,120,'Luau Scripts',self.script_editor); button(236,78,90,'Terrain',self.open_terrain,self.terrain_tab)
        d.line((240,103,322,103) if self.terrain_tab else (14,103,102,103),fill=accent,width=2)
        x=340
        for mode in ('move','rotate','scale'):
            button(x,78,68,mode.title(),lambda m=mode:setattr(self,'mode',m),self.mode==mode); x+=73
        x+=12
        for mode in ('Perspective','Top','Front','Side'):
            bw=90 if mode=='Perspective' else 54
            button(x,78,bw,mode,lambda m=mode:self.set_view(m),self.view_mode==mode); x+=bw+5
        button(w-103,8,94,'Graphics…',lambda:setattr(self,'picker','graphics'))
        if x+92<w:button(x+5,78,86,'World tools',self.close_world_tools if self.world_tools else lambda:setattr(self,'world_tools',True),self.world_tools)
        if self.world_tools and not self.terrain_tab:
            # A compact floating palette leaves the editor viewport and hierarchy usable.
            px=l+10;py=t+36;pw=min(204,max(145,(vw-30)//2)); cols=2 if vw>=2*pw+30 else 1
            d.rounded_rectangle((px-3,py-3,px+cols*(pw+5)-2,py+22+((14+cols-1)//cols)*25+3),6,fill=panel,outline=accent)
            text(px+5,py+2,'WORLD / SIMULATION',accent,self.small)
            for idx,(label,fn) in enumerate([('Create living district',self.city_demo),('Finish road' if self.road_points is not None else 'Draw road (click points)',self.road_finish if self.road_points is not None else self.road_tool),('Traffic / pedestrians',lambda:self.command_prefix('population ')),('Vehicle preset',lambda:self.command_prefix('vehicle ')),('Animation preview',lambda:self.command_prefix('animation ')),('New animation clip',lambda:self.command_prefix('clip ')),('Edit animation key',lambda:self.command_prefix('key ')),('Adaptive resolution',lambda:setattr(g,'adaptive',not g.adaptive)),('Skinning: '+('On' if g.skinning else 'Off'),lambda:setattr(g,'skinning',not g.skinning)),('Make selected a door',lambda:self.command_prefix('door')),('Sound emitter',lambda:self.command_prefix('emitter horn ')),('Weather: '+self.scene.environment.weather,self.weather),('Audio: '+('On' if self.scene.environment.audio else 'Off'),lambda:self.set_environment(audio=not self.scene.environment.audio)),('Cancel road / close' if self.road_points is not None else 'Close tools',self.close_world_tools)]):
                button(px+(idx%cols)*(pw+5),py+22+(idx//cols)*25,pw,label,fn)
        if self.terrain_tab:
            if self.scene.terrain:self.terrain_decorations=self.scene.terrain.decorations
            text(10,t+8,'TERRAIN / WORLD',accent); y=t+32
            button(10,y,l-20,'Biome: '+self.terrain_preset+'  ▾',lambda:setattr(self,'terrain_dropdown',not self.terrain_dropdown)); dropdown_y=y+25;y+=30
            button(10,y,l-20,'Seed: '+str(self.terrain_seed),lambda:self.command_prefix('terrainseed '));y+=28
            sizes=(1024,2048,4096,8192,16384)
            button(10,y,l-20,f'World: {self.terrain_size/1000:g} km square',lambda:setattr(self,'terrain_size',sizes[(sizes.index(self.terrain_size)+1)%len(sizes)]));y+=28
            button(10,y,l-20,f'Water level: {self.terrain_water:g}m',lambda:self.command_prefix('terrainwater '));y+=31
            button(10,y,l-20,'Generate / replace terrain',self.generate_terrain,True);y+=31
            button(10,y,l-20,'Remove terrain',self.terrain_remove);y+=32
            text(10,y,'SCULPT / PAINT',accent);y+=20
            for i,mode in enumerate(('Raise','Lower','Smooth','Flatten','Paint','Erase')):
                bw=(l-25)//2;button(10+(i%2)*(bw+5),y+(i//2)*28,bw,mode,lambda m=mode:setattr(self,'brush_mode',m),self.brush_mode==mode)
            y+=90
            text(10,y,'Click terrain to apply brush',muted,self.small)
            if self.terrain_dropdown:
                # Draw menu last over the underlying controls; reversed hit testing prioritizes rows.
                d.rounded_rectangle((8,dropdown_y,l-8,dropdown_y+len(TERRAIN_PRESETS)*24+4),4,fill=bg,outline=accent)
                for i,preset in enumerate(TERRAIN_PRESETS):button(10,dropdown_y+2+i*24,l-20,preset,lambda p=preset:self.set_preset(p),preset==self.terrain_preset)
            ix=r+10; iw=w-ix-10;y=t+8;text(ix,y,'BRUSH SETTINGS',accent);y+=28
            radii=(16,32,48,64,96,128,192,256); strengths=(2,6,12,24,48,80); mats=tuple(m for m in MATERIALS if m!='Water')
            button(ix,y,iw,f'Radius: {self.brush_radius} m',lambda:setattr(self,'brush_radius',radii[(radii.index(self.brush_radius)+1)%len(radii)]));y+=29
            button(ix,y,iw,f'Strength: {self.brush_strength}',lambda:setattr(self,'brush_strength',strengths[(strengths.index(self.brush_strength)+1)%len(strengths)]));y+=29
            button(ix,y,iw,'Paint: '+self.brush_material,lambda:setattr(self,'brush_material',mats[(mats.index(self.brush_material)+1)%len(mats)]));y+=35
            text(ix,y,'DECORATIONS',accent);y+=21
            button(ix,y,iw,'Decorations: '+('On' if self.terrain_decorations else 'Off'),self.toggle_decorations,self.terrain_decorations);y+=29
            text(ix,y,'Wind-animated grass',muted,self.small);y+=25
            text(ix,y,'WORLD DATA',accent);y+=23
            tr=self.scene.terrain
            if tr:
                text(ix,y,f'{tr.preset} | {tr.size:,}m square',muted,self.small);y+=18;text(ix,y,f'{len(tr.edits):,} height edits / {len(tr.paint):,} painted',muted,self.small);y+=22
            else:text(ix,y,'No terrain. Choose a preset.',muted,self.small);y+=24
            button(ix,y,iw,'Import heightmap PNG...',lambda:self.command_prefix('heightimport '));y+=29
            button(ix,y,iw,'Export heightmap PNG...',lambda:self.command_prefix('heightexport '));y+=35
            if y+60<b:
                text(ix,y,'GRAPHICS',accent);y+=20;button(ix,y,iw,'Quality: '+g.quality.name,g.cycle);y+=28;button(ix,y,iw,f'Render scale: {g.scale:.0%}',g.cycle_scale)
            d.rounded_rectangle((l+7,t+7,l+265,t+30),5,fill=(20,29,40,225));text(l+15,t+10,'Terrain  ·  '+self.brush_mode+'  ·  Tab: fly',fg,self.small)
            text(10,b+8,'TERRAIN OUTPUT',accent,self.small)
            for row,message in enumerate(self.output[-2:] or ['Generate terrain or open a saved terrain scene.']):text(10,b+30+row*16,message[:max(10,(w-20)//7)],muted,self.small)
            d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border);text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small);self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
            self.dirty=False;return im
        text(8,t+7,'Explorer',accent); text(8,t+26,f'{len(self.ids):,} entities',muted,self.small)
        button(8,t+45, min(l-16,105),'+ Add Object',self.add_menu)
        button(8,t+74,l-50,('Filter: '+self.search)[:23] if self.search else 'Find entity...',lambda:self.command_prefix('find ')); button(l-36,t+74,28,'X',self.clear_search)
        row_index={e:i for i,e in enumerate(self.ids)};display=self.visible_entities(); self.offset=min(self.offset,max(0,len(display)-1))
        rows=max(0,(vh-130)//19)
        for row,e in enumerate(display[self.offset:self.offset+rows]):
            i=row_index[e]; y=t+104+row*19
            if e==self.selected: d.rounded_rectangle((4,y,l-4,y+18),3,fill=theme.SELECT); d.rectangle((4,y+2,6,y+16),fill=accent)
            elif 0<=self.pointer[0]<l and y<=self.pointer[1]<y+19: d.rounded_rectangle((4,y,l-4,y+18),3,fill=theme.HOVER)
            text(7,y+2,str(i+1),muted,self.small)
            indent=34+min(5,self.depth[e])*11
            if e in self.scene.meshes:
                d.rounded_rectangle((indent,y+5,indent+9,y+14),2,outline='#8299b1',width=1)
            else:
                d.rounded_rectangle((indent,y+6,indent+11,y+14),2,fill='#c5a46b')
            text(indent+16,y+2,self.scene.names[e][:max(1,(l-indent-20)//7)],font=self.small)
            self.buttons.append((0,y,l,y+19,lambda e=e:self.select(e)))
        text(8,b-22,'Scroll to browse',muted,self.small); d.line((l-1,t,l-1,b),fill=border); d.line((r,t,r,b),fill=border)
        ix=r+9; iw=max(40,w-ix-9); y=t+8; text(ix,y,'Properties',accent); y+=24
        if self.selected in self.scene.names:
            e=self.selected; tr=self.scene.transforms[e]; m=self.scene.meshes.get(e); text(ix,y,self.scene.names[e][:30]); y+=22
            button(ix,y,72,'Rename',lambda:self.command_prefix('rename ')); button(ix+76,y,72,'Duplicate',self.duplicate); y+=28
            button(ix,y,72,'Delete',self.delete); button(ix+76,y,72,'Parent',lambda:self.command_prefix('parent ')); y+=30
            for field,cmd in [('position','pos'),('rotation','rot'),('scale','scale')]:
                text(ix,y,field.title(),muted,self.small); y+=15
                vals=' '.join(f'{v:.3g}' for v in getattr(tr,field)); button(ix,y,iw,vals,lambda cmd=cmd:self.command_prefix(cmd+' ')); y+=30
            if m:
                text(ix,y,'Material / RGB',accent,self.small); y+=17
                vals=' '.join(f'{v:.3g}' for v in m.color); button(ix,y,iw,vals,lambda:self.command_prefix('color ')); y+=30
                text(ix,y,'Roughness / Metal / Emission / Pattern',muted,self.small); y+=16
                vals=' '.join(f'{v:.3g}' for v in m.material); button(ix,y,iw,vals,lambda:self.command_prefix('mat ')); y+=31
                if y+25<b:
                    button(ix,y,iw,'Surface: '+PATTERNS[int(m.material[3])]+'  ▾',lambda:setattr(self,'surface_dropdown',not self.surface_dropdown));y+=28
            if not self.playing:
                mat=world_matrices(self.scene)[e]; p=mat[:3,3]; center=self.project(p); self.gizmo_length=max(2.,min(100.,np.linalg.norm(p-camera.position)*.12))
                if center is not None and l<=center[0]<r and t<=center[1]<b:
                    for axis,col in enumerate(('#fa6868','#65e48a','#70aaff')):
                        end=self.project(p+np.eye(3)[axis]*self.gizmo_length)
                        if end is not None and np.linalg.norm(end-center)>6 and l<=end[0]<r and t<=end[1]<b:
                            d.line((*center,*end),fill=col,width=3); d.ellipse((end[0]-4,end[1]-4,end[0]+4,end[1]+4),fill=col); text(end[0]+5,end[1]-7,'XYZ'[axis],col,self.small); self.gizmo.append((axis,center,end))
                    d.ellipse((center[0]-3,center[1]-3,center[0]+3,center[1]+3),fill='white')
        else: text(ix,y,'Select an entity',muted); y+=27
        if self.selected in self.scene.names and y+42<b:
            body=self.scene.bodies.get(self.selected)
            text(ix,y,'PHYSICS',accent,self.small); y+=15
            button(ix,y,iw,'Body: '+(body.kind+' / '+body.shape if body else 'None'),lambda:self.command_prefix('body ')); y+=28
        if y+105<b:
            text(ix,y,'GRAPHICS',accent); y+=19; button(ix,y,iw,'Quality: '+g.quality.name,g.cycle); y+=27
            button(ix,y,iw,f'Render scale: {g.scale:.0%}',g.cycle_scale); y+=27
            button(ix,y,iw,f'Time {g.hour:.1f} | +1 hour',lambda:g.adjust(1)); y+=27
            if y+17<b and hasattr(g,'render_size'): text(ix,y,f'Viewport: {g.render_size[0]} × {g.render_size[1]} px',muted,self.small)
        if self.surface_dropdown and self.selected in self.scene.meshes:
            current=int(self.scene.meshes[self.selected].material[3]); top=max(t+25,b-8*26-10);bw=(iw-5)//2
            d.rounded_rectangle((ix-3,top-5,ix+iw+3,top+8*26+4),4,fill=bg,outline=accent)
            for i,name in enumerate(PATTERNS):
                button(ix+(i%2)*(bw+5),top+(i//2)*26,bw,name,lambda n=name:self.surface_material(n),i==current)
        if self.debug_colliders:
            # Project unit box outlines as a coarse bounds preview, not exact shape wireframes.
            mats=world_matrices(self.scene)
            corners=np.array([(x,y,z,1) for x in (-.5,.5) for y in (-.5,.5) for z in (-.5,.5)])
            edges=[(a,b) for a in range(8) for b in range(a+1,8) if (a^b) in (1,2,4)]
            ids=list(self.scene.bodies)
            if self.selected in self.scene.bodies: ids.remove(self.selected); ids.insert(0,self.selected)
            for e in ids[:150]:
                pts=[self.project(p[:3]) for p in (mats[e]@corners.T).T]
                col='#f6c65c' if self.scene.bodies[e].kind=='dynamic' else '#65e48a'
                for a,j in edges:
                    if pts[a] is not None and pts[j] is not None and all(l<=p[0]<r and t<=p[1]<b for p in (pts[a],pts[j])):
                        d.line((*pts[a],*pts[j]),fill=col,width=1)
        if self.road_points:
            from .city import height
            pts=[self.project((x,height(self.scene,x,z)+.2,z)) for x,z in self.road_points]
            for a,bp in zip(pts,pts[1:]):
                if a is not None and bp is not None and all(l<=p[0]<r and t<=p[1]<b for p in (a,bp)):d.line((*a,*bp),fill=accent,width=3)
            for p in pts:
                if p is not None and l<=p[0]<r and t<=p[1]<b:d.ellipse((p[0]-4,p[1]-4,p[0]+4,p[1]+4),fill=accent)
        d.rounded_rectangle((l+7,t+7,min(r-6,l+490),t+30),5,fill=(20,29,40,225)); text(l+15,t+10,('G: character · B: view · '+self.character_status) if self.playing else self.view_mode+'  ·  Tab: fly camera',fg,self.small)
        text(10,b+5,'Asset browser',accent); button(10,b+24,72,'Import...',lambda:self.command_prefix('import '))
        models=[p for p in sorted(ROOT.glob('*.npz')) if self.asset_search in asset_info(p)[0].casefold()]; x=190
        button(88,b+24,96,('Find: '+self.asset_search)[:13] if self.asset_search else 'Find asset...',lambda:self.command_prefix('assetfind '))
        for p in models[self.asset_offset:]:
            if x+105>=w: break
            name,size=asset_info(p); button(x,b+24,102,name[:14],lambda p=p,name=name,size=size:self.create('asset:'+p.name,size,name)); x+=108
        text(10,b+52,'OUTPUT  /  '+('Play session' if self.playing else 'Editor'),accent,self.small)
        for row,message in enumerate(self.output[-(8 if self.output_expanded else 2):] or [self.message]): text(10,b+69+row*15,message[:max(10,(w-20)//7)],muted,self.small)
        d.rounded_rectangle((10,h-38,w-10,h-8),radius=4,fill='#101720',outline=accent if self.typing else border); text(17,h-32,'> '+self.command[-max(10,(w-40)//7):]+('|' if self.typing else ''),font=self.small); self.buttons.append((10,h-38,w-10,h-8,lambda:setattr(self,'typing',True)))
        self.dirty=False; return im
