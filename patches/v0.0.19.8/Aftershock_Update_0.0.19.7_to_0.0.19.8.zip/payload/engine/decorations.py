"""Bounded, deterministic grass patches; all movement is in the vertex shader."""
import math
import numpy as np
from .terrain import STEP, surface_ids
TILE=32
COUNT=1800

def grass_patch(terrain,key):
    # Stable per-tile seed, independent of traversal order.
    seed=(terrain.seed*2654435761+key[0]*73856093+key[1]*19349663)&0xffffffff
    rng=np.random.default_rng(seed); x=key[0]*TILE+rng.random(COUNT)*TILE;z=key[1]*TILE+rng.random(COUNT)*TILE
    # Match the actual high-detail terrain triangles, not the continuous height function.
    a=np.floor(x/STEP)*STEP;b=np.floor(z/STEP)*STEP;u=(x-a)/STEP;v=(z-b)/STEP
    h00=terrain.height(a,b);h10=terrain.height(a+STEP,b);h01=terrain.height(a,b+STEP);h11=terrain.height(a+STEP,b+STEP)
    y=np.where(u+v<=1,h00+(h10-h00)*u+(h01-h00)*v,h11+(h01-h11)*(1-u)+(h10-h11)*(1-v))
    ny=1/np.sqrt(1+((h10-h00)/STEP)**2+((h01-h00)/STEP)**2)
    ids=surface_ids(terrain,x,z,y,ny);keep=(ids==0)&(y>terrain.water+.35)&(ny>.78)&(abs(x)<terrain.size/2)&(abs(z)<terrain.size/2)
    rows=np.column_stack((x,y-.025,z,rng.uniform(.20,.64,COUNT),rng.uniform(0,math.tau,COUNT),rng.uniform(.74,1.24,COUNT)))
    return np.ascontiguousarray(rows[keep],dtype='f4')

def blade_geometry():
    rows=[]
    # Four tapered, curved ribbons per tuft; different height and tilt.
    for j,angle in enumerate((0,math.pi/4,math.pi/2,3*math.pi/4)):
        points=[(-.027,0),(.027,0),(-.022,.45),(.022,.45),(-.009,.78),(.009,.78),(0,1)]
        for k in (0,1,2,1,3,2,2,3,4,3,5,4,4,5,6):
            x,y=points[k]; bend=(.16+.04*j)*y*y;spread=(j-1.5)*.095
            rows.append((math.cos(angle)*x-math.sin(angle)*bend+spread,y*(.76+.08*j),math.sin(angle)*x+math.cos(angle)*bend))
    return np.asarray(rows,dtype='f4')

class Decorations:
    def __init__(self):self.terrain=None;self.cache={};self.key=None;self.rows=np.empty((0,6),'f4');self.changed=True
    def update(self,terrain,position,radius=1,density=1):
        if terrain is not self.terrain:self.cache.clear();self.key=None;self.terrain=terrain
        cx,cz=math.floor(position[0]/TILE),math.floor(position[2]/TILE)
        key=(cx,cz,radius,density,bool(terrain and terrain.decorations))
        self.changed=key!=self.key
        if not self.changed:return self.rows
        self.key=key
        keys={(x,z) for x in range(cx-radius,cx+radius+1) for z in range(cz-radius,cz+radius+1)} if key[-1] else set()
        self.cache={k:v for k,v in self.cache.items() if k in keys}
        for k in sorted(keys):
            if k not in self.cache:self.cache[k]=grass_patch(terrain,k)
        self.rows=np.ascontiguousarray(np.concatenate([v[::density] for v in self.cache.values()]) if self.cache else np.empty((0,6),'f4'))
        return self.rows

# Geometry LOD: same anchored tuft, different ribbon counts and segment budgets.
def detailed_blades(level):
    if level==1:return blade_geometry()
    rng=np.random.default_rng(2098);rows=[]
    count=9 if level==0 else 2
    for j in range(count):
        a=j*math.tau/count+rng.uniform(-.22,.22);height=rng.uniform(.64,1.13);width=rng.uniform(.016,.035);spread=rng.uniform(.02,.15)
        sections=4 if level==0 else 1
        points=[]
        for i in range(sections+1):
            t=i/sections;w=width*(1-t)**.72; bend=.29*t*t+spread
            points.append([(math.cos(a)*bend-math.sin(a)*s*w,t*height,math.sin(a)*bend+math.cos(a)*s*w) for s in (-1,1)])
        for i in range(sections):
            l,r=points[i];a1,b1=points[i+1];rows.extend((l,r,a1))
            if i<sections-1:rows.extend((r,b1,a1))
    return np.asarray(rows,dtype='f4')

def grass_lod_batches(rows,position,quality):
    """Quantized distance bands; stable density thinning independent of camera order."""
    ranges={'Low':(12,24,35),'Medium':(20,42,65),'High':(26,55,90),'Ultra':(34,70,110)}[quality]
    if not len(rows):return tuple(np.empty((0,6),'f4') for _ in ranges)
    center=(np.floor(np.asarray(position)[[0,2]]/4)+.5)*4
    distance=np.linalg.norm(rows[:,[0,2]]-center,axis=1)
    seed=np.mod(np.floor(rows[:,0]*91)+np.floor(rows[:,2]*137),11)
    return tuple(np.ascontiguousarray(rows[mask]) for mask in (distance<ranges[0],(distance>=ranges[0])&(distance<ranges[1])&(seed<8),(distance>=ranges[1])&(distance<ranges[2])&(seed<4)))
