# Real World Renderer I · Aftershock 0.0.19.8

Install on 0.0.19.7 using Check for Updates. No new dependencies.

## Rendering
Grass uses three actual instanced geometry meshes (63, 20 and 2 triangles per tuft) with deterministic thinning in the middle/far bands. Grass geometry fades at the maximum range: 35/65/90/110 metres for Low/Medium/High/Ultra. The tree streamer chooses detailed leaf triangles and branches close by, medium-detail leaf clusters further away and simplified solid crown silhouettes in the distance; it limits tile/cache and tree counts. The existing terrain mesh LOD is retained. Trees and vegetation remain procedural. Transition bands switch meshes, so some popping is possible. Terrain vegetation does not add physical colliders.

Ground surface sampling blends two differently scaled, offset copies of the texture. The engine fades expensive normal map detail as distance increases. Existing 1K PBR map import, mipmaps and anisotropic filtering are preserved. The materials in the base engine remain procedural unless the optional scans are installed.

Water has wind-dependent wave normal strength, more varied shoreline foam and shallow caustic-style lighting. It retains the previous approximate buoyancy and swimming physics; no real fluid solver, transparency or scene reflections. Puddles have a multiscale basin mask and persistent wetness, with the existing evaporation and ripples. The rain shader evaluates three world-position-based depth planes and respects foreground depth; it does not simulate individual collisions, shelter or roof detection.

## Optional real scanned materials
Graphics > Download Poly Haven CC0 material pack. Confirm, monitor progress in Graphics/Output, and restart Studio after downloading. The installer first tries the official optional GitHub pack and falls back to the Poly Haven API if it is unavailable. It downloads 1K diffuse, OpenGL normal and roughness maps for eight materials and checks reported hashes. Existing project PBR overrides are preserved. It installs materials in the project, not the engine update directory, so engine rollback does not delete them. Temporary archives are cleaned. The material cache is optional and can occupy tens of MB; each imported map set is 1K. Wood maps to bark for outdoor vegetation; other wooden objects will also inherit bark unless a different Wood override is imported. Game export includes project overrides.

Poly Haven (https://polyhaven.com) assets are CC0. Sources: leafy_grass, aerial_beach_02, aerial_rocks_02, forest_floor, concrete_floor_01, aerial_asphalt_01, brick_wall_02, bark_brown_02. Exact GitHub archive contents depend on successful source downloads; failed sources can be retried directly. No downloads occur automatically at launch.

Test with the Forest Valley, Tropical Island, and Material Showcase templates. Start Medium quality at 70% render scale on M1 hardware; High increases vegetation detail and distance. Actual macOS GPU performance needs hardware testing.
